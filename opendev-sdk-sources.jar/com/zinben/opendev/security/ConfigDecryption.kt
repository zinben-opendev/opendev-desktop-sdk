package com.zinben.opendev.security

import com.zinben.opendev.logger.Logger

/**
 * 配置文件解密工具
 * 使用AES-256-GCM算法解密CDN下载的加密配置文件
 */
object ConfigDecryption {
    
    private const val ALGORITHM = "AES/GCM/NoPadding"
    internal const val IV_LENGTH = 16 // 128位
    internal const val AUTH_TAG_LENGTH = 16 // 128位
    private const val KEY_LENGTH = 32 // 256位
    
    /**
     * 解密加密的配置文件
     * 
     * @param encryptedData 加密数据（hex编码的字符串，格式：version:iv:authTag:encryptedData）
     * @param encryptionKey 解密密钥（32字节，hex字符串或UTF-8字符串）
     * @return 解密后的JSON字符串
     * @throws Exception 解密失败时抛出异常
     */
    suspend fun decrypt(encryptedData: String, encryptionKey: String): String {
        return try {
            // 解析加密数据格式：version:iv:authTag:encryptedData
            val parts = encryptedData.split(":")
            if (parts.size != 4) {
                throw IllegalArgumentException("Invalid encrypted data format. Expected: version:iv:authTag:encryptedData")
            }
            
            val version = parts[0]
            val ivHex = parts[1]
            val authTagHex = parts[2]
            val encryptedHex = parts[3]
            
            Logger.debug("[ConfigDecryption] Decrypting config: version=$version, ivLength=${ivHex.length}, authTagLength=${authTagHex.length}, encryptedLength=${encryptedHex.length}")
            
            // 验证版本
            if (version != "v1") {
                throw IllegalArgumentException("Unsupported encryption version: $version")
            }
            
            // 转换hex字符串为字节数组
            val iv = hexStringToByteArray(ivHex)
            val authTag = hexStringToByteArray(authTagHex)
            val encrypted = hexStringToByteArray(encryptedHex)
            
            // 验证长度
            if (iv.size != IV_LENGTH) {
                throw IllegalArgumentException("Invalid IV length: ${iv.size}, expected: $IV_LENGTH")
            }
            if (authTag.size != AUTH_TAG_LENGTH) {
                throw IllegalArgumentException("Invalid auth tag length: ${authTag.size}, expected: $AUTH_TAG_LENGTH")
            }
            
            // 准备密钥
            val key = prepareKey(encryptionKey)
            
            // 执行解密
            val decrypted = decryptAES256GCMImpl(key, iv, authTag, encrypted)
            
            Logger.debug("[ConfigDecryption] Decryption successful, decrypted length: ${decrypted.size}")
            
            // 转换为字符串
            decrypted.decodeToString()
        } catch (e: Exception) {
            Logger.error("[ConfigDecryption] Decryption failed: ${e.message}")
            throw Exception("Failed to decrypt config file: ${e.message}", e)
        }
    }
    
    /**
     * 准备解密密钥
     * 支持hex字符串（64字符）或UTF-8字符串（32字符）
     */
    private fun prepareKey(encryptionKey: String): ByteArray {
        return when {
            encryptionKey.length == 64 -> {
                // hex字符串，64个字符 = 32字节
                hexStringToByteArray(encryptionKey)
            }
            encryptionKey.length == 32 -> {
                // 直接是32字节的UTF-8字符串
                encryptionKey.encodeToByteArray()
            }
            else -> {
                throw IllegalArgumentException(
                    "Encryption key must be 32 bytes (64 hex characters or 32 UTF-8 characters), got: ${encryptionKey.length}"
                )
            }
        }
    }
    
    /**
     * 将hex字符串转换为字节数组
     */
    private fun hexStringToByteArray(hex: String): ByteArray {
        val len = hex.length
        val data = ByteArray(len / 2)
        var i = 0
        while (i < len) {
            val digit1 = hex[i].digitToInt(16)
            val digit2 = hex[i + 1].digitToInt(16)
            data[i / 2] = ((digit1 shl 4) + digit2).toByte()
            i += 2
        }
        return data
    }
    
    
}

/**
 * 平台特定的AES-256-GCM解密实现
 * 使用expect/actual机制
 * 
 * 注意：这是一个suspend函数，支持异步操作（WasmJS平台需要）
 */
internal expect suspend fun decryptAES256GCMImpl(
    key: ByteArray,
    iv: ByteArray,
    authTag: ByteArray,
    encrypted: ByteArray
): ByteArray

