package com.zinben.opendev.security

internal actual fun currentTimeMillis(): Long = System.currentTimeMillis()
