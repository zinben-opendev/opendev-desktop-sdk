package com.zinben.opendev.security

/**
 * CDN 密钥编码器
 * 
 * 提供密钥片段的编码和解码功能。
 * 使用 XOR 混淆增加逆向难度。
 */
internal object CdnKeyEncoder {
    
    // XOR 混淆种子（分散存储）
    private val XOR_SEED = byteArrayOf(
        0x42.toByte(), 0x7A.toByte(), 0x1E.toByte(), 0x93.toByte(),
        0xC5.toByte(), 0x68.toByte(), 0x2F.toByte(), 0xD4.toByte()
    )
    
    /**
     * 解码密钥片段
     * 
     * @param encoded 编码后的片段
     * @param index 片段索引（用于选择 XOR 种子）
     * @return 解码后的原始片段
     */
    fun decode(encoded: String, index: Int): String {
        val bytes = hexToBytes(encoded)
        val seed = XOR_SEED[index % XOR_SEED.size]
        
        // XOR 解码
        for (i in bytes.indices) {
            bytes[i] = (bytes[i].toInt() xor seed.toInt()).toByte()
        }
        
        return bytesToHex(bytes)
    }
    
    /**
     * 编码密钥片段（用于生成混淆后的片段）
     * 
     * 注意：此方法仅用于初始密钥混淆，生产环境不使用
     * 
     * @param plain 明文片段
     * @param index 片段索引
     * @return 编码后的片段
     */
    @Suppress("unused")
    fun encode(plain: String, index: Int): String {
        val bytes = hexToBytes(plain)
        val seed = XOR_SEED[index % XOR_SEED.size]
        
        // XOR 编码
        for (i in bytes.indices) {
            bytes[i] = (bytes[i].toInt() xor seed.toInt()).toByte()
        }
        
        return bytesToHex(bytes)
    }
    
    /**
     * 十六进制字符串转字节数组
     */
    private fun hexToBytes(hex: String): ByteArray {
        val result = ByteArray(hex.length / 2)
        for (i in result.indices) {
            val index = i * 2
            result[i] = hex.substring(index, index + 2).toInt(16).toByte()
        }
        return result
    }
    
    /**
     * 字节数组转十六进制字符串
     */
    private fun bytesToHex(bytes: ByteArray): String {
        val hexChars = "0123456789abcdef"
        return bytes.joinToString("") { byte ->
            val value = byte.toInt() and 0xFF
            "${hexChars[value shr 4]}${hexChars[value and 0x0F]}"
        }
    }
}

