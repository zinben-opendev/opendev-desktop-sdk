package com.zinben.opendev.security

/**
 * CDN 密钥存储 - Part 1
 * 
 * 存储密钥片段的第一部分（奇数片段）。
 * 片段已使用 XOR 混淆，运行时解码。
 */
internal object CdnKeyStore {
    
    // 存储混淆后的密钥片段（奇数位置）
    // 注意：这些不是明文，需要通过 CdnKeyEncoder 解码
    
    /**
     * 密钥片段 1 (混淆后)
     * 原始: e1271659
     * 索引: 0, XOR 0x42
     */
    const val PART_1 = "a365541b"
    
    /**
     * 密钥片段 3 (混淆后)
     * 原始: 9aec0d8f
     * 索引: 2, XOR 0x1E
     */
    const val PART_3 = "84f21391"
    
    /**
     * 密钥片段 5 (混淆后)
     * 原始: 27d9a103
     * 索引: 4, XOR 0xC5
     */
    const val PART_5 = "e21c64c6"
    
    /**
     * 密钥片段 7 (混淆后)
     * 原始: 48253021
     * 索引: 6, XOR 0x2F
     */
    const val PART_7 = "670a1f0e"
}

