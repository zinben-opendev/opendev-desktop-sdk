package com.zinben.opendev.security

/**
 * HMAC-SHA256 跨平台实现（expect/actual）。
 *
 * 与后端 `appSignature.js` 的 `generateSignature` 算法一致：
 * `HMAC-SHA256(key, message)` → hex 小写。
 */
internal expect fun hmacSha256(key: ByteArray, data: ByteArray): ByteArray

@OptIn(ExperimentalStdlibApi::class)
internal fun hmacSha256Hex(key: String, message: String): String {
    val hash = hmacSha256(key.encodeToByteArray(), message.encodeToByteArray())
    return hash.toHexString()
}
