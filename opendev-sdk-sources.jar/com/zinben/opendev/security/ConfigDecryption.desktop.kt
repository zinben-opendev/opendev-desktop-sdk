package com.zinben.opendev.security

import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Desktop平台AES-256-GCM解密实现
 */
internal actual suspend fun decryptAES256GCMImpl(
    key: ByteArray,
    iv: ByteArray,
    authTag: ByteArray,
    encrypted: ByteArray
): ByteArray {
    // 创建密钥规范
    val keySpec = SecretKeySpec(key, "AES")
    
    // 创建GCM参数规范
    // GCM模式使用128位认证标签（16字节 * 8位）
    val gcmSpec = GCMParameterSpec(ConfigDecryption.AUTH_TAG_LENGTH * 8, iv)
    
    // 创建解密器
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.DECRYPT_MODE, keySpec, gcmSpec)
    
    // 在GCM模式中，认证标签需要附加在密文后面
    // 执行解密（会自动验证认证标签）
    val decrypted = cipher.doFinal(encrypted + authTag)
    
    return decrypted
}

