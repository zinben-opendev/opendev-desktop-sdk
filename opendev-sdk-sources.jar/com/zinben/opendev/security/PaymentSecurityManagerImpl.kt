package com.zinben.opendev.security

import com.zinben.opendev.logger.Logger
import com.zinben.opendev.managers.PaymentSecurityManager
import com.zinben.opendev.models.PaymentRequest
import com.zinben.opendev.models.RefundRequest
import kotlin.uuid.ExperimentalUuidApi
import kotlin.uuid.Uuid

/**
 * PaymentSecurityManager 的生产实现。
 *
 * 职责：
 * 1. **HMAC-SHA256 请求签名** — 与后端 `appSignature.js` 算法一致，
 *    为 `POST /orders`、`/verify`、`/finish` 注入 `X-Pay-Signature` 等 Header
 * 2. **本地参数校验** — 在发起网络请求前拦截明显非法的支付/退款请求
 *
 * 签名算法：`HMAC-SHA256(appSecret, "appId|userId|orderId|productId|timestamp")`
 * 输出格式：hex 小写（与后端 `crypto.createHmac('sha256', appSecret).digest('hex')` 一致）
 */
class PaymentSecurityManagerImpl(
    private val appId: String,
    private val appSecret: String
) : PaymentSecurityManager {

    val isSigningEnabled: Boolean
        get() = appSecret.isNotBlank()

    /**
     * 生成支付请求 HMAC 签名。
     *
     * @return [PaymentSignature] 包含 signature、timestamp、nonce，
     *         调用方应将其注入 HTTP Header。若 appSecret 为空则返回 null（降级为无签名）。
     */
    @OptIn(ExperimentalUuidApi::class)
    fun signPaymentRequest(
        userId: String,
        orderId: String,
        productId: String
    ): PaymentSignature? {
        if (appSecret.isBlank()) {
            Logger.debug("[PaymentSecurity] appSecret not configured, skipping signature")
            return null
        }

        val timestamp = currentTimeMillis()
        val nonce = Uuid.random().toString()
        val message = "$appId|$userId|$orderId|$productId|$timestamp"
        val signature = hmacSha256Hex(appSecret, message)

        Logger.debug("[PaymentSecurity] Signed: message=$appId|$userId|${orderId.take(8)}...|${productId.take(8)}...|$timestamp")
        return PaymentSignature(
            signature = signature,
            timestamp = timestamp,
            nonce = nonce
        )
    }

    override suspend fun validatePaymentRequest(request: PaymentRequest): Boolean {
        if (request.orderId.isBlank()) {
            Logger.error("[PaymentSecurity] validatePaymentRequest: orderId is blank")
            return false
        }
        val amountValue = request.amount.value.toDoubleOrNull()
        if (amountValue == null || amountValue <= 0) {
            Logger.error("[PaymentSecurity] validatePaymentRequest: invalid amount=${request.amount.value}")
            return false
        }
        if (request.currency.length != 3) {
            Logger.error("[PaymentSecurity] validatePaymentRequest: invalid currency=${request.currency}")
            return false
        }
        return true
    }

    override suspend fun validateRefundRequest(request: RefundRequest): Boolean {
        if (request.orderId.isBlank()) {
            Logger.error("[PaymentSecurity] validateRefundRequest: orderId is blank")
            return false
        }
        if (request.transactionId.isBlank()) {
            Logger.error("[PaymentSecurity] validateRefundRequest: transactionId is blank")
            return false
        }
        val amountValue = request.amount.value.toDoubleOrNull()
        if (amountValue == null || amountValue <= 0) {
            Logger.error("[PaymentSecurity] validateRefundRequest: invalid amount=${request.amount.value}")
            return false
        }
        if (request.currency.length != 3) {
            Logger.error("[PaymentSecurity] validateRefundRequest: invalid currency=${request.currency}")
            return false
        }
        return true
    }

    override suspend fun verifyCallbackSignature(callbackData: String): Boolean {
        // Webhook 签名验证在服务端完成，客户端仅做基本格式检查
        return callbackData.isNotBlank()
    }
}

data class PaymentSignature(
    val signature: String,
    val timestamp: Long,
    val nonce: String
) {
    companion object {
        const val HEADER_SIGNATURE = "X-Pay-Signature"
        const val HEADER_TIMESTAMP = "X-Pay-Timestamp"
        const val HEADER_NONCE = "X-Pay-Nonce"
    }
}

internal expect fun currentTimeMillis(): Long
