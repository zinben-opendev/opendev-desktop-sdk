package com.zinben.opendev.security

/**
 * CDN 密钥助手 - Part 2
 * 
 * 存储密钥片段的第二部分（偶数片段）。
 * 片段已使用 XOR 混淆，运行时解码。
 */
internal object CdnKeyHelper {
    
    // 存储混淆后的密钥片段（偶数位置）
    // 注意：这些不是明文，需要通过 CdnKeyEncoder 解码
    
    /**
     * 密钥片段 2 (混淆后)
     * 原始: 5595bd99
     * 索引: 1, XOR 0x7A
     */
    const val PART_2 = "2fefc7e3"
    
    /**
     * 密钥片段 4 (混淆后)
     * 原始: 19d4c91d
     * 索引: 3, XOR 0x93
     */
    const val PART_4 = "8a475a8e"
    
    /**
     * 密钥片段 6 (混淆后)
     * 原始: f15eb24a
     * 索引: 5, XOR 0x68
     */
    const val PART_6 = "9936da22"
    
    /**
     * 密钥片段 8 (混淆后)
     * 原始: 7e3dea57
     * 索引: 7, XOR 0xD4
     */
    const val PART_8 = "aae93e83"
}

