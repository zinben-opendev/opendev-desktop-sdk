package com.zinben.opendev

import com.zinben.opendev.adapters.ClientPaymentAdapter
import com.zinben.opendev.adapters.PaymentPlatformAdapter
import com.zinben.opendev.adapters.PlatformAuthAdapter
import com.zinben.opendev.auth.AuthProviderRegistry
import com.zinben.opendev.factories.Environment
import com.zinben.opendev.factories.PlatformConfig
import com.zinben.opendev.factories.PlatformFactory
import com.zinben.opendev.factories.createDefaultPlatformConfig
import com.zinben.opendev.logger.Logger
import com.zinben.opendev.managers.AuthManager
import com.zinben.opendev.managers.PaymentManager
import com.zinben.opendev.models.*
import com.zinben.opendev.network.globalSSLCertificateConfig
import com.zinben.opendev.services.ConfigService
import com.zinben.opendev.services.HttpPaymentService
import com.zinben.opendev.services.OAuthConfigCache
import com.zinben.opendev.storage.TokenStorage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * OpenDev SDK 统一客户端
 *
 * 这是 OpenDev SDK 的唯一公开入口，整合了认证、支付、配置管理和状态观察。
 * 支持构造器注入以便测试，同时提供 [getInstance] 单例访问。
 *
 * ## 使用示例
 * ```kotlin
 * val client = OpenDevClient.getInstance()
 * client.initialize(enableAutoLogin = true)
 *
 * client.login(LoginMethod.GOOGLE)
 * client.currentUser.collect { user -> ... }
 * ```
 */
class OpenDevClient internal constructor(
    val authManager: AuthManager,
    val paymentManager: PaymentManager,
    private val clientPaymentAdapter: ClientPaymentAdapter,
    private val authAdapter: PlatformAuthAdapter,
    private val paymentAdapters: Map<PaymentMethodType, PaymentPlatformAdapter>,
    private val tokenStorage: TokenStorage,
    val authProviderRegistry: AuthProviderRegistry,
    private val configService: ConfigService,
    private val oauthConfigCache: OAuthConfigCache,
    internal val httpPaymentService: HttpPaymentService,
    private var config: PlatformConfig,
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
) {

    // ==================== 版本常量 ====================

    companion object {
        const val VERSION = "1.6.0"
        const val BUILD_DATE = "2024-12-19"
        const val MAX_AVATAR_SIZE = 1 * 1024 * 1024 // 1MB

        private var instance: OpenDevClient? = null
        private val mutex = Mutex()

        @InternalOpenDevApi
        suspend fun getInstance(): OpenDevClient {
            return instance ?: throw IllegalStateException(
                "OpenDevClient not initialized. Call OpenDevSDK.initialize() first."
            )
        }

        @InternalOpenDevApi
        fun getInstanceOrNull(): OpenDevClient? = instance

        @InternalOpenDevApi
        fun isInitialized(): Boolean = instance != null

        /**
         * 创建 OpenDevClient 实例（高级用法）
         *
         * 大多数场景应使用 [OpenDevSDK.initialize]。
         * 此工厂方法用于需要完全控制依赖的测试场景。
         */
        @InternalOpenDevApi
        suspend fun create(config: PlatformConfig): OpenDevClient {
            globalSSLCertificateConfig = config.sslCertificateConfig
            val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
            val deps = SDKDependencies.create(config, scope)
            val client = OpenDevClient(
                authManager = deps.authManager,
                paymentManager = deps.paymentManager,
                clientPaymentAdapter = deps.clientPaymentAdapter,
                authAdapter = deps.authAdapter,
                paymentAdapters = deps.paymentAdapters,
                tokenStorage = deps.tokenStorage,
                authProviderRegistry = deps.authProviderRegistry,
                configService = deps.configService,
                oauthConfigCache = deps.oauthConfigCache,
                httpPaymentService = deps.httpPaymentService,
                config = config,
                scope = scope
            )
            return client
        }

        /**
         * 使用配置初始化单例实例。
         *
         * 外部应通过 [OpenDevSDK.initialize] 调用，不应直接使用此方法。
         */
        @InternalOpenDevApi
        suspend fun initializeInstance(
            config: PlatformConfig? = null,
            enableAutoLogin: Boolean = false,
            ensureLoggedIn: Boolean = false
        ): Result<OpenDevClient> {
            if (instance != null) {
                val client = instance!!
                client.initialize(config, enableAutoLogin, ensureLoggedIn)
                return Result.success(client)
            }
            return mutex.withLock {
                if (instance != null) {
                    val client = instance!!
                    client.initialize(config, enableAutoLogin, ensureLoggedIn)
                    return@withLock Result.success(client)
                }
                runCatching {
                    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
                    val resolvedConfig = resolveConfigWithCdnIfNeeded(config, scope)
                    globalSSLCertificateConfig = resolvedConfig.sslCertificateConfig
                    val deps = SDKDependencies.create(resolvedConfig, scope)
                    val client = OpenDevClient(
                        authManager = deps.authManager,
                        paymentManager = deps.paymentManager,
                        clientPaymentAdapter = deps.clientPaymentAdapter,
                        authAdapter = deps.authAdapter,
                        paymentAdapters = deps.paymentAdapters,
                        tokenStorage = deps.tokenStorage,
                        authProviderRegistry = deps.authProviderRegistry,
                        configService = deps.configService,
                        oauthConfigCache = deps.oauthConfigCache,
                        httpPaymentService = deps.httpPaymentService,
                        config = resolvedConfig,
                        scope = scope
                    )
                    client.initialize(config, enableAutoLogin, ensureLoggedIn).getOrThrow()
                    client
                }
            }
        }

        /**
         * 从 CDN 加载配置并合并到宿主提供的配置中。
         * 即使 appId/apiBaseUrl 已设置，仍会尝试加载 CDN 以补充 publisher 等辅助信息。
         * [fillDefaultsFrom] 确保宿主已设置的字段不被覆盖。
         */
        private suspend fun resolveConfigWithCdnIfNeeded(config: PlatformConfig?, scope: CoroutineScope): PlatformConfig {
            val base = config ?: createDefaultPlatformConfig(null)
            if (base.cdnBaseUrl.isEmpty()) return base
            val configService = ConfigService(scope)
            val platform: ConfigPlatform = PlatformFactory.getCurrentPlatform().toConfigPlatform()
            val configEnv: ConfigEnvironment = base.environment.toConfigEnvironment()
            val sdkConfig: SDKConfig? = configService.loadConfig(
                platform = platform,
                environment = configEnv,
                channelKey = base.channelKey.takeIf { it.isNotEmpty() },
                cdnBaseUrl = base.cdnBaseUrl,
                cdnToken = base.cdnToken.takeIf { it.isNotEmpty() }
            )
            if (sdkConfig == null) {
                Logger.debug("[OpenDevClient] CDN config load failed or not available, using partial config")
                return base
            }
            val fromCdn = createDefaultPlatformConfig(sdkConfig)
            return base.fillDefaultsFrom(fromCdn)
        }
    }

    // ==================== 状态观察 ====================

    private val _initializationState = MutableStateFlow<InitializationState>(InitializationState.NotInitialized)
    val initializationState: StateFlow<InitializationState> = _initializationState.asStateFlow()

    private val _loginState = MutableStateFlow<LoginState>(LoginState.Idle)
    val loginState: StateFlow<LoginState> = _loginState.asStateFlow()

    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    private val _showLoginDialog = MutableStateFlow<LoginUIDialogState?>(null)
    val showLoginDialog: StateFlow<LoginUIDialogState?> = _showLoginDialog.asStateFlow()

    // ==================== 私有状态 ====================

    private val instanceMutex = Mutex()
    private val loginMutex = Mutex()
    private val autoLoginScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var isAutoLoginEnabled = false
    private var previousLoginState: LoginState? = null
    private var isInitialLogin = true
    private var isManualSwitching = false
    private val currentPlatform = PlatformFactory.getCurrentPlatform()

    // ==================== 初始化 ====================

    /**
     * 初始化 SDK
     *
     * @param config 平台配置，null 则使用默认配置
     * @param enableAutoLogin 是否启用自动登录监听
     * @param ensureLoggedIn 是否在初始化后确保用户已登录
     */
    suspend fun initialize(
        config: PlatformConfig? = null,
        enableAutoLogin: Boolean = false,
        ensureLoggedIn: Boolean = false
    ): Result<Unit> {
        Logger.debug("[OpenDevClient] initialize() called, enableAutoLogin=$enableAutoLogin, ensureLoggedIn=$ensureLoggedIn")

        if (_initializationState.value == InitializationState.Initialized) {
            Logger.debug("[OpenDevClient] Already initialized, skipping")
            if (enableAutoLogin && !isAutoLoginEnabled) startAutoLoginListener()
            if (ensureLoggedIn) ensureLoggedIn()
            return Result.success(Unit)
        }

        return runCatching {
            instanceMutex.withLock {
                if (_initializationState.value == InitializationState.Initialized) {
                    if (enableAutoLogin && !isAutoLoginEnabled) startAutoLoginListener()
                    if (ensureLoggedIn) ensureLoggedIn()
                    return@withLock
                }

                Logger.debug("[OpenDevClient] Starting initialization...")
                _initializationState.value = InitializationState.Initializing

                authManager.initialize()
                clientPaymentAdapter.initializeSDK()

                Logger.debug("[OpenDevClient] Core initialized, loading OAuth config...")
                loadOAuthConfigWithCache()

                Logger.debug("[OpenDevClient] Refreshing login state...")
                refreshLoginStateInternal()

                _initializationState.value = InitializationState.Initialized
                instance = this@OpenDevClient
                Logger.debug("[OpenDevClient] Initialization completed successfully")

                syncUserProfileFromServer()

                if (this@OpenDevClient.config.environment == Environment.DEVELOPMENT) {
                    logConfigDiagnostic()
                }

                if (enableAutoLogin) startAutoLoginListener()
                if (ensureLoggedIn) ensureLoggedIn()
            }
        }.onFailure { error ->
            val msg = error.message ?: "Unknown error"
            Logger.error("[OpenDevClient] Initialization failed: $msg")
            _initializationState.value = InitializationState.Failed(msg)
        }.map { }
    }

    suspend fun enableAutoLogin() {
        if (isAutoLoginEnabled) return
        startAutoLoginListener()
    }

    suspend fun ensureLoggedIn(onResult: ((Result<AuthResult>) -> Unit)? = null) {
        Logger.debug("[OpenDevClient] ensureLoggedIn() called")
        loginUI { result ->
            result.onSuccess { authResult ->
                if (authResult is AuthResult.Success) {
                    Logger.debug("[OpenDevClient] Ensure login successful: userId=${authResult.user.id}")
                }
            }.onFailure { error ->
                Logger.error("[OpenDevClient] Ensure login failed: ${error.message}")
            }
            onResult?.invoke(result)
        }
    }

    // ==================== 认证 API ====================

    suspend fun login(method: LoginMethod = LoginMethod.GUEST): Result<AuthResult> {
        Logger.debug("[OpenDevClient] login() called with method: $method")

        if (_loginState.value is LoginState.LoggedIn) {
            val loggedInState = _loginState.value as LoginState.LoggedIn
            val user = loggedInState.user ?: throw IllegalStateException("Logged in but user is null")

            if (loggedInState.method == method) {
                Logger.debug("[OpenDevClient] Already logged in with same method, returning current state")
                val currentToken = runCatching { authManager.getAccessToken() }.getOrNull() ?: ""
                return Result.success(
                    AuthResult.Success(user = user, sessionToken = currentToken, jwtToken = null, expiresAt = null)
                )
            }

            Logger.debug("[OpenDevClient] Login method changed, performing account switch")
            isManualSwitching = true
            try {
                logout().getOrThrow()
            } catch (e: Exception) {
                Logger.error("[OpenDevClient] Logout failed during switch: ${e.message}")
            }
        }

        try {
            return when (method) {
                LoginMethod.GUEST -> performAuthCall(method) { authManager.performGuestLogin() }
                LoginMethod.FACEBOOK, LoginMethod.GOOGLE, LoginMethod.APPLE, LoginMethod.WECHAT, LoginMethod.QQ -> {
                    val provider = method.toThirdPartyProvider()
                        ?: return Result.failure(IllegalArgumentException("Invalid login method: $method"))
                    performAuthCall(method) { authManager.performThirdPartyLogin(provider) }
                }
                LoginMethod.PHONE, LoginMethod.EMAIL -> {
                    return Result.failure(
                        UnsupportedOperationException("Use sendOtp() + verifyOtpAndLogin() for $method login")
                    )
                }
            }
        } finally {
            isManualSwitching = false
        }
    }

    suspend fun loginUI(onResult: (Result<AuthResult>) -> Unit) {
        Logger.debug("[OpenDevClient] loginUI() called")
        if (_loginState.value is LoginState.LoggedIn) {
            val loggedInState = _loginState.value as LoginState.LoggedIn
            onResult(login(loggedInState.method))
            return
        }
        Logger.debug("[OpenDevClient] User not logged in, showing login dialog")
        _showLoginDialog.value = LoginUIDialogState(onResult = onResult)
    }

    suspend fun handleLoginDialogAction(method: LoginMethod) {
        val dialogState = _showLoginDialog.value ?: return
        val loginResult = login(method)
        dialogState.onResult(loginResult)
        loginResult.getOrNull()?.let { authResult ->
            if (authResult is AuthResult.Success) _showLoginDialog.value = null
        }
    }

    fun dismissLoginDialog() {
        _showLoginDialog.value = null
    }

    suspend fun bindProvider(provider: ThirdPartyProvider): Result<AuthResult> {
        val currentMethod = resolveLoginMethod(_currentUser.value) ?: LoginMethod.GUEST
        return performAuthCall(currentMethod) { authManager.bindAccount(provider) }
    }

    suspend fun unbindProvider(provider: ThirdPartyProvider): Result<AuthResult> {
        val currentMethod = resolveLoginMethod(_currentUser.value) ?: LoginMethod.GUEST
        return performAuthCall(currentMethod) { authManager.unbindAccount(provider) }
    }

    suspend fun bindOtp(targetType: OtpTargetType, target: String): Result<AuthResult> {
        val currentMethod = resolveLoginMethod(_currentUser.value) ?: LoginMethod.GUEST
        return performAuthCall(currentMethod) { authManager.bindOtpAccount(targetType, target) }
    }

    suspend fun unbindOtp(targetType: OtpTargetType, target: String): Result<AuthResult> {
        val currentMethod = resolveLoginMethod(_currentUser.value) ?: LoginMethod.GUEST
        return performAuthCall(currentMethod) { authManager.unbindOtpAccount(targetType, target) }
    }

    suspend fun switchToGuest(): Result<Unit> = runCatching {
        isManualSwitching = true
        try {
            logout().getOrThrow()
            login().getOrThrow()
        } finally {
            isManualSwitching = false
        }
    }

    suspend fun selectAccount(user: User): Result<AuthResult> {
        val currentState = _loginState.value
        if (currentState !is LoginState.AccountSelection) {
            return Result.failure(IllegalStateException("Not in account selection state"))
        }
        return performAuthCall(currentState.method) { authManager.loginSelectedAccount(user) }
    }

    suspend fun logout(): Result<Unit> = try {
        _loginState.value = LoginState.Idle
        _currentUser.value = null
        withContext(NonCancellable) { authManager.logout() }
        Result.success(Unit)
    } catch (e: Exception) {
        _loginState.value = LoginState.Idle
        _currentUser.value = null
        Logger.error("[OpenDevClient] Logout exception (state cleared): ${e.message}")
        Result.success(Unit)
    }

    suspend fun refreshToken(): AuthResult = requireInit { authManager.refreshToken() }

    fun getCurrentUser(): User? = authManager.getCurrentUser()

    fun isLoggedIn(): Boolean = authManager.isLoggedIn()

    fun getAccessToken(): String? = authManager.getAccessToken()

    fun getTokenInfo(): TokenInfo? {
        val sessionToken = authManager.getAccessToken() ?: return null
        return TokenInfo(
            sessionToken = sessionToken,
            jwtToken = authManager.getJwtToken(),
            expiresAt = authManager.getExpiresAt()
        )
    }

    suspend fun getSupportedAuthProviders(): List<ThirdPartyProvider> =
        requireInit { authManager.getSupportedProviders() }

    suspend fun getOAuthConfig(channelKey: String? = null): OAuthProviderConfigs =
        requireInit { oauthConfigCache.current?.configs ?: OAuthProviderConfigs() }

    suspend fun getOAuthConfigFull(channelKey: String? = null): OAuthConfigResponse =
        requireInit { oauthConfigCache.current ?: OAuthConfigResponse() }

    suspend fun getAvailableChannels(): List<ChannelInfo> =
        requireInit { authManager.getAvailableChannels(config.appId) }

    suspend fun fetchChannelConfig(channelKey: String? = null): ClientChannelConfig =
        requireInit {
            val response = oauthConfigCache.current ?: OAuthConfigResponse()
            response.configs.toClientChannelConfig(response.channelKey ?: channelKey ?: "default")
        }

    val guestLoginEnabled: Boolean get() = config.guestLoginEnabled

    /**
     * Aggregates available login methods from in-memory OAuth config cache.
     *
     * - Guest login: controlled by [PlatformConfig.guestLoginEnabled] (client-side, default true)
     * - Third-party providers + OTP: from cached `GET /auth/oauth-config` response
     */
    suspend fun getAvailableLoginMethods(channelKey: String? = null): AvailableLoginMethods =
        requireInit {
            val oauthConfigs = oauthConfigCache.current?.configs ?: OAuthProviderConfigs()

            AvailableLoginMethods(
                guestEnabled = config.guestLoginEnabled,
                thirdPartyProviders = oauthConfigs.availableOAuthProviders(),
                otpMethods = oauthConfigs.availableOtpMethods()
            )
        }

    // ==================== OTP 登录 ====================

    /**
     * Step 1: Send an OTP code to the specified phone number or email address.
     *
     * @return [OtpSendResult] containing `sessionId` for the subsequent [verifyOtpAndLogin] call.
     */
    suspend fun sendOtp(
        targetType: OtpTargetType,
        target: String,
        channelKey: String? = null
    ): Result<OtpSendResult> = runCatching {
        requireInit {
            authManager.sendOtp(config.appId, targetType, target, channelKey)
        }
    }

    /**
     * Step 2: Verify the OTP code and complete login in one atomic operation.
     *
     * Internally: verify-otp -> fetch auth payload -> account login.
     *
     * May produce [LoginState.AccountSelection] if the backend returns multiple users
     * for the same OTP identity, consistent with the Federated multi-account flow.
     * Callers should observe [loginState] and handle [AuthResult.MultipleAccounts] accordingly.
     */
    suspend fun verifyOtpAndLogin(
        targetType: OtpTargetType,
        target: String,
        sessionId: String,
        code: String,
        channelKey: String? = null
    ): Result<AuthResult> {
        val method = if (targetType == OtpTargetType.EMAIL) LoginMethod.EMAIL else LoginMethod.PHONE
        return performAuthCall(method) {
            authManager.verifyOtpAndLogin(config.appId, targetType, target, sessionId, code, channelKey)
        }
    }

    // ==================== 用户管理 ====================

    // ==================== Saved Accounts API ====================

    suspend fun listSavedAccounts(): List<com.zinben.opendev.models.SavedAccount> =
        requireInit { authManager.getSavedAccounts() }

    suspend fun removeSavedAccount(userId: String) =
        requireInit { authManager.removeSavedAccount(userId) }

    suspend fun clearAllSavedAccounts() =
        requireInit { authManager.clearAllSavedAccounts() }

    // ==================== 用户管理 ====================

    suspend fun refreshLoginState() = refreshLoginStateInternal()

    suspend fun updateProfile(
        username: String,
        nickname: String? = null,
        avatar: String? = null
    ): Result<User> = runCatching {
        val user = _currentUser.value ?: throw IllegalStateException("User not logged in")
        val updatedUser = user.copy(username = username, nickname = nickname ?: user.nickname, avatar = avatar ?: user.avatar)
        val currentMethod = resolveLoginMethod(user) ?: LoginMethod.GUEST
        val result = authManager.updateUserInfo(updatedUser)
        if (result is AuthResult.Success) {
            _currentUser.value = result.user
            _loginState.value = LoginState.LoggedIn(result.user, resolveLoginMethod(result.user) ?: currentMethod)
            result.user
        } else {
            throw RuntimeException("Update profile failed: $result")
        }
    }

    suspend fun uploadAvatar(imageBytes: ByteArray, fileName: String, mimeType: String): Result<User> = runCatching {
        requireInit {
            val token = tokenStorage.getToken() ?: throw IllegalStateException("Not authenticated")
            val avatarUrl = authManager.uploadAvatar(imageBytes, fileName, mimeType, token)
            val user = _currentUser.value ?: throw IllegalStateException("User not logged in")
            val updatedUser = user.copy(avatar = avatarUrl)
            val currentMethod = resolveLoginMethod(user) ?: LoginMethod.GUEST
            _currentUser.value = updatedUser
            _loginState.value = LoginState.LoggedIn(updatedUser, resolveLoginMethod(updatedUser) ?: currentMethod)
            updatedUser
        }
    }

    // ==================== 统一支付 API ====================
    //
    // 带 UI 的一键商城：见 UI 模块 `PaymentMallPage`（与下列无 UI API 平行，开箱完整购买与订单记录页）。
    //

    /**
     * 从后端拉取商品档位列表。
     *
     * 返回的 [Product] 包含 [Product.platformProductIds] 映射，
     * 调用方可据此提取当前平台的原生商品 ID。
     *
     * 若无需自绘界面，可直接在应用中导航到 `core-ui` 的 `PaymentMallPage`。
     */
    suspend fun fetchProductsFromServer(): ProductQueryResult = requireInit {
        try {
            val dtos = httpPaymentService.fetchProducts()
            if (dtos.isEmpty()) {
                return@requireInit ProductQueryResult.Failure("NO_PRODUCTS", "No products configured")
            }
            val products = dtos.map { dto ->
                val productType = when (dto.type.lowercase()) {
                    "consumable" -> ProductType.CONSUMABLE
                    "non_consumable" -> ProductType.NON_CONSUMABLE
                    "subscription" -> ProductType.SUBSCRIPTION
                    "auto_renewable" -> ProductType.AUTO_RENEWABLE
                    else -> ProductType.CONSUMABLE
                }
                Product(
                    id = dto.productId,
                    name = dto.name,
                    description = dto.description ?: "",
                    price = Money(dto.price.amount.formatPlain()),
                    currency = dto.price.currency,
                    type = productType,
                    platform = currentPlatform,
                    isAvailable = true,
                    platformProductIds = dto.platformProductIds,
                    source = dto.source
                )
            }
            ProductQueryResult.Success(products)
        } catch (e: Exception) {
            Logger.error("[OpenDevClient] fetchProductsFromServer failed: ${e.message}")
            ProductQueryResult.Failure("FETCH_FAILED", e.message ?: "Failed to fetch products")
        }
    }

    /**
     * 使用平台原生商品 ID 从应用商店查询真实价格。
     *
     * @param nativeProductIds 平台原生商品 ID 列表（如 Google Play 的 `com.walknote.pay2`）
     */
    suspend fun fetchNativeProducts(nativeProductIds: List<String>): ProductQueryResult =
        requireInit { clientPaymentAdapter.fetchProducts(nativeProductIds) }

    /**
     * 统一购买流程（业界最佳实践）：
     *
     * 1. 后端下单 → 获取 orderId
     * 2. 原生支付 → 获取 receipt/purchaseToken
     * 3. 后端验证 → 验证支付凭证
     * 4. 后端发货 → 确认交易完成
     * 5. 客户端确认消费 → 防止重复发货
     *
     * @param serverProductId 后端商品 ID（如 `com_zinben_pay1`）
     * @param nativeProductId 平台原生商品 ID（如 Google Play 的 `com.walknote.pay2`）
     */
    suspend fun purchaseWithFullFlow(
        serverProductId: String,
        nativeProductId: String
    ): PurchaseResult = requireInit {
        val platformName = currentPlatform.name.lowercase()
        Logger.debug("[OpenDevClient] Starting full purchase flow: server=$serverProductId native=$nativeProductId platform=$platformName")

        try {
            // Step 1: 后端下单
            Logger.debug("[OpenDevClient] Step 1: Creating order on server")
            val orderResponse = httpPaymentService.createOrder(serverProductId, platformName)
            val orderId = orderResponse.orderId
            Logger.debug("[OpenDevClient] Order created: $orderId")

            // Step 2: 原生支付
            Logger.debug("[OpenDevClient] Step 2: Launching native payment for $nativeProductId")
            val nativeResult = clientPaymentAdapter.purchaseProduct(nativeProductId)

            when (nativeResult) {
                is PurchaseResult.Cancelled -> {
                    Logger.debug("[OpenDevClient] Purchase cancelled by user")
                    return@requireInit PurchaseResult.Cancelled(nativeProductId)
                }
                is PurchaseResult.Failure -> {
                    Logger.error("[OpenDevClient] Native payment failed: ${nativeResult.errorMessage}")
                    return@requireInit nativeResult
                }
                is PurchaseResult.Pending -> {
                    Logger.debug("[OpenDevClient] Purchase pending: ${nativeResult.message}")
                    return@requireInit nativeResult
                }
                is PurchaseResult.Success -> {
                    Logger.debug("[OpenDevClient] Native payment success, txn=${nativeResult.transaction.transactionId}")
                }
            }

            val transaction = nativeResult.transaction

            // Step 3: 后端验证
            Logger.debug("[OpenDevClient] Step 3: Verifying payment on server")
            val receiptData = buildReceiptData(transaction)
            try {
                httpPaymentService.verifyPayment(orderId, platformName, receiptData)
                Logger.debug("[OpenDevClient] Payment verified on server")
            } catch (e: Exception) {
                Logger.error("[OpenDevClient] Server verification failed: ${e.message}")
            }

            // Step 4: 后端发货确认
            Logger.debug("[OpenDevClient] Step 4: Finishing order on server")
            try {
                httpPaymentService.finishOrder(orderId, transaction.transactionId)
                Logger.debug("[OpenDevClient] Order finished on server")
            } catch (e: Exception) {
                Logger.error("[OpenDevClient] Server finish failed: ${e.message}")
            }

            // Step 5: 客户端确认消费（防止重复发货）
            Logger.debug("[OpenDevClient] Step 5: Finishing transaction on client")
            try {
                clientPaymentAdapter.finishTransaction(transaction.transactionId)
                Logger.debug("[OpenDevClient] Client transaction finished")
            } catch (e: Exception) {
                Logger.error("[OpenDevClient] Client finish failed: ${e.message}")
            }

            nativeResult
        } catch (e: Exception) {
            Logger.error("[OpenDevClient] Full purchase flow failed: ${e.message}")
            PurchaseResult.Failure(
                errorCode = "PURCHASE_FLOW_FAILED",
                errorMessage = e.message ?: "Purchase flow failed",
                productId = nativeProductId
            )
        }
    }

    /**
     * Desktop / Web 浏览器支付流程。
     *
     * 1. 调用后端 `checkout/init` 获取收银台相对路径
     * 2. 拼接 `apiBaseUrl` 得到完整 URL
     * 3. 通过平台适配器打开浏览器
     *
     * JS SDK 参考实现：
     * ```js
     * if (checkoutUrl.startsWith("/")) checkoutUrl = apiBaseUrl + checkoutUrl;
     * window.open(checkoutUrl, "_blank");
     * ```
     */
    suspend fun purchaseViaBrowser(
        serverProductId: String,
        successUrl: String? = null,
        cancelUrl: String? = null
    ): BrowserCheckoutResult = requireInit {
        try {
            Logger.debug("[OpenDevClient] Starting browser checkout for $serverProductId")
            val checkout = httpPaymentService.initCheckout(serverProductId, successUrl, cancelUrl)
            var checkoutUrl = checkout.checkoutUrl

            if (checkoutUrl.startsWith("/")) {
                val baseUrl = config.apiBaseUrl.trimEnd('/')
                checkoutUrl = "$baseUrl$checkoutUrl"
            }
            Logger.debug("[OpenDevClient] Full checkout URL: $checkoutUrl")

            setBrowserCheckoutUrl(checkoutUrl)
            clientPaymentAdapter.purchaseProduct(serverProductId)

            BrowserCheckoutResult.Opened(
                orderId = checkout.orderId,
                checkoutUrl = checkoutUrl,
                productId = serverProductId
            )
        } catch (e: Exception) {
            Logger.error("[OpenDevClient] Browser checkout failed: ${e.message}")
            BrowserCheckoutResult.Failed(
                errorCode = "CHECKOUT_FAILED",
                errorMessage = e.message ?: "Checkout failed"
            )
        }
    }

    /**
     * 轮询后端订单状态（浏览器收银台场景）。
     *
     * 使用公开接口 `GET /v1/payment/order/status/:orderId`（与 `checkout.html` 一致），
     * **不**使用需校验订单归属的 `GET /v1/payment/status/:orderId`，否则在
     * checkout 订单 userId 与当前登录用户不一致时会 403。
     */
    suspend fun pollOrderStatus(orderId: String): OrderPollResult = requireInit {
        try {
            val pub = httpPaymentService.queryPublicOrderStatus(orderId)
            Logger.debug("[OpenDevClient] Order $orderId public status: ${pub.status} completed=${pub.completed}")
            val effectiveStatus =
                if (pub.completed || pub.status == "completed") {
                    "completed"
                } else {
                    pub.status
                }
            when (effectiveStatus) {
                "completed" -> OrderPollResult.Completed(orderId)
                "failed" -> OrderPollResult.Failed(orderId, "Payment failed")
                "cancelled" -> OrderPollResult.Failed(orderId, "Payment cancelled")
                "expired" -> OrderPollResult.Failed(orderId, "Order expired")
                "refunded" -> OrderPollResult.Failed(orderId, "Payment refunded")
                else -> OrderPollResult.Pending(orderId, pub.status)
            }
        } catch (e: Exception) {
            Logger.error("[OpenDevClient] Poll order status failed: ${e.message}")
            OrderPollResult.Error(e.message ?: "Network error")
        }
    }

    private fun setBrowserCheckoutUrl(url: String) {
        clientPaymentAdapter.setBrowserCheckoutUrl(url)
    }

    private fun buildReceiptData(transaction: Transaction): Map<String, String> {
        val data = mutableMapOf<String, String>()
        transaction.purchaseToken?.let { data["purchaseToken"] = it }
        transaction.receipt?.let { data["receipt"] = it }
        transaction.signature?.let { data["signature"] = it }
        data["transactionId"] = transaction.transactionId
        data["productId"] = transaction.productId
        return data
    }

    // ==================== 服务端支付 API ====================

    suspend fun createPaymentOrder(request: CreatePaymentRequest): PaymentOrder =
        requireInit { paymentManager.createPaymentOrder(request) }

    suspend fun performPayment(request: PaymentRequest): PaymentResult =
        requireInit { paymentManager.performPayment(request) }

    suspend fun queryPaymentStatus(orderId: String): PaymentStatus =
        requireInit { paymentManager.queryPaymentStatus(orderId) }

    suspend fun requestRefund(refundRequest: RefundRequest): RefundResult =
        requireInit { paymentManager.requestRefund(refundRequest) }

    suspend fun getPaymentMethods(): List<PaymentMethod> =
        requireInit { paymentManager.getPaymentMethods() }

    /** 仅本地缓存（SWR 首屏）；Desktop / Android / iOS 共用同一套 core 实现。 */
    suspend fun readCachedPaymentHistory(userId: String, limit: Int = 20): List<PaymentOrder> =
        requireInit { paymentManager.readCachedPaymentHistory(userId, limit) }

    /** 拉取服务端并写入本地；失败抛异常。 */
    suspend fun syncPaymentHistoryFromServer(userId: String, limit: Int = 20): List<PaymentOrder> =
        requireInit { paymentManager.syncPaymentHistoryFromServer(userId, limit) }

    /** 网络优先，失败回退缓存（单次原子语义）。 */
    suspend fun getPaymentHistory(userId: String, limit: Int = 20): List<PaymentOrder> =
        requireInit { paymentManager.getPaymentHistory(userId, limit) }

    suspend fun handlePaymentCallback(callbackData: String): Boolean =
        requireInit { paymentManager.handlePaymentCallback(callbackData) }

    // ==================== 客户端原生支付 API（低级别） ====================

    suspend fun fetchProducts(productIds: List<String>): ProductQueryResult =
        requireInit { clientPaymentAdapter.fetchProducts(productIds) }

    suspend fun purchaseProduct(productId: String): PurchaseResult =
        requireInit { clientPaymentAdapter.purchaseProduct(productId) }

    suspend fun restorePurchases(): RestoreResult =
        requireInit { clientPaymentAdapter.restorePurchases() }

    suspend fun checkPurchaseStatus(productId: String): PurchaseStatusResult =
        requireInit { clientPaymentAdapter.checkPurchaseStatus(productId) }

    suspend fun finishTransaction(transactionId: String): TransactionFinishResult =
        requireInit { clientPaymentAdapter.finishTransaction(transactionId) }

    suspend fun getPendingTransactionIds(): PendingTransactionsResult =
        requireInit { clientPaymentAdapter.getPendingTransactionIds() }

    suspend fun isTransactionFinished(transactionId: String): Boolean =
        requireInit { clientPaymentAdapter.isTransactionFinished(transactionId) }

    // ==================== 配置管理 API ====================

    suspend fun downloadConfig(
        baseUrl: String,
        token: String,
        environment: ConfigEnvironment,
        channelKey: String? = null,
        onSuccess: (SDKConfig) -> Unit,
        onError: (Throwable) -> Unit
    ) {
        requireInit {
            configService.downloadConfig(
                baseUrl = baseUrl, token = token, environment = environment,
                platform = currentPlatform.toConfigPlatform(),
                channelKey = channelKey, onSuccess = onSuccess, onError = onError
            )
        }
    }

    suspend fun downloadConfigSync(
        baseUrl: String,
        token: String,
        environment: ConfigEnvironment,
        channelKey: String? = null
    ): SDKConfig {
        return requireInit {
            var result: SDKConfig? = null
            var error: Throwable? = null
            configService.downloadConfig(
                baseUrl = baseUrl, token = token, environment = environment,
                platform = currentPlatform.toConfigPlatform(),
                channelKey = channelKey,
                onSuccess = { result = it },
                onError = { error = it }
            )
            result ?: throw error ?: Exception("Unknown error")
        }
    }

    suspend fun readConfig(
        platform: ConfigPlatform,
        environment: ConfigEnvironment,
        channelKey: String? = null,
        filePath: String? = null,
        encryptionKey: String? = null
    ): Result<SDKConfig> = runCatching {
        configService.readLocalConfig(
            platform = platform, environment = environment,
            channelKey = channelKey, filePath = filePath, encryptionKey = encryptionKey
        )
    }

    // ==================== 工具方法 ====================

    fun getCurrentPlatform(): Platform = currentPlatform

    fun getVersion(): String = VERSION

    fun getConfig(): PlatformConfig = config

    fun getPrivacyPolicyUrl(): String = config.privacyPolicyUrl

    fun getTermsOfUseUrl(): String = config.termsOfUseUrl

    suspend fun isAuthProviderSupported(provider: ThirdPartyProvider): Boolean =
        requireInit { authAdapter.isProviderAvailable(provider) }

    suspend fun isPaymentMethodSupported(paymentMethod: PaymentMethodType): Boolean =
        requireInit { paymentAdapters[paymentMethod]?.isPaymentMethodAvailable(paymentMethod) ?: false }

    suspend fun getSDKStatus(): SDKStatus {
        val initialized = _initializationState.value == InitializationState.Initialized
        return SDKStatus(
            isInitialized = initialized,
            platform = currentPlatform,
            version = VERSION,
            hasAuthAdapter = true,
            hasPaymentAdapters = paymentAdapters.isNotEmpty(),
            supportedAuthProviders = if (initialized) {
                runCatching { authAdapter.getSupportedProviders() }.getOrElse { emptyList() }
            } else emptyList(),
            supportedPaymentMethods = if (initialized) paymentAdapters.keys.toList() else emptyList()
        )
    }

    fun cleanup() {
        Logger.debug("[OpenDevClient] cleanup() called")
        autoLoginScope.cancel()
        isAutoLoginEnabled = false
        previousLoginState = null
        isInitialLogin = true
        isManualSwitching = false
        _initializationState.value = InitializationState.NotInitialized
        _loginState.value = LoginState.Idle
        _currentUser.value = null
        _showLoginDialog.value = null
        scope.launch {
            runCatching {
                authManager.cleanup()
                paymentManager.cleanup()
                authAdapter.cleanup()
                paymentAdapters.values.forEach { it.cleanup() }
                clientPaymentAdapter.cleanup()
            }
        }
        instance = null
        Logger.debug("[OpenDevClient] cleanup completed")
    }

    // ==================== 私有辅助方法 ====================

    private fun startAutoLoginListener() {
        if (isAutoLoginEnabled) return
        isAutoLoginEnabled = true
        previousLoginState = _loginState.value
        isInitialLogin = true

        autoLoginScope.launch {
            _loginState.collectLatest { currentState ->
                val wasLoggedIn = previousLoginState is LoginState.LoggedIn
                val wasLoggingIn = previousLoginState is LoginState.LoggingIn
                val wasLoginFailed = previousLoginState is LoginState.LoginFailed
                val isNowIdle = currentState is LoginState.Idle

                val shouldTrigger = !isInitialLogin && !isManualSwitching && isNowIdle &&
                    (wasLoggedIn || wasLoggingIn || wasLoginFailed)

                if (shouldTrigger) {
                    Logger.debug("[OpenDevClient] Detected logout, triggering automatic login...")
                    loginUI { result ->
                        result.onSuccess { if (it is AuthResult.Success) Logger.debug("[OpenDevClient] Auto login successful") }
                            .onFailure { Logger.error("[OpenDevClient] Auto login failed: ${it.message}") }
                    }
                }

                previousLoginState = currentState
                if (isInitialLogin && (currentState is LoginState.LoggedIn || currentState is LoginState.LoginFailed)) {
                    delay(100)
                    isInitialLogin = false
                }
            }
        }
    }

    private fun syncUserProfileFromServer() {
        val localUser = _currentUser.value ?: return
        scope.launch {
            try {
                val result = authManager.refreshToken()
                if (result is AuthResult.Success && result.user != null) {
                    val serverUser = result.user
                    if (serverUser != localUser) {
                        authManager.updateLocalUser(serverUser)
                        _currentUser.value = serverUser
                        val method = resolveLoginMethod(serverUser) ?: LoginMethod.GUEST
                        _loginState.value = LoginState.LoggedIn(serverUser, method)
                        Logger.debug("[OpenDevClient] User profile synced from server")
                    }
                }
            } catch (e: Exception) {
                Logger.debug("[OpenDevClient] Background profile sync skipped: ${e.message}")
            }
        }
    }

    private suspend fun refreshLoginStateInternal() {
        val loggedIn = runCatching { authManager.isLoggedIn() }.getOrElse { false }
        if (loggedIn) {
            val user = runCatching { authManager.getCurrentUser() }.getOrNull()
            _currentUser.value = user
            _loginState.value = LoginState.LoggedIn(user, resolveLoginMethod(user) ?: LoginMethod.GUEST)
        } else {
            _currentUser.value = null
            _loginState.value = LoginState.Idle
        }
    }

    private suspend fun performAuthCall(
        method: LoginMethod,
        block: suspend () -> AuthResult
    ): Result<AuthResult> = runCatching {
        _loginState.value = LoginState.LoggingIn
        loginMutex.withLock {
            val result = block()
            handleAuthResult(result, method)
            result
        }
    }.onFailure { error ->
        Logger.error("[OpenDevClient] Auth call failed: ${error.message}")
        _loginState.value = LoginState.LoginFailed(error.message ?: "Unknown error")
    }

    private fun handleAuthResult(result: AuthResult, method: LoginMethod) {
        when (result) {
            is AuthResult.Success -> {
                _currentUser.value = result.user
                _loginState.value = LoginState.LoggedIn(result.user, resolveLoginMethod(result.user) ?: method)
            }
            is AuthResult.Failure -> _loginState.value = LoginState.LoginFailed(result.error.name)
            is AuthResult.Pending -> _loginState.value = LoginState.LoginFailed(result.message)
            is AuthResult.MultipleAccounts -> _loginState.value = LoginState.AccountSelection(
                users = result.users,
                method = method,
                sourceMethod = method
            )
            is AuthResult.Unlinked -> {
                Logger.error("[OpenDevClient] Unlinked reached handleAuthResult (auto-register should have handled this)")
                _loginState.value = LoginState.LoginFailed("PROVIDER_NOT_LINKED")
            }
            is AuthResult.Cancelled -> _loginState.value = LoginState.Idle
        }
    }

    private fun resolveLoginMethod(user: User?): LoginMethod? {
        if (user == null) return null
        return when (user.loginType) {
            LoginType.GUEST -> LoginMethod.GUEST
            LoginType.OTP -> {
                if (user.email != null) LoginMethod.EMAIL else LoginMethod.PHONE
            }
            LoginType.THIRD_PARTY, LoginType.BOUND -> {
                val first = user.boundAccounts.firstOrNull()
                when (first?.provider) {
                    ThirdPartyProvider.FACEBOOK -> LoginMethod.FACEBOOK
                    ThirdPartyProvider.GOOGLE -> LoginMethod.GOOGLE
                    ThirdPartyProvider.APPLE -> LoginMethod.APPLE
                    ThirdPartyProvider.WECHAT -> LoginMethod.WECHAT
                    ThirdPartyProvider.QQ -> LoginMethod.QQ
                    null -> when (first?.providerType) {
                        "phone" -> LoginMethod.PHONE
                        "email" -> LoginMethod.EMAIL
                        else -> null
                    }
                }
            }
        }
    }

    private fun shouldReadConfigFromFile(config: PlatformConfig): Boolean {
        return (config.cdnBaseUrl.isNotEmpty() || config.channelKey.isNotEmpty()) &&
            config.facebookAppId.isEmpty() && config.googleClientId.isEmpty() &&
            config.wechatAppId.isEmpty() && config.apiBaseUrl.isEmpty() && config.appId.isEmpty()
    }

    private suspend fun loadOAuthConfigWithCache() {
        if (config.appId.isEmpty() || config.apiBaseUrl.isEmpty()) return

        oauthConfigCache.setOnConfigUpdated { resp ->
            enrichConfigFromCachedResponse(resp)
        }

        val channelKey = config.channelKey.takeIf { it.isNotEmpty() }
        val cached = oauthConfigCache.loadFromLocal()
        if (cached != null) {
            enrichConfigFromCachedResponse(cached)
            oauthConfigCache.refreshAsync(config.appId, channelKey)
        } else {
            val fetched = oauthConfigCache.fetchFromServer(config.appId, channelKey)
            if (fetched != null) {
                enrichConfigFromCachedResponse(fetched)
            }
        }
    }

    private fun enrichConfigFromCachedResponse(resp: OAuthConfigResponse) {
        val c = resp.configs
        val p = resp.publisher
        val enriched = config.copy(
            googleClientId = config.googleClientId.ifEmpty { c.google?.clientId ?: "" },
            facebookAppId = config.facebookAppId.ifEmpty { c.facebook?.appId ?: "" },
            appleClientId = config.appleClientId.ifEmpty { c.apple?.clientId ?: "" },
            wechatAppId = config.wechatAppId.ifEmpty { c.wechat?.appId ?: "" },
            privacyPolicyUrl = config.privacyPolicyUrl.ifEmpty { p?.privacyPolicyUrl ?: "" },
            termsOfUseUrl = config.termsOfUseUrl.ifEmpty { p?.termsOfUseUrl ?: "" }
        )
        if (enriched != config) {
            config = enriched
            authAdapter.updateConfig(enriched)
            Logger.debug("[OpenDevClient] Config enriched from OAuth config cache")
        }
    }

    private fun logConfigDiagnostic() {
        val tag = "[OpenDevClient]"
        Logger.debug("$tag ========== Config Diagnostic ==========")
        Logger.debug("$tag version=$VERSION, platform=${currentPlatform.name}")
        Logger.debug("$tag appId=${config.appId.ifEmpty { "(pending)" }}, channelKey=${config.channelKey}")
        Logger.debug("$tag environment=${config.environment}, guestLoginEnabled=${config.guestLoginEnabled}")
        Logger.debug("$tag apiBaseUrl=${config.apiBaseUrl.ifEmpty { "(from CDN)" }}")
        Logger.debug("$tag cdnBaseUrl=${config.cdnBaseUrl.take(60)}...")
        Logger.debug("$tag autoConfigureFromServer=${config.autoConfigureFromServer}")
        val cached = oauthConfigCache.current
        if (cached != null) {
            Logger.debug("$tag oauthConfig (cached): appId=${cached.appId}, channelKey=${cached.channelKey}")
            val c = cached.configs
            Logger.debug("$tag   google=${c.google}, facebook=${c.facebook}, apple=${c.apple}")
            Logger.debug("$tag   wechat=${c.wechat}, qq=${c.qq}, phone=${c.phone}, email=${c.email}")
            Logger.debug("$tag   availableProviders=${c.availableOAuthProviders()}, otpMethods=${c.availableOtpMethods()}")
        } else {
            Logger.debug("$tag oauthConfig: (no cache)")
        }
        Logger.debug("$tag ========== End Config Diagnostic ==========")
    }

    private suspend inline fun <T> requireInit(block: () -> T): T {
        check(_initializationState.value == InitializationState.Initialized) {
            "OpenDevClient not initialized. Call initialize() first."
        }
        return block()
    }
}

// ==================== 状态类定义 ====================

sealed class InitializationState {
    object NotInitialized : InitializationState()
    object Initializing : InitializationState()
    object Initialized : InitializationState()
    data class Failed(val error: String) : InitializationState()
}

sealed class LoginState {
    object Idle : LoginState()
    object LoggingIn : LoginState()
    data class LoggedIn(val user: User?, val method: LoginMethod) : LoginState()
    data class LoginFailed(val error: String) : LoginState()
    data class AccountSelection(
        val users: List<User>,
        val method: LoginMethod,
        val sourceMethod: LoginMethod? = null
    ) : LoginState()
}

data class LoginUIDialogState(
    val onResult: (Result<AuthResult>) -> Unit
)

data class AvailableLoginMethods(
    val guestEnabled: Boolean,
    val thirdPartyProviders: List<ThirdPartyProvider>,
    val otpMethods: List<LoginMethod>
)

enum class LoginMethod {
    GUEST, FACEBOOK, GOOGLE, APPLE, WECHAT, QQ, PHONE, EMAIL;

    fun toThirdPartyProvider(): ThirdPartyProvider? = when (this) {
        FACEBOOK -> ThirdPartyProvider.FACEBOOK
        GOOGLE -> ThirdPartyProvider.GOOGLE
        APPLE -> ThirdPartyProvider.APPLE
        WECHAT -> ThirdPartyProvider.WECHAT
        QQ -> ThirdPartyProvider.QQ
        GUEST, PHONE, EMAIL -> null
    }

    fun isThirdParty(): Boolean = when (this) {
        FACEBOOK, GOOGLE, APPLE, WECHAT, QQ -> true
        GUEST, PHONE, EMAIL -> false
    }

    fun isOtp(): Boolean = this == PHONE || this == EMAIL
}

data class TokenInfo(
    val sessionToken: String,
    val jwtToken: String?,
    val expiresAt: Long?
)

data class SDKStatus(
    val isInitialized: Boolean,
    val platform: Platform,
    val version: String,
    val hasAuthAdapter: Boolean,
    val hasPaymentAdapters: Boolean,
    val supportedAuthProviders: List<ThirdPartyProvider>,
    val supportedPaymentMethods: List<PaymentMethodType>
)
