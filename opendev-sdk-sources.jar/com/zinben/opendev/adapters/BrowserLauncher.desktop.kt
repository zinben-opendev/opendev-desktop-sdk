package com.zinben.opendev.adapters

import com.zinben.opendev.logger.Logger
import java.awt.Desktop
import java.net.URI

actual object BrowserLauncher {
    actual fun openUrl(url: String) {
        runCatching {
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().browse(URI(url))
                Logger.debug("BrowserLauncher: Opened $url")
            } else {
                Logger.error("BrowserLauncher: Desktop browse not supported for $url")
            }
        }.onFailure { error ->
            Logger.error("BrowserLauncher: Failed to open $url -> ${error.message}")
        }
    }
}

