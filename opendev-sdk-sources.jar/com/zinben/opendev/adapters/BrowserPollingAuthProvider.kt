package com.zinben.opendev.adapters

import com.zinben.opendev.logger.Logger
import com.zinben.opendev.network.ApiResponseWrapper
import com.zinben.opendev.network.URLSession
import com.zinben.opendev.factories.PlatformConfig
import com.zinben.opendev.models.PlatformAuthResult
import com.zinben.opendev.models.PlatformUserInfo
import com.zinben.opendev.models.ThirdPartyProvider
import com.zinben.opendev.models.toApiType
import com.zinben.opendev.models.toThirdPartyProviderOrNull
import io.ktor.client.call.body
import io.ktor.client.request.get
import io.ktor.client.request.parameter
import kotlinx.coroutines.delay
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlin.random.Random

private const val DEFAULT_BASE_URL = "http://localhost:3000"
private const val POLL_INTERVAL_MS = 5000L
private const val MAX_ATTEMPTS = 30

internal class BrowserPollingAuthProvider(
    private var config: PlatformConfig,
    private val deviceIdProvider: suspend () -> String = { "" }
) {
    private var providerHandlers = buildHandlers()
    private val userInfoCache = mutableMapOf<ThirdPartyProvider, PlatformUserInfo>()

    fun updateConfig(newConfig: PlatformConfig) {
        config = newConfig
        providerHandlers = buildHandlers()
    }

    suspend fun initializeSDK() {
        // 预留SDK初始化扩展点，目前无需操作
    }

    suspend fun cleanup() {
        userInfoCache.clear()
    }

    suspend fun authenticate(
        provider: ThirdPartyProvider,
        userId: String? = null
    ): PlatformAuthResult {
        val handler = providerHandlers[provider]
            ?: return PlatformAuthResult.Failure(
                errorCode = "UNSUPPORTED_PROVIDER",
                errorMessage = "Provider $provider is not supported on this platform"
            )
        val result = handler.authenticate(userId)
        if (result is PlatformAuthResult.Success) {
            userInfoCache[provider] = result.userInfo
        }
        return result
    }

    fun getUserInfo(provider: ThirdPartyProvider): PlatformUserInfo? {
        return userInfoCache[provider]
    }

    fun isProviderAvailable(provider: ThirdPartyProvider): Boolean {
        return providerHandlers[provider]?.isAvailable() ?: false
    }

    fun getSupportedProviders(): List<ThirdPartyProvider> {
        return providerHandlers.filterValues { it.isAvailable() }.keys.toList()
    }

    private fun buildHandlers(): Map<ThirdPartyProvider, ProviderAuthHandler> {
        val pollingClient = AuthPollingClient(apiBaseUrl())
        return mapOf(
            ThirdPartyProvider.FACEBOOK to FacebookAuthHandler(config, pollingClient, deviceIdProvider),
            ThirdPartyProvider.GOOGLE to GoogleAuthHandler(config, pollingClient, deviceIdProvider),
            ThirdPartyProvider.WECHAT to WeChatAuthHandler(config, pollingClient, deviceIdProvider),
            ThirdPartyProvider.APPLE to AppleAuthHandler(config, pollingClient, deviceIdProvider)
        )
    }

    private fun apiBaseUrl(): String {
        return config.apiBaseUrl.takeIf { it.isNotBlank() }?.trimEnd('/') ?: DEFAULT_BASE_URL
    }
}

private interface ProviderAuthHandler {
    val provider: ThirdPartyProvider
    fun isAvailable(): Boolean
    suspend fun authenticate(userId: String?): PlatformAuthResult
}

private abstract class BrowserPollingAuthHandler(
    override val provider: ThirdPartyProvider,
    private val pollingClient: AuthPollingClient,
    private val deviceIdProvider: suspend () -> String
) : ProviderAuthHandler {

    abstract val requiredParamValue: String?
    abstract fun buildAuthUrl(userId: String): String

    override fun isAvailable(): Boolean = !requiredParamValue.isNullOrBlank()

    override suspend fun authenticate(userId: String?): PlatformAuthResult {
        if (!isAvailable()) {
            return PlatformAuthResult.Failure(
                errorCode = "CONFIG_UNAVAILABLE",
                errorMessage = "$provider is not configured for this platform"
            )
        }
        val oauthSessionId = userId?.takeIf { it.isNotBlank() } ?: generateOAuthSessionId()
        Logger.debug("BrowserPollingAuthHandler: OAuth session for $provider, sessionId=$oauthSessionId")
        val authUrl = buildAuthUrl(oauthSessionId)
        BrowserLauncher.openUrl(authUrl)
        val info = pollingClient.awaitAuthorization(provider, oauthSessionId)
            ?: return PlatformAuthResult.Failure(
                errorCode = "AUTH_TIMEOUT",
                errorMessage = "$provider authorization timed out"
            )
        return PlatformAuthResult.Success(
            providerUserId = info.providerUserId,
            accessToken = info.accessToken.orEmpty(),
            userInfo = info.userInfo
        )
    }
}

private class FacebookAuthHandler(
    private val config: PlatformConfig,
    pollingClient: AuthPollingClient,
    deviceIdProvider: suspend () -> String
) : BrowserPollingAuthHandler(ThirdPartyProvider.FACEBOOK, pollingClient, deviceIdProvider) {
    override val requiredParamValue: String? = config.facebookAppId.takeIf { it.isNotBlank() }

    override fun buildAuthUrl(userId: String): String {
        val base = config.apiBaseUrl.takeIf { it.isNotBlank() }?.trimEnd('/') ?: DEFAULT_BASE_URL
        val appIdParam = config.appId.takeIf { it.isNotBlank() }?.let { "&appId=$it" } ?: ""
        return "$base/oauth/fb?fb_appid=${requiredParamValue}&user_id=$userId$appIdParam"
    }
}

private class GoogleAuthHandler(
    private val config: PlatformConfig,
    pollingClient: AuthPollingClient,
    deviceIdProvider: suspend () -> String
) : BrowserPollingAuthHandler(ThirdPartyProvider.GOOGLE, pollingClient, deviceIdProvider) {
    override val requiredParamValue: String? = config.googleClientId.takeIf { it.isNotBlank() }

    override fun buildAuthUrl(userId: String): String {
        val base = config.apiBaseUrl.takeIf { it.isNotBlank() }?.trimEnd('/') ?: DEFAULT_BASE_URL
        val appIdParam = config.appId.takeIf { it.isNotBlank() }?.let { "&appId=$it" } ?: ""
        return "$base/oauth/google?g_client_id=${requiredParamValue}&user_id=$userId$appIdParam"
    }
}

private class WeChatAuthHandler(
    private val config: PlatformConfig,
    pollingClient: AuthPollingClient,
    deviceIdProvider: suspend () -> String
) : BrowserPollingAuthHandler(ThirdPartyProvider.WECHAT, pollingClient, deviceIdProvider) {
    override val requiredParamValue: String? = config.wechatAppId.takeIf { it.isNotBlank() }

    override fun buildAuthUrl(userId: String): String {
        val base = config.apiBaseUrl.takeIf { it.isNotBlank() }?.trimEnd('/') ?: DEFAULT_BASE_URL
        val appIdParam = config.appId.takeIf { it.isNotBlank() }?.let { "&appId=$it" } ?: ""
        return "$base/oauth/wechat?wechat_appid=$requiredParamValue&user_id=$userId$appIdParam"
    }
}

private class AppleAuthHandler(
    private val config: PlatformConfig,
    pollingClient: AuthPollingClient,
    deviceIdProvider: suspend () -> String
) : BrowserPollingAuthHandler(ThirdPartyProvider.APPLE, pollingClient, deviceIdProvider) {
    override val requiredParamValue: String? = config.appleClientId.takeIf { it.isNotBlank() }

    override fun buildAuthUrl(userId: String): String {
        val base = config.apiBaseUrl.takeIf { it.isNotBlank() }?.trimEnd('/') ?: DEFAULT_BASE_URL
        val appIdParam = config.appId.takeIf { it.isNotBlank() }?.let { "&appId=$it" } ?: ""
        return "$base/oauth/apple?apple_client_id=$requiredParamValue&user_id=$userId$appIdParam"
    }
}

private class StubAuthHandler(
    override val provider: ThirdPartyProvider
) : ProviderAuthHandler {
    override fun isAvailable(): Boolean = false

    override suspend fun authenticate(userId: String?): PlatformAuthResult {
        return PlatformAuthResult.Failure(
            errorCode = "NOT_IMPLEMENTED",
            errorMessage = "$provider authentication is not implemented yet"
        )
    }
}

/**
 * Generates a unique OAuth session ID for browser-based authentication.
 * Aligned with JS SDK's generateOAuthSessionId() — produces a one-time
 * identifier that is independent of login state or device identity.
 */
private fun generateOAuthSessionId(): String {
    val randomBytes = Random.nextBytes(16)
    val hex = randomBytes.joinToString("") { it.toUByte().toString(16).padStart(2, '0') }
    return "oauth_$hex"
}

private class AuthPollingClient(
    private val baseUrl: String
) {
    suspend fun awaitAuthorization(
        provider: ThirdPartyProvider,
        userId: String
    ): AuthResultPayload? {
        repeat(MAX_ATTEMPTS) {
            val payload = fetchPayload(provider, userId)
            val item = payload?.payloads?.maxByOrNull { it.updatedAt ?: it.createdAt ?: "" }
            if (item != null) {
                val info = item.toPlatformUserInfo(provider) ?: return null
                val accessToken = item.extractAccessToken()
                return AuthResultPayload(
                    providerUserId = info.providerUserId,
                    accessToken = accessToken,
                    userInfo = info
                )
            }
            delay(POLL_INTERVAL_MS)
        }
        return null
    }

    private suspend fun fetchPayload(
        provider: ThirdPartyProvider,
        userId: String
    ): AuthPayloadResponse? {
        return runCatching {
            val response = URLSession.get("$baseUrl/auth/payload") {
                parameter("user_id", userId)
                parameter("provider", provider.toApiType())
            }.body<ApiResponseWrapper<AuthPayloadResponseData>>()
            
            // 检查响应状态
            if (response.code != 0 || response.data == null) {
                // 对于 404 或业务层面的 "未找到"，视为正常轮询中，保留日志但可根据需要调整级别
                // 为了调试方便，这里保留 404 的 error 日志，如果觉得太吵可以改为 debug 或 warn
                if (response.code == -1 && response.msg.contains("No OAuth payloads")) {
                    Logger.error("AuthPollingClient: Polling... No payload found yet (404).")
                } else {
                    Logger.error("AuthPollingClient: Failed to fetch payload -> code=${response.code}, msg=${response.msg}")
                }
                return@runCatching null
            }
            
            // 转换为内部格式
            val data = response.data
            AuthPayloadResponse(
                userId = data.userId,
                provider = data.provider,
                payloads = data.payloads
            )
        }.onFailure { error ->
            Logger.error("AuthPollingClient: Failed to fetch payload -> ${error.message}")
        }.getOrNull()
    }
}

private data class AuthResultPayload(
    val providerUserId: String,
    val accessToken: String?,
    val userInfo: PlatformUserInfo
)


/**
 * /auth/payload 接口的响应数据（符合接口文档规范）
 */
@Serializable
private data class AuthPayloadResponseData(
    @SerialName("user_id") val userId: String,
    val provider: String? = null,
    val payloads: List<AuthPayloadItem> = emptyList()
)

/**
 * 内部使用的响应格式（向后兼容）
 */
private data class AuthPayloadResponse(
    val userId: String,
    val provider: String? = null,
    val payloads: List<AuthPayloadItem> = emptyList()
)

@Serializable
private data class AuthPayloadItem(
    val provider: String? = null,
    @SerialName("user_id") val userId: String? = null,
    val email: String? = null,
    val name: String? = null,
    @SerialName("raw_payload") val rawPayload: JsonElement? = null,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null
)

private fun AuthPayloadItem.toPlatformUserInfo(
    fallbackProvider: ThirdPartyProvider
): PlatformUserInfo? {
    val provider = provider?.toThirdPartyProviderOrNull() ?: fallbackProvider
    val raw = rawPayload?.jsonObject
    val providerUserId = when (provider) {
        ThirdPartyProvider.GOOGLE -> raw?.stringValue("sub")
        ThirdPartyProvider.APPLE -> raw?.stringValue("sub")
        ThirdPartyProvider.FACEBOOK -> raw?.stringValue("id")
        ThirdPartyProvider.WECHAT -> raw?.stringValue("unionid") ?: raw?.stringValue("openid")
        ThirdPartyProvider.QQ -> raw?.stringValue("openid")
    } ?: return null
    val emailValue = email ?: raw?.stringValue("email")
    val nameValue = name ?: raw?.stringValue("name")
    val avatar = raw?.extractAvatar()
    return PlatformUserInfo(
        providerUserId = providerUserId,
        username = nameValue,
        email = emailValue,
        avatar = avatar,
        nickname = nameValue,
        provider = provider
    )
}

private fun AuthPayloadItem.extractAccessToken(): String? {
    val raw = rawPayload?.jsonObject ?: return null
    val tokens = raw["tokens"] as? JsonObject
    val tokenFromTokens = tokens?.stringValue("accessToken")
        ?: tokens?.stringValue("access_token")
        ?: tokens?.stringValue("token")
    return tokenFromTokens
        ?: raw.stringValue("access_token")
        ?: raw.stringValue("accessToken")
        ?: raw.stringValue("token")
        ?: raw.stringValue("accessTokenString")
}

private fun JsonObject.extractAvatar(): String? {
    val picture = this["picture"] ?: return null
    if (picture is JsonObject) {
        val data = picture["data"] as? JsonObject
        return data?.stringValue("url")
    }
    return picture.jsonPrimitiveOrNull()
}

private fun JsonObject.stringValue(key: String): String? {
    return this[key]?.jsonPrimitiveOrNull()
}

private fun JsonElement.jsonPrimitiveOrNull(): String? {
    return runCatching { this.jsonPrimitive.content }.getOrNull()
}

