package com.zinben.opendev.adapters

import com.zinben.opendev.models.*
import com.zinben.opendev.factories.PlatformConfig
import com.zinben.opendev.logger.Logger

/**
 * Desktop 平台客户端支付适配器
 * 
 * 使用浏览器 Web 支付方式完成支付
 */
actual class ClientPaymentAdapter actual constructor(
    private val config: PlatformConfig
) {
    /** Desktop 支付适配器 */
    private var desktopPaymentAdapter: DesktopPaymentAdapter? = null
    
    /**
     * 获取或创建 Desktop 支付适配器
     */
    private fun getOrCreateAdapter(): DesktopPaymentAdapter {
        if (desktopPaymentAdapter == null) {
            desktopPaymentAdapter = DesktopPaymentAdapter(config)
        }
        return desktopPaymentAdapter!!
    }
    
    actual suspend fun initializeSDK() {
        Logger.debug("[ClientPaymentAdapter.Desktop] Initializing payment SDK")
        getOrCreateAdapter().initializeSDK()
    }

    actual fun setBrowserCheckoutUrl(url: String) {
        getOrCreateAdapter().setPendingCheckoutUrl(url)
    }

    actual suspend fun fetchProducts(productIds: List<String>): ProductQueryResult {
        return getOrCreateAdapter().fetchProducts(productIds)
    }

    actual suspend fun purchaseProduct(productId: String): PurchaseResult {
        return getOrCreateAdapter().purchaseProduct(productId)
    }
    
    actual suspend fun restorePurchases(): RestoreResult {
        return getOrCreateAdapter().restorePurchases()
    }
    
    actual suspend fun checkPurchaseStatus(productId: String): PurchaseStatusResult {
        return getOrCreateAdapter().checkPurchaseStatus(productId)
    }
    
    actual suspend fun finishTransaction(transactionId: String): TransactionFinishResult {
        return getOrCreateAdapter().finishTransaction(transactionId)
    }
    
    actual suspend fun getPendingTransactionIds(): PendingTransactionsResult {
        return getOrCreateAdapter().getPendingTransactionIds()
    }
    
    actual suspend fun isTransactionFinished(transactionId: String): Boolean {
        return getOrCreateAdapter().isTransactionFinished(transactionId)
    }
    
    actual suspend fun cleanup() {
        Logger.debug("[ClientPaymentAdapter.Desktop] Cleaning up payment SDK")
        desktopPaymentAdapter?.cleanup()
        desktopPaymentAdapter = null
    }
}
