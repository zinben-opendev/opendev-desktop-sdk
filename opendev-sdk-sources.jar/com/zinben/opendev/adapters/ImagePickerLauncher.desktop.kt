package com.zinben.opendev.adapters

import com.zinben.opendev.logger.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.awt.FileDialog
import java.awt.Frame
import java.io.File
import java.io.FilenameFilter
import javax.swing.SwingUtilities
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine

actual object ImagePickerLauncher {
    private val imageExtensions = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp")

    actual suspend fun pickImage(): PickedImage? = suspendCancellableCoroutine { cont ->
        SwingUtilities.invokeLater {
            try {
                val dialog = FileDialog(null as Frame?, "Select Image", FileDialog.LOAD).apply {
                    isMultipleMode = false
                    filenameFilter = FilenameFilter { _, name ->
                        name.substringAfterLast('.', "").lowercase() in imageExtensions
                    }
                }
                dialog.isVisible = true

                val dir = dialog.directory
                val name = dialog.file
                if (dir == null || name == null) {
                    cont.resume(null)
                    return@invokeLater
                }
                val file = File(dir, name)
                val bytes = file.readBytes()
                val ext = file.extension.lowercase()
                val mimeType = when (ext) {
                    "png" -> "image/png"
                    "webp" -> "image/webp"
                    "gif" -> "image/gif"
                    "bmp" -> "image/bmp"
                    else -> "image/jpeg"
                }
                Logger.debug("ImagePickerLauncher: Picked ${file.name} (${bytes.size} bytes)")
                cont.resume(PickedImage(bytes = bytes, fileName = file.name, mimeType = mimeType))
            } catch (e: Exception) {
                Logger.error("ImagePickerLauncher: Failed to pick image: ${e.message}")
                cont.resume(null)
            }
        }
    }
}
