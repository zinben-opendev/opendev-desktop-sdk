package com.zinben.opendev.adapters

import com.zinben.opendev.factories.PlatformConfig
import com.zinben.opendev.logger.Logger
import com.zinben.opendev.models.*
import java.awt.Desktop
import java.net.URI

/**
 * Desktop 平台支付适配器
 * 
 * Desktop 平台支付方案：
 * 1. 通过浏览器打开 Web 支付页面完成支付
 * 2. 支付完成后通过回调 URL 或轮询方式确认支付结果
 * 
 * 实际应用中，建议：
 * - 使用 Stripe Checkout 或 PayPal 等 Web 支付方案
 * - 或者使用应用内嵌入的 WebView 完成支付
 * 
 * ## 架构说明
 * 此类是 Desktop 平台的统一支付适配器，实现 PaymentPlatformAdapter 接口以支持服务端支付流程。
 * 同时提供客户端支付方法，由 ClientPaymentAdapter.desktop.kt 委托调用。
 * 
 * 这与 Android/iOS 平台的架构保持一致：
 * - Android: AndroidGooglePlayBillingAdapter
 * - iOS: AppleStoreKitAdapter
 */
class DesktopPaymentAdapter(
    private val config: PlatformConfig
) : PaymentPlatformAdapter {
    private var isInitialized = false
    
    /** 商品缓存 */
    private val productCache = mutableMapOf<String, Product>()
    
    /** 交易记录 */
    private val transactions = mutableMapOf<String, Transaction>()
    private val finishedTransactions = mutableSetOf<String>()

    // ==================== PaymentPlatformAdapter 接口实现 ====================

    override suspend fun initializeSDK() {
        Logger.debug("[DesktopPayment] Initializing Desktop Payment SDK")
        isInitialized = true
    }

    /**
     * 获取商品信息
     */
    suspend fun fetchProducts(productIds: List<String>): ProductQueryResult {
        Logger.debug("[DesktopPayment] Fetching products: $productIds")
        
        if (!isInitialized) {
            return ProductQueryResult.Failure(
                errorCode = "NOT_INITIALIZED",
                errorMessage = "Desktop Payment not initialized"
            )
        }
        
        try {
            // 模拟商品数据（实际应用中应从后端 API 获取）
            val products = productIds.map { productId ->
                val product = createMockProduct(productId)
                productCache[productId] = product
                product
            }
            
            return ProductQueryResult.Success(products)
        } catch (e: Exception) {
            Logger.error("[DesktopPayment] Fetch products failed: ${e.message}")
            return ProductQueryResult.Failure(
                errorCode = "FETCH_FAILED",
                errorMessage = "Failed to fetch products: ${e.message}"
            )
        }
    }
    
    /**
     * 创建模拟商品
     */
    private fun createMockProduct(productId: String): Product {
        val (price, name, description) = when {
            productId.contains("monthly") -> Triple("9.99", "月度会员", "解锁所有高级功能，每月自动续费")
            productId.contains("yearly") -> Triple("99.99", "年度会员", "解锁所有高级功能，每年自动续费")
            productId.contains("lifetime") -> Triple("299.99", "终身会员", "一次性购买，永久使用")
            else -> Triple("1.99", "测试商品", "测试商品描述")
        }
        
        return Product(
            id = productId,
            name = name,
            description = description,
            price = Money(price),
            currency = "USD",
            type = if (productId.contains("subscription") || productId.contains("monthly") || productId.contains("yearly")) {
                ProductType.SUBSCRIPTION
            } else {
                ProductType.NON_CONSUMABLE
            },
            platform = Platform.DESKTOP,
            isAvailable = true,
            localizedPrice = "$$price"
        )
    }

    /**
     * 购买商品
     *
     * Desktop 平台通过打开浏览器完成支付。
     * 优先使用 [pendingCheckoutUrl]（由 [OpenDevClient.purchaseViaBrowser] 设置），
     * 若未设置则回退到自行构建 URL。
     */
    suspend fun purchaseProduct(productId: String): PurchaseResult {
        Logger.debug("[DesktopPayment] Purchasing product: $productId")

        if (!isInitialized) {
            return PurchaseResult.Failure(
                errorCode = "NOT_INITIALIZED",
                errorMessage = "Desktop Payment not initialized",
                productId = productId
            )
        }

        try {
            if (!Desktop.isDesktopSupported() || !Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                return PurchaseResult.Failure(
                    errorCode = "BROWSER_NOT_SUPPORTED",
                    errorMessage = "Cannot open browser for payment",
                    productId = productId
                )
            }

            val url = consumePendingCheckoutUrl()
                ?: buildFallbackPaymentUrl(productId)

            Desktop.getDesktop().browse(URI(url))
            Logger.debug("[DesktopPayment] Opened payment page: $url")

            return PurchaseResult.Pending(
                productId = productId,
                message = "请在浏览器中完成支付"
            )
        } catch (e: Exception) {
            Logger.error("[DesktopPayment] Purchase failed: ${e.message}")
            return PurchaseResult.Failure(
                errorCode = "PURCHASE_FAILED",
                errorMessage = e.message ?: "Purchase failed",
                productId = productId
            )
        }
    }

    // -- checkout URL 传递机制 --

    @Volatile
    private var pendingCheckoutUrl: String? = null

    fun setPendingCheckoutUrl(url: String) {
        pendingCheckoutUrl = url
    }

    private fun consumePendingCheckoutUrl(): String? {
        val url = pendingCheckoutUrl
        pendingCheckoutUrl = null
        return url
    }

    private fun buildFallbackPaymentUrl(productId: String): String {
        val baseUrl = config.apiBaseUrl.trimEnd('/')
        return "$baseUrl/payment/html/checkout.html?productId=$productId&appId=${config.appId}"
    }

    /**
     * 模拟确认支付（用于测试）
     */
    suspend fun confirmPayment(productId: String): PurchaseResult {
        val product = productCache[productId] ?: return PurchaseResult.Failure(
            errorCode = "PRODUCT_NOT_FOUND",
            errorMessage = "Product not found",
            productId = productId
        )
        
        val transactionId = "desktop_${System.currentTimeMillis()}_$productId"
        val transaction = Transaction(
            transactionId = transactionId,
            productId = productId,
            userId = "",
            platform = Platform.DESKTOP,
            purchaseTime = System.currentTimeMillis(),
            originalTransactionId = transactionId,
            isRestored = false,
            isFinished = false
        )
        
        transactions[transactionId] = transaction
        
        return PurchaseResult.Success(
            transaction = transaction,
            product = product
        )
    }

    /**
     * 恢复购买
     */
    suspend fun restorePurchases(): RestoreResult {
        Logger.debug("[DesktopPayment] Restoring purchases")
        
        val restoredTransactions = transactions.values.toList()
        
        return if (restoredTransactions.isEmpty()) {
            RestoreResult.NothingToRestore()
        } else {
            RestoreResult.Success(restoredTransactions = restoredTransactions)
        }
    }

    /**
     * 检查购买状态
     */
    suspend fun checkPurchaseStatus(productId: String): PurchaseStatusResult {
        Logger.debug("[DesktopPayment] Checking purchase status for: $productId")
        
        val transaction = transactions.values.find { it.productId == productId }
        
        return if (transaction != null) {
            PurchaseStatusResult.Success(
                isPurchased = true,
                transaction = transaction
            )
        } else {
            PurchaseStatusResult.Success(
                isPurchased = false,
                transaction = null
            )
        }
    }

    /**
     * 确认消费交易
     */
    suspend fun finishTransaction(transactionId: String): TransactionFinishResult {
        Logger.debug("[DesktopPayment] Finishing transaction: $transactionId")
        
        val transaction = transactions[transactionId]
        
        return if (transaction != null) {
            finishedTransactions.add(transactionId)
            transactions[transactionId] = transaction.copy(isFinished = true)
            TransactionFinishResult.Success(transactionId = transactionId)
        } else {
            TransactionFinishResult.Failure(
                errorCode = "NOT_FOUND",
                errorMessage = "Transaction not found",
                transactionId = transactionId
            )
        }
    }

    /**
     * 获取待处理交易
     */
    suspend fun getPendingTransactionIds(): PendingTransactionsResult {
        val pending = transactions.filter { (id, tx) ->
            !tx.isFinished && !finishedTransactions.contains(id)
        }.keys.toList()
        
        return PendingTransactionsResult.Success(pendingTransactionIds = pending)
    }

    /**
     * 检查交易是否已完成
     */
    suspend fun isTransactionFinished(transactionId: String): Boolean {
        return finishedTransactions.contains(transactionId) ||
            (transactions[transactionId]?.isFinished == true)
    }

    /**
     * 清理资源
     */
    override suspend fun cleanup() {
        Logger.debug("[DesktopPayment] Cleaning up")
        productCache.clear()
        transactions.clear()
        finishedTransactions.clear()
        isInitialized = false
    }

    override suspend fun createPayment(paymentRequest: PaymentRequest): PlatformPaymentResult {
        if (!isInitialized) {
            return PlatformPaymentResult.Failed(
                errorCode = "NOT_INITIALIZED",
                errorMessage = "Desktop Payment not initialized"
            )
        }

        // 从请求中获取商品ID并调用 purchaseProduct
        val productId = paymentRequest.paymentData["productId"] as? String
        if (productId == null) {
            return PlatformPaymentResult.Failed(
                errorCode = "NO_PRODUCT_ID",
                errorMessage = "Product ID not provided in payment request"
            )
        }
        
        val result = purchaseProduct(productId)
        
        return when (result) {
            is PurchaseResult.Success -> PlatformPaymentResult.Success(
                transactionId = result.transaction.transactionId,
                paymentData = result.transaction.transactionId
            )
            is PurchaseResult.Failure -> PlatformPaymentResult.Failed(
                errorCode = result.errorCode,
                errorMessage = result.errorMessage
            )
            is PurchaseResult.Cancelled -> PlatformPaymentResult.Cancelled
            is PurchaseResult.Pending -> PlatformPaymentResult.Failed(
                errorCode = "PENDING",
                errorMessage = result.message
            )
        }
    }

    override suspend fun verifyPayment(paymentData: String): Boolean {
        // Desktop 支付验证应该在服务端完成
        Logger.debug("[DesktopPayment] Payment verification should be done on server")
        return paymentData.isNotEmpty()
    }

    override suspend fun refundPayment(refundRequest: RefundRequest): PlatformRefundResult {
        // Desktop 退款应该通过后端处理
        Logger.warn("[DesktopPayment] Refund should be handled by backend")
        return PlatformRefundResult.Failure(
            errorCode = "BACKEND_REQUIRED",
            errorMessage = "Refund should be processed through backend API"
        )
    }

    override suspend fun isPaymentMethodAvailable(paymentMethod: PaymentMethodType): Boolean {
        // Desktop 支持 Web 支付
        return isInitialized && Desktop.isDesktopSupported() && 
               Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)
    }

    override suspend fun getSupportedPaymentMethods(): List<PaymentMethodType> {
        return if (isInitialized) {
            // Desktop 通过浏览器支持 Web 支付
            listOf(PaymentMethodType.GOOGLE_PAY) // 通过 Web 方式支持
        } else {
            emptyList()
        }
    }
}

