package com.zinben.opendev.adapters

import com.zinben.opendev.models.*
import com.zinben.opendev.factories.PlatformConfig

// 平台认证适配器expect接口
expect class PlatformAuthAdapter(config: PlatformConfig) {
    suspend fun authenticate(provider: ThirdPartyProvider, userId: String? = null): PlatformAuthResult
    suspend fun getUserInfo(provider: ThirdPartyProvider): PlatformUserInfo?
    suspend fun isProviderAvailable(provider: ThirdPartyProvider): Boolean
    suspend fun getSupportedProviders(): List<ThirdPartyProvider>
    suspend fun initializeSDK()
    suspend fun cleanup()
    fun updateConfig(newConfig: PlatformConfig)
}
