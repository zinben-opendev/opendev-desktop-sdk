package com.zinben.opendev.adapters

import com.zinben.opendev.models.*

// 支付平台适配器接口
interface PaymentPlatformAdapter {
    // 创建支付
    suspend fun createPayment(paymentRequest: PaymentRequest): PlatformPaymentResult
    
    // 验证支付
    suspend fun verifyPayment(paymentData: String): Boolean
    
    // 退款支付
    suspend fun refundPayment(refundRequest: RefundRequest): PlatformRefundResult
    
    // 检查支付方式是否可用
    suspend fun isPaymentMethodAvailable(paymentMethod: PaymentMethodType): Boolean
    
    // 获取支持的支付方式
    suspend fun getSupportedPaymentMethods(): List<PaymentMethodType>
    
    // 初始化支付SDK
    suspend fun initializeSDK()
    
    // 清理支付资源
    suspend fun cleanup()
}
