package com.zinben.opendev.adapters

import com.zinben.opendev.models.*
import com.zinben.opendev.factories.PlatformConfig

/**
 * 客户端支付适配器expect类
 * 
 * 定义客户端支付相关的跨平台接口，具体实现由各平台适配器提供
 */
expect class ClientPaymentAdapter(config: PlatformConfig) {
    
    /**
     * 获取商品档位信息
     * @param productIds 商品ID列表
     * @return 商品查询结果
     */
    suspend fun fetchProducts(productIds: List<String>): ProductQueryResult
    
    /**
     * 购买商品
     * @param productId 商品ID
     * @return 购买结果
     */
    suspend fun purchaseProduct(productId: String): PurchaseResult
    
    /**
     * 恢复购买
     * @return 恢复购买结果
     */
    suspend fun restorePurchases(): RestoreResult
    
    /**
     * 检查商品档位支付状态
     * @param productId 商品ID
     * @return 购买状态结果
     */
    suspend fun checkPurchaseStatus(productId: String): PurchaseStatusResult
    
    /**
     * 确认消费交易
     * @param transactionId 交易ID
     * @return 交易完成结果
     */
    suspend fun finishTransaction(transactionId: String): TransactionFinishResult
    
    /**
     * 获取未消费的交易单号列表
     * @return 待处理交易结果
     */
    suspend fun getPendingTransactionIds(): PendingTransactionsResult
    
    /**
     * 检查交易订单是否已经消费
     * @param transactionId 交易ID
     * @return 是否已消费
     */
    suspend fun isTransactionFinished(transactionId: String): Boolean
    
    /**
     * 初始化客户端支付SDK
     */
    suspend fun initializeSDK()

    /**
     * 设置浏览器收银台 URL（Desktop / Web 平台使用）。
     * 移动端平台可空实现。
     */
    fun setBrowserCheckoutUrl(url: String)

    /**
     * 清理资源
     */
    suspend fun cleanup()
}
