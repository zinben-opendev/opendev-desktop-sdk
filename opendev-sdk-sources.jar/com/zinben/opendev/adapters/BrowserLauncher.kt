package com.zinben.opendev.adapters

/**
 * 跨平台浏览器调起器
 */
expect object BrowserLauncher {
    fun openUrl(url: String)
}

