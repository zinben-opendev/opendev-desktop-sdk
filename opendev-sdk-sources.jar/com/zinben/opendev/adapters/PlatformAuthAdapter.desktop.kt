package com.zinben.opendev.adapters

import com.zinben.opendev.factories.PlatformConfig
import com.zinben.opendev.models.PlatformAuthResult
import com.zinben.opendev.models.PlatformUserInfo
import com.zinben.opendev.models.ThirdPartyProvider
import com.zinben.opendev.utils.DeviceManager

actual class PlatformAuthAdapter actual constructor(
    config: PlatformConfig
) {
    private val delegate = BrowserPollingAuthProvider(config) { DeviceManager.getOrCreateDeviceId() }
    
    actual suspend fun initializeSDK() {
        delegate.initializeSDK()
    }
    
    actual suspend fun authenticate(provider: ThirdPartyProvider, userId: String?): PlatformAuthResult {
        return delegate.authenticate(provider, userId)
    }
    
    actual suspend fun getUserInfo(provider: ThirdPartyProvider): PlatformUserInfo? {
        return delegate.getUserInfo(provider)
    }
    
    actual suspend fun isProviderAvailable(provider: ThirdPartyProvider): Boolean {
        return delegate.isProviderAvailable(provider)
    }
    
    actual suspend fun getSupportedProviders(): List<ThirdPartyProvider> {
        return delegate.getSupportedProviders()
    }
    
    actual suspend fun cleanup() {
        delegate.cleanup()
    }

    actual fun updateConfig(newConfig: PlatformConfig) {
        delegate.updateConfig(newConfig)
    }
}