package com.zinben.opendev

import com.zinben.opendev.models.*
import com.zinben.opendev.factories.PlatformConfig
import kotlinx.coroutines.delay

/**
 * OpenDev SDK — 唯一公开门面。
 *
 * 宿主应用通过此对象完成所有 SDK 交互，不应直接操作 [OpenDevClient]。
 *
 * ```kotlin
 * // 初始化
 * OpenDevSDK.initialize(config, enableAutoLogin = true, ensureLoggedIn = true)
 *
 * // 认证
 * OpenDevSDK.auth.login(LoginMethod.GOOGLE)
 * OpenDevSDK.auth.loginState.collect { ... }
 *
 * // 支付
 * OpenDevSDK.payment.fetchProductsFromServer()
 * OpenDevSDK.payment.purchaseWithFullFlow(serverId, nativeId)
 *
 * // 配置
 * OpenDevSDK.config.getPrivacyPolicyUrl()
 *
 * // UI（一键打开整页，需依赖 core-ui 模块）
 * OpenDevSDK.ui.openPaymentMall(onNavigateBack = { ... })
 * OpenDevSDK.ui.openAccount(onNavigateBack = { ... }, onNavigateToHome = { ... })
 * ```
 */
object OpenDevSDK {

    const val SDK_NAME = "OpenDev SDK"

    val VERSION: String get() = OpenDevClient.VERSION

    val BUILD_DATE: String get() = OpenDevClient.BUILD_DATE

    // ==================== 子 API ====================

    @OptIn(InternalOpenDevApi::class)
    val auth: OpenDevAuth
        get() = OpenDevAuth(requireClient())

    @OptIn(InternalOpenDevApi::class)
    val payment: OpenDevPayment
        get() = OpenDevPayment(requireClient())

    @OptIn(InternalOpenDevApi::class)
    val config: OpenDevConfig
        get() = OpenDevConfig(requireClient())

    // ==================== 安全访问器 ====================

    /**
     * 安全获取 [OpenDevAuth]；SDK 未初始化时返回 null 而非抛异常。
     * 适用于 ViewModel 构造、Composable 初始化等不宜 crash 的场景。
     */
    @OptIn(InternalOpenDevApi::class)
    val authOrNull: OpenDevAuth?
        get() = OpenDevClient.getInstanceOrNull()?.let { OpenDevAuth(it) }

    @OptIn(InternalOpenDevApi::class)
    val paymentOrNull: OpenDevPayment?
        get() = OpenDevClient.getInstanceOrNull()?.let { OpenDevPayment(it) }

    @OptIn(InternalOpenDevApi::class)
    val configOrNull: OpenDevConfig?
        get() = OpenDevClient.getInstanceOrNull()?.let { OpenDevConfig(it) }

    /**
     * 挂起等待 SDK 初始化完成。已初始化时立即返回。
     * 用于替代各页面散落的 `while (!isInitialized()) { delay(...) }` 循环。
     */
    suspend fun awaitInitialized(pollIntervalMs: Long = 100) {
        while (!isInitialized()) {
            delay(pollIntervalMs)
        }
    }

    // ==================== UI ====================

    private var _uiProvider: OpenDevUIProvider? = null

    /**
     * SDK UI 入口 — 打开 SDK 提供的整页 UI（支付商城、账号管理等）。
     *
     * 需要宿主项目依赖 core-ui 模块，core-ui 初始化时会自动注册 UI 实现。
     * 宿主还需在根布局放置 `OpenDevUIHost()` 作为 SDK 页面的渲染容器。
     */
    val ui: OpenDevUIProvider
        get() = _uiProvider
            ?: throw IllegalStateException(
                "OpenDevSDK UI not available. Ensure core-ui module is included and OpenDevUIHost() is placed in your root layout."
            )

    /**
     * 检查 UI 模块是否可用。
     */
    fun isUIAvailable(): Boolean = _uiProvider != null

    @InternalOpenDevApi
    fun registerUIProvider(provider: OpenDevUIProvider) {
        _uiProvider = provider
    }

    // ==================== 生命周期 ====================

    @OptIn(InternalOpenDevApi::class)
    suspend fun initialize(
        config: PlatformConfig? = null,
        enableAutoLogin: Boolean = false,
        ensureLoggedIn: Boolean = false,
    ): Result<Unit> {
        return OpenDevClient.initializeInstance(config, enableAutoLogin, ensureLoggedIn).map { }
    }

    @OptIn(InternalOpenDevApi::class)
    fun isInitialized(): Boolean = OpenDevClient.isInitialized()

    @OptIn(InternalOpenDevApi::class)
    fun cleanup() {
        if (isInitialized()) {
            try {
                val client = OpenDevClient.getInstanceOrNull()
                client?.cleanup()
            } catch (_: Exception) { }
        }
    }

    fun getVersionInfo(): String = "$SDK_NAME v$VERSION (Build: $BUILD_DATE)"

    // ==================== 内部 ====================

    @InternalOpenDevApi
    fun requireClient(): OpenDevClient {
        return OpenDevClient.getInstanceOrNull()
            ?: throw IllegalStateException(
                "OpenDevSDK not initialized. Call OpenDevSDK.initialize() first."
            )
    }
}

// ==================== 公开类型别名 ====================

typealias OpenDevUser = User
typealias OpenDevAuthResult = AuthResult
typealias OpenDevLoginMethod = LoginMethod
typealias OpenDevLoginState = LoginState
typealias OpenDevInitializationState = InitializationState
typealias OpenDevThirdPartyProvider = ThirdPartyProvider
typealias OpenDevPlatformConfig = PlatformConfig
typealias OpenDevPaymentOrder = PaymentOrder
typealias OpenDevPaymentResult = PaymentResult
typealias OpenDevPaymentStatus = PaymentStatus
typealias OpenDevPaymentMethod = PaymentMethod
typealias OpenDevCreatePaymentRequest = CreatePaymentRequest
typealias OpenDevPaymentRequest = PaymentRequest
typealias OpenDevRefundRequest = RefundRequest
typealias OpenDevRefundResult = RefundResult
typealias OpenDevProductQueryResult = ProductQueryResult
typealias OpenDevPurchaseResult = PurchaseResult
typealias OpenDevRestoreResult = RestoreResult
typealias OpenDevPurchaseStatusResult = PurchaseStatusResult
typealias OpenDevTransactionFinishResult = TransactionFinishResult

/**
 * 内部 API 标记注解
 */
@RequiresOptIn(
    message = "This is an internal OpenDev SDK API. It may be changed or removed without notice.",
    level = RequiresOptIn.Level.ERROR
)
@Retention(AnnotationRetention.BINARY)
@Target(
    AnnotationTarget.CLASS,
    AnnotationTarget.FUNCTION,
    AnnotationTarget.PROPERTY,
    AnnotationTarget.TYPEALIAS,
    AnnotationTarget.CONSTRUCTOR
)
annotation class InternalOpenDevApi

/**
 * 实验性 API 标记注解
 */
@RequiresOptIn(
    message = "This is an experimental OpenDev SDK API. It may be changed in future versions.",
    level = RequiresOptIn.Level.WARNING
)
@Retention(AnnotationRetention.BINARY)
@Target(
    AnnotationTarget.CLASS,
    AnnotationTarget.FUNCTION,
    AnnotationTarget.PROPERTY,
    AnnotationTarget.TYPEALIAS,
    AnnotationTarget.CONSTRUCTOR
)
annotation class ExperimentalOpenDevApi
