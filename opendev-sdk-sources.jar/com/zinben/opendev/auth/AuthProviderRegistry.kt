package com.zinben.opendev.auth

import com.zinben.opendev.logger.Logger
import com.zinben.opendev.models.ClientChannelConfig

/**
 * Registry that holds all available [AuthProvider] instances.
 *
 * Providers are registered at SDK initialization time via [register].
 * The registry is queried by [AuthManager][com.zinben.opendev.managers.AuthManager]
 * when performing authentication.
 *
 * Supports channel-based filtering: when a [ClientChannelConfig] is applied,
 * only providers whose IDs are in [ClientChannelConfig.enabledAuthProviders] are returned.
 */
class AuthProviderRegistry {

    private val providers = mutableMapOf<String, AuthProvider>()
    private var channelConfig: ClientChannelConfig? = null

    fun register(provider: AuthProvider) {
        providers[provider.providerId] = provider
        Logger.debug("AuthProviderRegistry: Registered provider '${provider.providerId}'")
    }

    fun applyChannelConfig(config: ClientChannelConfig?) {
        channelConfig = config
        if (config != null) {
            Logger.debug("AuthProviderRegistry: Channel config applied — channelId=${config.channelId}, enabledProviders=${config.enabledAuthProviders}")
        }
    }

    fun get(providerId: String): AuthProvider? {
        val provider = providers[providerId] ?: return null
        val cfg = channelConfig ?: return provider
        return if (cfg.isAuthProviderEnabled(providerId)) provider else null
    }

    fun getAll(): List<AuthProvider> {
        val cfg = channelConfig ?: return providers.values.toList()
        return providers.values.filter { cfg.isAuthProviderEnabled(it.providerId) }
    }

    suspend fun getAvailable(): List<AuthProvider> {
        val cfg = channelConfig
        return providers.values.filter { provider ->
            val channelAllowed = cfg?.isAuthProviderEnabled(provider.providerId) ?: true
            channelAllowed && provider.isAvailable()
        }
    }

    fun contains(providerId: String): Boolean {
        if (!providers.containsKey(providerId)) return false
        val cfg = channelConfig ?: return true
        return cfg.isAuthProviderEnabled(providerId)
    }

    fun clear() {
        providers.clear()
        channelConfig = null
    }
}
