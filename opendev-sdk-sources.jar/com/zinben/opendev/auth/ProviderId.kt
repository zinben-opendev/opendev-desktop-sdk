package com.zinben.opendev.auth

import com.zinben.opendev.models.ThirdPartyProvider

/**
 * Canonical provider identifiers used across the SDK.
 *
 * Provides a string-based identifier that is extensible without breaking
 * binary compatibility. Complements [com.zinben.opendev.LoginMethod] enum
 * for scenarios requiring dynamic provider resolution.
 */
object ProviderId {
    const val GUEST = "guest"
    const val GOOGLE = "google"
    const val FACEBOOK = "facebook"
    const val APPLE = "apple"
    const val WECHAT = "wechat"
    const val QQ = "qq"

    fun fromThirdPartyProvider(provider: ThirdPartyProvider): String = when (provider) {
        ThirdPartyProvider.GOOGLE -> GOOGLE
        ThirdPartyProvider.FACEBOOK -> FACEBOOK
        ThirdPartyProvider.APPLE -> APPLE
        ThirdPartyProvider.WECHAT -> WECHAT
        ThirdPartyProvider.QQ -> QQ
    }

    fun toThirdPartyProvider(id: String): ThirdPartyProvider? = when (id) {
        GOOGLE -> ThirdPartyProvider.GOOGLE
        FACEBOOK -> ThirdPartyProvider.FACEBOOK
        APPLE -> ThirdPartyProvider.APPLE
        WECHAT -> ThirdPartyProvider.WECHAT
        QQ -> ThirdPartyProvider.QQ
        else -> null
    }
}
