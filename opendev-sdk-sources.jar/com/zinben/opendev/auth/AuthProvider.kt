package com.zinben.opendev.auth

/**
 * Unified authentication provider interface.
 *
 * Each third-party login channel (Google, Facebook, Apple, WeChat) implements
 * this interface so the SDK can treat all providers uniformly.
 */
interface AuthProvider {
    /** Canonical provider identifier, e.g. [ProviderId.GOOGLE]. */
    val providerId: String

    /** Whether this provider is available on the current platform/device. */
    suspend fun isAvailable(): Boolean

    /** Perform the sign-in flow and return a credential on success. */
    suspend fun signIn(context: AuthContext): AuthCredential

    /** Sign out from this provider (clear local provider state). */
    suspend fun signOut()
}

/**
 * Contextual information passed to [AuthProvider.signIn].
 *
 * Carries the current user ID (if any) so providers can implement
 * account-linking or re-authentication flows.
 */
data class AuthContext(
    val currentUserId: String? = null
)
