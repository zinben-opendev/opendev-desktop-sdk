package com.zinben.opendev.auth

import kotlinx.serialization.Serializable

/**
 * Unified authentication credential returned by [AuthProvider.signIn].
 *
 * Encapsulates the token/code obtained from a third-party provider
 * together with basic profile information, so the backend can verify
 * and create/link accounts without knowing provider-specific details.
 */
@Serializable
data class AuthCredential(
    val providerId: String,
    val providerUserId: String,
    val tokenType: TokenType,
    val token: String,
    val displayName: String? = null,
    val email: String? = null,
    val avatarUrl: String? = null
)

@Serializable
enum class TokenType {
    ID_TOKEN,
    ACCESS_TOKEN,
    AUTH_CODE
}
