package com.zinben.opendev

/**
 * SDK UI 能力的抽象接口 — 定义在 core 模块，由 core-ui 模块实现。
 *
 * 宿主通过 [OpenDevSDK.ui] 获取实例，调用方法即可打开 SDK 内部整页 UI，
 * 无需关心 SDK 内部的路由、页面切换等实现细节。
 *
 * ```kotlin
 * OpenDevSDK.ui.openPaymentMall(onNavigateBack = { navController.popBackStack() })
 * OpenDevSDK.ui.openAccount(
 *     onNavigateBack = { navController.popBackStack() },
 *     onNavigateToHome = { navController.navigate("home") }
 * )
 * ```
 */
interface OpenDevUIProvider {

    /**
     * 打开支付商城页面。
     * SDK 内部自动处理商城浏览、商品购买、订单记录等子页面路由。
     *
     * @param onNavigateBack 用户关闭商城时的回调
     */
    fun openPaymentMall(onNavigateBack: () -> Unit)

    /**
     * 打开账号管理页面。
     * SDK 内部自动处理账号信息、绑定/解绑、设置等子页面路由。
     *
     * @param onNavigateBack 用户关闭账号页面时的回调
     * @param onNavigateToHome 用户触发"回到首页"时的回调（如登出后跳转）
     */
    fun openAccount(
        onNavigateBack: () -> Unit = {},
        onNavigateToHome: () -> Unit = {},
    )

    /**
     * 关闭当前 SDK UI 页面。
     */
    fun dismiss()
}
