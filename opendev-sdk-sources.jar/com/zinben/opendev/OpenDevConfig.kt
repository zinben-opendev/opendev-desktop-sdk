package com.zinben.opendev

import com.zinben.opendev.factories.PlatformConfig
import com.zinben.opendev.models.ConfigEnvironment
import com.zinben.opendev.models.ConfigPlatform
import com.zinben.opendev.models.Platform
import com.zinben.opendev.models.SDKConfig

/**
 * 配置子 API — 通过 [OpenDevSDK.config] 访问。
 *
 * 包装 [OpenDevClient] 的配置管理和 SDK 状态查询能力。
 */
class OpenDevConfig @InternalOpenDevApi constructor(
    private val client: OpenDevClient,
) {
    suspend fun downloadConfig(
        baseUrl: String,
        token: String,
        environment: ConfigEnvironment,
        channelKey: String? = null,
        onSuccess: (SDKConfig) -> Unit,
        onError: (Throwable) -> Unit,
    ) = client.downloadConfig(baseUrl, token, environment, channelKey, onSuccess, onError)

    suspend fun downloadConfigSync(
        baseUrl: String,
        token: String,
        environment: ConfigEnvironment,
        channelKey: String? = null,
    ): SDKConfig = client.downloadConfigSync(baseUrl, token, environment, channelKey)

    suspend fun readConfig(
        platform: ConfigPlatform,
        environment: ConfigEnvironment,
        channelKey: String? = null,
        filePath: String? = null,
        encryptionKey: String? = null,
    ): Result<SDKConfig> = client.readConfig(platform, environment, channelKey, filePath, encryptionKey)

    fun getCurrentPlatform(): Platform = client.getCurrentPlatform()

    fun getVersion(): String = client.getVersion()

    fun getConfig(): PlatformConfig = client.getConfig()

    fun getPrivacyPolicyUrl(): String = client.getPrivacyPolicyUrl()

    fun getTermsOfUseUrl(): String = client.getTermsOfUseUrl()

    suspend fun getSDKStatus(): SDKStatus = client.getSDKStatus()
}
