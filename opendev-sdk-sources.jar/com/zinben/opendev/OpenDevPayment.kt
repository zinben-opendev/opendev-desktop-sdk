package com.zinben.opendev

import com.zinben.opendev.models.*

/**
 * 支付子 API — 通过 [OpenDevSDK.payment] 访问。
 *
 * 包装 [OpenDevClient] 的统一支付、服务端支付、原生支付和支付记录能力。
 */
class OpenDevPayment @InternalOpenDevApi constructor(
    private val client: OpenDevClient,
) {
    // ==================== 统一支付 ====================

    suspend fun fetchProductsFromServer(): ProductQueryResult =
        client.fetchProductsFromServer()

    suspend fun fetchNativeProducts(nativeProductIds: List<String>): ProductQueryResult =
        client.fetchNativeProducts(nativeProductIds)

    suspend fun purchaseWithFullFlow(
        serverProductId: String,
        nativeProductId: String,
    ): PurchaseResult = client.purchaseWithFullFlow(serverProductId, nativeProductId)

    suspend fun purchaseViaBrowser(
        serverProductId: String,
        successUrl: String? = null,
        cancelUrl: String? = null,
    ): BrowserCheckoutResult = client.purchaseViaBrowser(serverProductId, successUrl, cancelUrl)

    suspend fun pollOrderStatus(orderId: String): OrderPollResult =
        client.pollOrderStatus(orderId)

    // ==================== 服务端支付 ====================

    suspend fun createOrder(request: CreatePaymentRequest): PaymentOrder =
        client.createPaymentOrder(request)

    suspend fun performPayment(request: PaymentRequest): PaymentResult =
        client.performPayment(request)

    suspend fun queryStatus(orderId: String): PaymentStatus =
        client.queryPaymentStatus(orderId)

    suspend fun requestRefund(request: RefundRequest): RefundResult =
        client.requestRefund(request)

    suspend fun getPaymentMethods(): List<PaymentMethod> =
        client.getPaymentMethods()

    // ==================== 支付记录 ====================

    suspend fun readCachedHistory(userId: String, limit: Int = 20): List<PaymentOrder> =
        client.readCachedPaymentHistory(userId, limit)

    suspend fun syncHistoryFromServer(userId: String, limit: Int = 20): List<PaymentOrder> =
        client.syncPaymentHistoryFromServer(userId, limit)

    suspend fun getHistory(userId: String, limit: Int = 20): List<PaymentOrder> =
        client.getPaymentHistory(userId, limit)

    // ==================== 原生支付（低级别） ====================

    suspend fun fetchProducts(productIds: List<String>): ProductQueryResult =
        client.fetchProducts(productIds)

    suspend fun purchaseProduct(productId: String): PurchaseResult =
        client.purchaseProduct(productId)

    suspend fun restorePurchases(): RestoreResult =
        client.restorePurchases()

    suspend fun checkPurchaseStatus(productId: String): PurchaseStatusResult =
        client.checkPurchaseStatus(productId)

    suspend fun finishTransaction(transactionId: String): TransactionFinishResult =
        client.finishTransaction(transactionId)

    suspend fun getPendingTransactionIds(): PendingTransactionsResult =
        client.getPendingTransactionIds()

    suspend fun isTransactionFinished(transactionId: String): Boolean =
        client.isTransactionFinished(transactionId)
}
