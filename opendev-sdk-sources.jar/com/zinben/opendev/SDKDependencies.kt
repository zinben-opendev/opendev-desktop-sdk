package com.zinben.opendev

import com.zinben.opendev.adapters.ClientPaymentAdapter
import com.zinben.opendev.adapters.PaymentPlatformAdapter
import com.zinben.opendev.adapters.PlatformAuthAdapter
import com.zinben.opendev.factories.PlatformConfig
import com.zinben.opendev.factories.PlatformFactory
import com.zinben.opendev.logger.Logger
import com.zinben.opendev.managers.AuthManager
import com.zinben.opendev.utils.DeviceManager
import com.zinben.opendev.managers.PaymentManager
import com.zinben.opendev.managers.PaymentSecurityManager
import com.zinben.opendev.models.PaymentMethodType
import com.zinben.opendev.models.PaymentRequest
import com.zinben.opendev.models.RefundRequest
import com.zinben.opendev.security.PaymentSecurityManagerImpl
import com.zinben.opendev.auth.AuthProviderRegistry
import com.zinben.opendev.services.AuthService
import com.zinben.opendev.services.ChannelConfigService
import com.zinben.opendev.services.ConfigService
import com.zinben.opendev.services.HttpAuthService
import com.zinben.opendev.services.HttpPaymentService
import com.zinben.opendev.services.LocalChannelConfigService
import com.zinben.opendev.services.OAuthConfigCache
import com.zinben.opendev.services.PaymentService
import com.zinben.opendev.services.PaymentServiceImpl
import com.zinben.opendev.services.RemoteChannelConfigService
import com.zinben.opendev.db.CloudDatabase
import com.zinben.opendev.db.CloudDatabaseImpl
import com.zinben.opendev.db.LocalDatabase
import com.zinben.opendev.db.LocalDatabaseImpl
import com.zinben.opendev.storage.KVLocalDataStoreProvider
import com.zinben.opendev.storage.SavedAccountStore
import com.zinben.opendev.storage.TokenStorage
import com.zinben.opendev.storage.createTokenStorage
import kotlinx.coroutines.CoroutineScope

/**
 * Centralized dependency container for the SDK.
 *
 * Production instances are created via [create]. Tests can construct
 * this class directly with mock/fake implementations.
 */
class SDKDependencies internal constructor(
    val authService: AuthService,
    val paymentService: PaymentService,
    val httpPaymentService: HttpPaymentService,
    val configService: ConfigService,
    val channelConfigService: ChannelConfigService,
    val localDatabase: LocalDatabase,
    val cloudDatabase: CloudDatabase,
    val tokenStorage: TokenStorage,
    val authAdapter: PlatformAuthAdapter,
    val paymentAdapters: Map<PaymentMethodType, PaymentPlatformAdapter>,
    val clientPaymentAdapter: ClientPaymentAdapter,
    val authManager: AuthManager,
    val paymentManager: PaymentManager,
    val authProviderRegistry: AuthProviderRegistry,
    val oauthConfigCache: OAuthConfigCache,
    val savedAccountStore: SavedAccountStore
) {
    companion object {
        suspend fun create(config: PlatformConfig, scope: CoroutineScope): SDKDependencies {
            val localDatabase: LocalDatabase = LocalDatabaseImpl()
            val cloudDatabase: CloudDatabase = CloudDatabaseImpl()
            val tokenStorage = createTokenStorage()

            val authService: AuthService = HttpAuthService(
                baseUrl = config.apiBaseUrl,
                apiVersion = "v1",
                appId = config.appId,
                deviceIdProvider = { DeviceManager.getOrCreateDeviceId() }
            )

            val securityManager = PaymentSecurityManagerImpl(
                appId = config.appId,
                appSecret = config.appSecret
            )

            val configService = ConfigService(scope)

            val channelConfigService: ChannelConfigService = if (config.autoConfigureFromServer) {
                RemoteChannelConfigService(authService)
            } else {
                LocalChannelConfigService()
            }

            val authProviderRegistry = AuthProviderRegistry()
            config.clientChannel?.let { authProviderRegistry.applyChannelConfig(it) }

            val savedAccountStore = SavedAccountStore(KVLocalDataStoreProvider.instance)

            val platform = PlatformFactory.getCurrentPlatform()
            val authAdapter = PlatformFactory.createAuthAdapter(platform, config)
            val paymentAdapters = PlatformFactory.createPaymentAdapters(platform, config)
            val clientPaymentAdapter = PlatformFactory.createClientPaymentAdapter(platform, config)

            val authManager = AuthManager(
                authService = authService,
                platformAdapter = authAdapter,
                localDatabase = localDatabase,
                tokenStorage = tokenStorage,
                cloudDatabase = cloudDatabase,
                savedAccountStore = savedAccountStore,
                scope = scope
            )

            val httpPaymentService = HttpPaymentService(
                baseUrl = config.apiBaseUrl,
                apiVersion = "v1",
                appId = config.appId,
                tokenProvider = { tokenStorage.getToken() },
                securityManager = securityManager,
                userIdProvider = { authManager.getCurrentUser()?.id }
            )
            val paymentService: PaymentService = PaymentServiceImpl(httpPaymentService)

            val paymentManager = PaymentManager(
                paymentService = paymentService,
                platformAdapters = paymentAdapters,
                localDatabase = localDatabase,
                cloudDatabase = cloudDatabase,
                securityManager = securityManager,
                scope = scope
            )

            val oauthConfigCache = OAuthConfigCache(
                kvStore = KVLocalDataStoreProvider.instance,
                authService = authService,
                scope = scope
            )

            Logger.debug("[SDKDependencies] All dependencies created successfully")
            return SDKDependencies(
                authService = authService,
                paymentService = paymentService,
                httpPaymentService = httpPaymentService,
                configService = configService,
                channelConfigService = channelConfigService,
                localDatabase = localDatabase,
                cloudDatabase = cloudDatabase,
                tokenStorage = tokenStorage,
                authAdapter = authAdapter,
                paymentAdapters = paymentAdapters,
                clientPaymentAdapter = clientPaymentAdapter,
                authManager = authManager,
                paymentManager = paymentManager,
                authProviderRegistry = authProviderRegistry,
                oauthConfigCache = oauthConfigCache,
                savedAccountStore = savedAccountStore
            )
        }
    }
}
