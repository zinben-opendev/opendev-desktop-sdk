package com.zinben.opendev.models

import kotlinx.serialization.Serializable
import kotlinx.serialization.SerialName
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonPrimitive

/**
 * SDK配置数据模型
 * 对应后端配置包的JSON格式
 */
@Serializable
data class SDKConfig(
    val appId: String,
    val appSecret: String? = null,
    val app: AppInfo,
    val channel: ChannelConfig? = null,
    val environment: String? = null,
    val platform: String? = null,
    @SerialName("generatedAt") val generatedAt: String? = null // 配置生成时间（ISO 8601 格式，如 "2025-12-10T13:43:27.187Z"）
)

/**
 * 应用信息
 */
@Serializable
data class AppInfo(
    val appId: String,
    val packageName: String? = null,
    val name: String? = null,
    val logoUrl: String? = null,
    val platforms: List<String> = emptyList()
)

/**
 * 渠道配置
 */
@Serializable
data class ChannelConfig(
    val channelId: Int? = null,
    val channelKey: String? = null,
    val channelName: String? = null,
    val channelType: String? = null,
    val packageName: String? = null,
    val config: Map<String, JsonElement> = emptyMap(), // 支持字符串、数组等不同类型的值
    val oauthChannels: List<OAuthChannelConfig> = emptyList(),
    val microservices: List<MicroserviceConfig> = emptyList(),
    val publisher: PublisherInfo? = null
) {
    /**
     * 安全地获取字符串配置值
     * 如果值是字符串则返回，如果是数组或其他类型则返回null
     */
    fun getStringConfig(key: String): String? {
        val element = config[key] ?: return null
        return runCatching {
            if (element is JsonPrimitive && element.isString) {
                element.content
            } else {
                null
            }
        }.getOrNull()
    }
}

/**
 * OAuth渠道配置
 */
@Serializable
data class OAuthChannelConfig(
    val id: Int? = null,
    val channelKey: String? = null,
    val name: String? = null,
    val providerType: String? = null,
    val config: Map<String, JsonElement> = emptyMap() // 支持字符串、数组等不同类型的值
) {
    /**
     * 安全地获取字符串配置值
     * 如果值是字符串则返回，如果是数组或其他类型则返回null
     */
    fun getStringConfig(key: String): String? {
        val element = config[key] ?: return null
        return runCatching {
            if (element is JsonPrimitive && element.isString) {
                element.content
            } else {
                null
            }
        }.getOrNull()
    }
}

/**
 * 微服务配置
 */
@Serializable
data class MicroserviceConfig(
    val id: Int? = null,
    val serviceKey: String? = null,
    val name: String? = null,
    val serviceType: String? = null,
    val config: Map<String, JsonElement> = emptyMap() // 支持字符串、数组等不同类型的值
) {
    /**
     * 安全地获取字符串配置值
     * 如果值是字符串则返回，如果是数组或其他类型则返回null
     */
    fun getStringConfig(key: String): String? {
        val element = config[key] ?: return null
        return runCatching {
            if (element is JsonPrimitive && element.isString) {
                element.content
            } else {
                null
            }
        }.getOrNull()
    }
}

/**
 * 发行主体信息
 */
@Serializable
data class PublisherInfo(
    val id: Int? = null,
    val name: String? = null,
    val privacyPolicyUrl: String? = null,
    val termsOfUseUrl: String? = null
)

/**
 * 配置下载请求参数
 */
data class ConfigDownloadRequest(
    val baseUrl: String,
    val token: String,
    val environment: ConfigEnvironment,
    val platform: ConfigPlatform,
    val channelKey: String? = null,
    val onSuccess: (SDKConfig, String) -> Unit, // 第二个参数是加密的hex字符串
    val onError: (Throwable) -> Unit
)

/**
 * 配置环境枚举
 */
enum class ConfigEnvironment {
    DEV,
    TEST,
    PROD
}

/**
 * 配置平台枚举（对应下载URL中的平台标识）
 */
enum class ConfigPlatform(val value: String) {
    ANDROID("android"),
    IOS("ios"),
    DESKTOP("desktop"),
    WEB("web")
}

/**
 * 平台枚举到配置平台枚举的转换
 */
fun Platform.toConfigPlatform(): ConfigPlatform {
    return when (this) {
        Platform.ANDROID -> ConfigPlatform.ANDROID
        Platform.IOS -> ConfigPlatform.IOS
        Platform.DESKTOP -> ConfigPlatform.DESKTOP
        Platform.WASMJS -> ConfigPlatform.WEB
    }
}

/**
 * 配置环境字符串到枚举的转换
 */
fun String.toConfigEnvironment(): ConfigEnvironment? {
    return when (this.lowercase()) {
        "dev" -> ConfigEnvironment.DEV
        "test" -> ConfigEnvironment.TEST
        "prod" -> ConfigEnvironment.PROD
        else -> null
    }
}

/**
 * [Environment] 到 [ConfigEnvironment] 的映射（用于从 CDN 加载配置）
 */
fun com.zinben.opendev.factories.Environment.toConfigEnvironment(): ConfigEnvironment {
    return when (this) {
        com.zinben.opendev.factories.Environment.DEVELOPMENT -> ConfigEnvironment.DEV
        com.zinben.opendev.factories.Environment.STAGING -> ConfigEnvironment.TEST
        com.zinben.opendev.factories.Environment.PRODUCTION -> ConfigEnvironment.PROD
    }
}

