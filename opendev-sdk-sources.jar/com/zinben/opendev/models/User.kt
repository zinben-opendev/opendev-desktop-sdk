package com.zinben.opendev.models

import kotlinx.serialization.Serializable
import kotlinx.serialization.SerialName

@Serializable
enum class LoginType {
    GUEST,
    THIRD_PARTY,
    BOUND,
    OTP
}

@Serializable
data class BoundAccountInfo(
    val providerType: String,
    val provider: ThirdPartyProvider? = providerType.toThirdPartyProviderOrNull(),
    val providerUserId: String? = null,
    val providerUserName: String? = null
) {
    val isOtp: Boolean get() = providerType == "phone" || providerType == "email"
    val otpTargetType: OtpTargetType?
        get() = when (providerType) {
            "phone" -> OtpTargetType.PHONE
            "email" -> OtpTargetType.EMAIL
            else -> null
        }
}

@Serializable
data class User(
    val id: String,
    val username: String? = null,
    val email: String? = null,
    val avatar: String? = null,
    val nickname: String? = null,
    val loginType: LoginType,
    val boundAccounts: List<BoundAccountInfo> = emptyList(),
    val createdAt: Long,
    val lastLoginAt: Long,
    val isSynced: Boolean = false
)

@Serializable
data class PlatformUserInfo(
    @SerialName("provider_user_id") val providerUserId: String,
    val username: String? = null,
    val email: String? = null,
    val avatar: String? = null,
    val nickname: String? = null,
    val provider: ThirdPartyProvider
)
