package com.zinben.opendev.models

import kotlinx.serialization.Serializable

/**
 * OTP target type — phone (SMS) or email.
 */
@Serializable
enum class OtpTargetType {
    PHONE, EMAIL;

    fun toApiType(): String = when (this) {
        PHONE -> "phone"
        EMAIL -> "email"
    }
}

/**
 * Result of `POST /auth/send-otp`.
 */
@Serializable
data class OtpSendResult(
    val sessionId: String,
    val expiresIn: Int = 300
)

/**
 * Result of `POST /auth/verify-otp`.
 */
@Serializable
data class OtpVerifyResult(
    val sessionId: String,
    val provider: String? = null
)

/**
 * Request model for `POST /auth/send-otp`.
 */
@Serializable
internal data class SendOtpRequest(
    val appId: String,
    val channelKey: String? = null,
    val targetType: String,
    val target: String,
    val sessionId: String? = null
)

/**
 * Request model for `POST /auth/verify-otp`.
 */
@Serializable
internal data class VerifyOtpRequest(
    val appId: String,
    val channelKey: String? = null,
    val targetType: String,
    val target: String,
    val sessionId: String,
    val code: String
)

/**
 * A single payload entry from `GET /auth/payload`.
 */
@Serializable
data class AuthPayloadEntry(
    val provider: String? = null,
    val name: String? = null,
    val email: String? = null,
    @kotlinx.serialization.SerialName("user_id")
    val userId: String? = null,
    @kotlinx.serialization.SerialName("access_token")
    val accessToken: String? = null
)

/**
 * Response wrapper for `GET /auth/payload`.
 */
@Serializable
data class AuthPayloadResponse(
    @kotlinx.serialization.SerialName("user_id")
    val userId: String? = null,
    val provider: String? = null,
    val appId: String? = null,
    val payloads: List<AuthPayloadEntry> = emptyList()
)
