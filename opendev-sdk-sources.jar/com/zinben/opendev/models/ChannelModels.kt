package com.zinben.opendev.models

import kotlinx.serialization.Serializable

/**
 * Client-side channel configuration for multi-channel distribution.
 *
 * This can be constructed manually at SDK init time, or derived from
 * the server-side [ChannelConfig] returned by config download.
 *
 * @property channelId Distribution channel identifier (e.g. "google_play", "huawei", "xiaomi")
 * @property enabledAuthProviders List of provider IDs allowed for this channel (e.g. ["google", "facebook"])
 * @property paymentProvider Payment backend for this channel (e.g. "google_play", "huawei_iap", "apple_storekit")
 * @property oauthOverrides Per-provider OAuth config overrides (clientId, redirectUri, scopes)
 * @property features Feature flags for this channel
 */
@Serializable
data class ClientChannelConfig(
    val channelId: String,
    val enabledAuthProviders: List<String> = emptyList(),
    val paymentProvider: String = "",
    val oauthOverrides: Map<String, OAuthProviderConfig> = emptyMap(),
    val features: Map<String, Boolean> = emptyMap()
) {
    fun isAuthProviderEnabled(providerId: String): Boolean {
        if (enabledAuthProviders.isEmpty()) return true
        return providerId in enabledAuthProviders
    }

    fun getOAuthConfig(providerId: String): OAuthProviderConfig? {
        return oauthOverrides[providerId]
    }

    fun isFeatureEnabled(featureKey: String, default: Boolean = false): Boolean {
        return features[featureKey] ?: default
    }

    companion object {
        /**
         * Derives a [ClientChannelConfig] from the server-side [ChannelConfig].
         */
        fun fromServerConfig(serverConfig: ChannelConfig): ClientChannelConfig {
            val enabledProviders = serverConfig.oauthChannels.mapNotNull { it.providerType }
            val oauthOverrides = serverConfig.oauthChannels.associate { oauth ->
                val providerId = oauth.providerType ?: return@associate "" to OAuthProviderConfig()
                providerId to OAuthProviderConfig(
                    clientId = oauth.getStringConfig("clientId") ?: oauth.getStringConfig("appId") ?: "",
                    redirectUri = oauth.getStringConfig("redirectUri"),
                    scopes = emptyList()
                )
            }.filterKeys { it.isNotEmpty() }

            return ClientChannelConfig(
                channelId = serverConfig.channelKey ?: serverConfig.channelId?.toString() ?: "",
                enabledAuthProviders = enabledProviders,
                paymentProvider = serverConfig.channelType ?: "",
                oauthOverrides = oauthOverrides
            )
        }
    }
}

/**
 * Per-provider OAuth configuration override.
 */
@Serializable
data class OAuthProviderConfig(
    val clientId: String = "",
    val redirectUri: String? = null,
    val scopes: List<String> = emptyList()
)
