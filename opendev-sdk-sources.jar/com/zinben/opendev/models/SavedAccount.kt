package com.zinben.opendev.models

import kotlinx.serialization.Serializable

/**
 * Non-sensitive metadata for a previously authenticated account.
 *
 * Stored independently from [com.zinben.opendev.storage.TokenStorage] and
 * [com.zinben.opendev.db.LocalDatabase] auth data — session/token clearing
 * MUST NOT delete SavedAccount records (§11 reliability constraint).
 *
 * @see com.zinben.opendev.storage.SavedAccountStore
 */
@Serializable
data class SavedAccount(
    val userId: String,
    val displayName: String? = null,
    val avatar: String? = null,
    val loginMethod: SavedLoginMethod,
    val maskedIdentifier: String? = null,
    val lastUsedAt: Long,
    val lastProvider: ThirdPartyProvider? = null,
    val boundProviders: List<ThirdPartyProvider> = emptyList()
)

/**
 * Login method stored alongside [SavedAccount].
 * Mirrors [com.zinben.opendev.LoginMethod] but is serializable and
 * decoupled from the runtime enum to avoid circular module dependency.
 */
@Serializable
enum class SavedLoginMethod {
    GUEST, FACEBOOK, GOOGLE, APPLE, WECHAT, QQ, PHONE, EMAIL
}
