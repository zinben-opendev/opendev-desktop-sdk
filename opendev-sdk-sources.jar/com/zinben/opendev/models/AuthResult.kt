package com.zinben.opendev.models

import kotlinx.serialization.Serializable

sealed class AuthResult {
    data class Success(
        val user: User,
        val sessionToken: String,
        val jwtToken: String? = null,
        val expiresAt: Long? = null
    ) : AuthResult()

    data class Failure(
        val error: AuthError
    ) : AuthResult()

    data class Pending(
        val message: String
    ) : AuthResult()

    data class MultipleAccounts(
        val users: List<User>
    ) : AuthResult()

    data class Unlinked(
        val provider: ThirdPartyProvider,
        val platformUserInfo: PlatformUserInfo,
        val accessToken: String?
    ) : AuthResult()

    object Cancelled : AuthResult()
}

@Serializable
enum class AuthError {
    NETWORK_ERROR,
    INVALID_CREDENTIALS,
    USER_NOT_FOUND,
    ACCOUNT_DISABLED,
    TOO_MANY_ATTEMPTS,
    PLATFORM_AUTH_FAILED,
    USER_INFO_NOT_FOUND,
    CANCELLED,
    ACCOUNT_ALREADY_BOUND,
    INVALID_TARGET_USER,
    LOGIN_CONTEXT_EXPIRED,
    UNKNOWN_ERROR
}

sealed class PlatformAuthResult {
    data class Success(
        val providerUserId: String,
        val accessToken: String,
        val userInfo: PlatformUserInfo
    ) : PlatformAuthResult()

    data class Failure(
        val errorCode: String,
        val errorMessage: String
    ) : PlatformAuthResult()

    object Cancelled : PlatformAuthResult()
}
