package com.zinben.opendev.models

import com.zinben.opendev.LoginMethod
import kotlinx.serialization.Serializable

/**
 * Backend response envelope for `GET /auth/oauth-config`.
 *
 * Response shape: `{ code: 0, data: { appId, channelKey?, configs: {...} } }`
 */
@Serializable
data class OAuthConfigResponse(
    val appId: String? = null,
    val channelKey: String? = null,
    val configs: OAuthProviderConfigs = OAuthProviderConfigs(),
    val publisher: OAuthPublisherInfo? = null
)

@Serializable
data class OAuthPublisherInfo(
    val name: String? = null,
    val privacyPolicyUrl: String? = null,
    val termsOfUseUrl: String? = null
)

@Serializable
data class OAuthProviderConfigs(
    val google: OAuthProviderDetail? = null,
    val facebook: OAuthProviderDetail? = null,
    val apple: OAuthProviderDetail? = null,
    val wechat: OAuthProviderDetail? = null,
    val qq: OAuthProviderDetail? = null,
    val phone: OtpProviderDetail? = null,
    val email: OtpProviderDetail? = null
) {
    fun availableOAuthProviders(): List<ThirdPartyProvider> = buildList {
        if (google != null) add(ThirdPartyProvider.GOOGLE)
        if (facebook != null) add(ThirdPartyProvider.FACEBOOK)
        if (apple != null) add(ThirdPartyProvider.APPLE)
        if (wechat != null) add(ThirdPartyProvider.WECHAT)
        if (qq != null) add(ThirdPartyProvider.QQ)
    }

    fun availableOtpMethods(): List<LoginMethod> = buildList {
        if (phone != null) add(LoginMethod.PHONE)
        if (email != null) add(LoginMethod.EMAIL)
    }

    fun toClientChannelConfig(channelId: String): ClientChannelConfig {
        val enabledProviders = availableOAuthProviders().map { it.name.lowercase() }
        val overrides = buildMap {
            google?.clientId?.let { put("google", OAuthProviderConfig(clientId = it)) }
            facebook?.appId?.let { put("facebook", OAuthProviderConfig(clientId = it)) }
            apple?.clientId?.let { put("apple", OAuthProviderConfig(clientId = it)) }
            wechat?.appId?.let { put("wechat", OAuthProviderConfig(clientId = it)) }
            qq?.appId?.let { put("qq", OAuthProviderConfig(clientId = it)) }
        }
        return ClientChannelConfig(
            channelId = channelId,
            enabledAuthProviders = enabledProviders,
            oauthOverrides = overrides
        )
    }
}

@Serializable
data class OAuthProviderDetail(
    val clientId: String? = null,
    val appId: String? = null
)

@Serializable
data class OtpProviderDetail(
    val enabled: Boolean = false
)

/**
 * Backend response envelope for `GET /auth/app-channels`.
 *
 * Response shape: `{ code: 0, data: { appId, channels: [...] } }`
 */
@Serializable
data class AppChannelsResponse(
    val appId: String? = null,
    val channels: List<ChannelInfo> = emptyList()
)

@Serializable
data class ChannelInfo(
    val channelKey: String,
    val name: String? = null
)
