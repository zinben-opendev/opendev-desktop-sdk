package com.zinben.opendev.models

import kotlinx.serialization.Serializable

/**
 * 跨平台金额类型
 * 
 * 使用 String 存储金额，确保跨平台兼容性（Android、iOS、Desktop、WasmJS）
 * 金额格式：数字字符串，支持小数（如 "99.99"）
 * 
 * 优势：
 * - 跨平台兼容：所有平台都支持 String
 * - 精度保持：不会丢失小数精度
 * - 序列化友好：直接序列化为字符串
 * 
 * 注意：使用普通类而非 value class，以确保在所有平台（包括 JVM）上都能正常工作。
 * JVM 平台需要 @JvmInline 才能使用 value class，但该注解在 iOS 等平台不可用。
 * 
 * 使用示例：
 * ```kotlin
 * val amount = Money("99.99")
 * val total = amount.add(Money("10.00"))
 * ```
 */
@Serializable
data class Money(val value: String) {
    
    init {
        require(value.isNotBlank()) { "Money value cannot be blank" }
        require(value.matches(Regex("^-?\\d+(\\.\\d+)?$"))) { 
            "Money value must be a valid number string: $value" 
        }
    }
    
    /**
     * 创建金额（从字符串）
     */
    companion object {
        fun of(value: String): Money = Money(value)
        
        /**
         * 创建金额（从 Double，用于兼容现有代码）
         * 注意：Double 可能有精度问题，建议直接使用 String
         */
        fun fromDouble(value: Double): Money = Money(value.toString())
        
        /**
         * 创建金额（从 Long，以分为单位）
         * 例如：fromCents(9999) = Money("99.99")
         */
        fun fromCents(cents: Long): Money {
            val dollars = cents / 100
            val centsRemainder = cents % 100
            return Money("$dollars.${centsRemainder.toString().padStart(2, '0')}")
        }
        
        /**
         * 零金额
         */
        val ZERO = Money("0.00")
    }
    
    /**
     * 转换为 Double（可能丢失精度）
     */
    fun toDouble(): Double = value.toDoubleOrNull() ?: 0.0
    
    /**
     * 转换为 Long（以分为单位）
     * 例如：Money("99.99").toCents() = 9999
     */
    fun toCents(): Long {
        val parts = value.split(".")
        val dollars = parts[0].toLongOrNull() ?: 0L
        val cents = if (parts.size > 1) {
            val centsStr = parts[1].padEnd(2, '0').take(2)
            centsStr.toLongOrNull() ?: 0L
        } else {
            0L
        }
        return dollars * 100 + cents
    }
    
    /**
     * 加法
     */
    operator fun plus(other: Money): Money {
        val result = toDouble() + other.toDouble()
        return Money(result.toString())
    }
    
    /**
     * 减法
     */
    operator fun minus(other: Money): Money {
        val result = toDouble() - other.toDouble()
        return Money(result.toString())
    }
    
    /**
     * 乘法
     */
    operator fun times(multiplier: Double): Money {
        val result = toDouble() * multiplier
        return Money(result.toString())
    }
    
    /**
     * 比较
     */
    operator fun compareTo(other: Money): Int {
        return toDouble().compareTo(other.toDouble())
    }
    
    override fun toString(): String = value
}

/**
 * 扩展函数：String 转 Money
 */
fun String.toMoney(): Money = Money(this)

/**
 * 扩展函数：Double 转 Money
 */
fun Double.toMoney(): Money = Money.fromDouble(this)

/**
 * Double 转无科学计数法字符串，跨平台兼容（Kotlin/Native 无 BigDecimal）。
 * 去除尾部多余零，但至少保留一位小数。
 */
fun Double.formatPlain(): String {
    if (this == 0.0) return "0"
    val raw = this.toString()
    if ('E' !in raw && 'e' !in raw) {
        return raw.trimEnd('0').trimEnd('.')
    }
    val long = this.toLong()
    if (this == long.toDouble()) return long.toString()
    return raw
}

/**
 * 扩展函数：Long（分）转 Money
 */
fun Long.toMoneyFromCents(): Money = Money.fromCents(this)

