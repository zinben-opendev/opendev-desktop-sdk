package com.zinben.opendev.models

import kotlinx.serialization.Serializable

/**
 * 商品信息
 */
@Serializable
data class Product(
    val id: String,
    val name: String,
    val description: String,
    val price: Money,
    val currency: String,
    val type: ProductType,
    val platform: Platform,
    val isAvailable: Boolean = true,
    val localizedPrice: String? = null,
    val localizedTitle: String? = null,
    val localizedDescription: String? = null,
    val platformProductIds: Map<String, String>? = null,
    val source: String? = null
)

/**
 * 商品类型
 */
@Serializable
enum class ProductType {
    CONSUMABLE,        // 消耗品（如金币、道具）
    NON_CONSUMABLE,    // 非消耗品（如解锁功能）
    SUBSCRIPTION,      // 订阅（如会员）
    AUTO_RENEWABLE     // 自动续费订阅
}

/**
 * 交易订单信息
 */
@Serializable
data class Transaction(
    val transactionId: String,         // 交易ID
    val productId: String,             // 商品ID
    val userId: String,                // 用户ID
    val platform: Platform,           // 平台
    val purchaseTime: Long,            // 购买时间
    val originalTransactionId: String?, // 原始交易ID（用于恢复购买）
    val isRestored: Boolean = false,   // 是否为恢复购买
    val isFinished: Boolean = false,   // 是否已消费
    val receipt: String? = null,       // 收据信息
    val signature: String? = null,     // 签名信息
    val purchaseToken: String? = null  // 购买令牌
)

/**
 * 购买结果
 */
@Serializable
sealed class PurchaseResult {
    @Serializable
    data class Success(
        val transaction: Transaction,
        val product: Product
    ) : PurchaseResult()
    
    @Serializable
    data class Failure(
        val errorCode: String,
        val errorMessage: String,
        val productId: String? = null
    ) : PurchaseResult()
    
    @Serializable
    data class Cancelled(
        val productId: String
    ) : PurchaseResult()
    
    @Serializable
    data class Pending(
        val productId: String,
        val message: String
    ) : PurchaseResult()
}

/**
 * 商品查询结果
 */
@Serializable
sealed class ProductQueryResult {
    @Serializable
    data class Success(
        val products: List<Product>
    ) : ProductQueryResult()
    
    @Serializable
    data class Failure(
        val errorCode: String,
        val errorMessage: String
    ) : ProductQueryResult()
}

/**
 * 购买状态检查结果
 */
@Serializable
sealed class PurchaseStatusResult {
    @Serializable
    data class Success(
        val isPurchased: Boolean,
        val transaction: Transaction? = null
    ) : PurchaseStatusResult()
    
    @Serializable
    data class Failure(
        val errorCode: String,
        val errorMessage: String
    ) : PurchaseStatusResult()
}

/**
 * 恢复购买结果
 */
@Serializable
sealed class RestoreResult {
    @Serializable
    data class Success(
        val restoredTransactions: List<Transaction>
    ) : RestoreResult()
    
    @Serializable
    data class Failure(
        val errorCode: String,
        val errorMessage: String
    ) : RestoreResult()
    
    @Serializable
    data class NothingToRestore(
        val message: String = "No purchases to restore"
    ) : RestoreResult()
}

/**
 * 交易完成结果
 */
@Serializable
sealed class TransactionFinishResult {
    @Serializable
    data class Success(
        val transactionId: String
    ) : TransactionFinishResult()
    
    @Serializable
    data class Failure(
        val errorCode: String,
        val errorMessage: String,
        val transactionId: String
    ) : TransactionFinishResult()
}

/**
 * 待处理交易列表结果
 */
@Serializable
sealed class PendingTransactionsResult {
    @Serializable
    data class Success(
        val pendingTransactionIds: List<String>
    ) : PendingTransactionsResult()

    @Serializable
    data class Failure(
        val errorCode: String,
        val errorMessage: String
    ) : PendingTransactionsResult()
}

/**
 * 浏览器收银台发起结果（Desktop / Web）
 */
sealed class BrowserCheckoutResult {
    data class Opened(
        val orderId: String,
        val checkoutUrl: String,
        val productId: String
    ) : BrowserCheckoutResult()

    data class Failed(
        val errorCode: String,
        val errorMessage: String
    ) : BrowserCheckoutResult()
}

/**
 * 订单轮询结果
 */
sealed class OrderPollResult {
    data class Completed(val orderId: String) : OrderPollResult()
    data class Pending(val orderId: String, val currentStatus: String) : OrderPollResult()
    data class Failed(val orderId: String, val reason: String) : OrderPollResult()
    data class Error(val message: String) : OrderPollResult()
}
