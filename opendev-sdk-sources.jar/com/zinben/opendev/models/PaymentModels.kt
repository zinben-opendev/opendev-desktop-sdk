package com.zinben.opendev.models

import kotlinx.serialization.Serializable

// 支付方式类型
@Serializable
enum class PaymentMethodType {
    // 海外支付
    APPLE_PAY,
    GOOGLE_PAY,
    STRIPE_CARD,
    PAYPAL,
    
    // 国内支付
    WECHAT_PAY,
    ALIPAY,
    UNION_PAY,
    
    // 其他
    BANK_TRANSFER,
    CRYPTO_CURRENCY
}

// 支付状态
@Serializable
enum class PaymentStatus {
    PENDING,
    PROCESSING,
    SUCCESS,
    FAILED,
    CANCELLED,
    REFUNDED
}

// 支付订单
@Serializable
data class PaymentOrder(
    val id: String,
    val userId: String,
    val productId: String,
    val productName: String,
    val productDescription: String? = null,
    val amount: Money,
    val currency: String,
    val paymentMethod: PaymentMethodType,
    val platform: Platform,
    val status: PaymentStatus,
    val createdAt: Long,
    val updatedAt: Long,
    val expiresAt: Long? = null,
    val metadata: Map<String, String> = emptyMap()
)

// 支付交易
@Serializable
data class PaymentTransaction(
    val id: String,
    val orderId: String,
    val transactionId: String? = null,
    val paymentMethod: PaymentMethodType,
    val amount: Money,
    val currency: String,
    val status: PaymentStatus,
    val paymentTime: Long? = null,
    val platformData: Map<String, String> = emptyMap(),
    val createdAt: Long,
    val updatedAt: Long
)

// 退款记录
@Serializable
data class RefundRecord(
    val id: String,
    val transactionId: String,
    val orderId: String,
    val amount: Money,
    val currency: String,
    val reason: String? = null,
    val status: PaymentStatus,
    val refundTime: Long? = null,
    val createdAt: Long,
    val updatedAt: Long
)

// 支付方式
@Serializable
data class PaymentMethod(
    val type: PaymentMethodType,
    val name: String,
    val isEnabled: Boolean = true,
    val platformSupport: List<Platform> = emptyList(),
    val configData: Map<String, String> = emptyMap()
)

// 创建支付请求
@Serializable
data class CreatePaymentRequest(
    val userId: String,
    val amount: Money,
    val currency: String,
    val productId: String,
    val productName: String,
    val productDescription: String? = null,
    val platform: Platform,
    val paymentMethods: List<PaymentMethodType>
)

// 支付请求
@Serializable
data class PaymentRequest(
    val orderId: String,
    val paymentMethod: PaymentMethodType,
    val amount: Money, // 支付金额
    val currency: String, // 货币类型
    val paymentData: Map<String, String>, // 平台特定的支付数据
    val platform: Platform
)

// 支付结果
@Serializable
sealed class PaymentResult {
    @Serializable
    data class Success(
        val orderId: String,
        val transactionId: String,
        val amount: Money,
        val currency: String,
        val paymentTime: Long
    ) : PaymentResult()
    
    @Serializable
    data class Pending(
        val orderId: String,
        val status: String,
        val message: String
    ) : PaymentResult()
    
    @Serializable
    data class Failure(
        val orderId: String,
        val errorCode: String,
        val errorMessage: String
    ) : PaymentResult()
}

// 平台支付结果
sealed class PlatformPaymentResult {
    data class Success(
        val transactionId: String,
        val paymentData: String
    ) : PlatformPaymentResult()
    
    data class Failed(
        val errorCode: String,
        val errorMessage: String
    ) : PlatformPaymentResult()
    
    object Cancelled : PlatformPaymentResult()
}

// 退款请求
@Serializable
data class RefundRequest(
    val transactionId: String,
    val orderId: String,
    val amount: Money,
    val currency: String,
    val reason: String? = null
)

// 退款结果
@Serializable
sealed class RefundResult {
    @Serializable
    data class Success(
        val refundId: String,
        val amount: Money,
        val currency: String,
        val refundTime: Long
    ) : RefundResult()
    
    @Serializable
    data class Failure(
        val errorCode: String,
        val errorMessage: String
    ) : RefundResult()
}

// 平台退款结果
sealed class PlatformRefundResult {
    data class Success(
        val refundId: String,
        val amount: Money,
        val currency: String
    ) : PlatformRefundResult()
    
    data class Failure(
        val errorCode: String,
        val errorMessage: String
    ) : PlatformRefundResult()
}
