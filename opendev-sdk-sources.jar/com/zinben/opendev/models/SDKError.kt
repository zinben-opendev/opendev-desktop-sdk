package com.zinben.opendev.models

sealed class SDKError(
    val code: String,
    override val message: String,
    override val cause: Throwable? = null
) : Exception(message, cause) {

    sealed class Auth(code: String, message: String, cause: Throwable? = null) : SDKError(code, message, cause) {
        class NotInitialized : Auth("AUTH_001", "SDK not initialized")
        class NotLoggedIn : Auth("AUTH_002", "User not logged in")
        class InvalidCredentials(detail: String? = null) : Auth("AUTH_003", "Invalid credentials${detail?.let { ": $it" } ?: ""}")
        class ProviderUnavailable(provider: String) : Auth("AUTH_004", "Auth provider unavailable: $provider")
        class PlatformAuthFailed(detail: String? = null) : Auth("AUTH_005", "Platform authentication failed${detail?.let { ": $it" } ?: ""}")
        class UserNotFound : Auth("AUTH_006", "User not found")
        class AccountDisabled : Auth("AUTH_007", "Account disabled")
        class TooManyAttempts : Auth("AUTH_008", "Too many login attempts")
        class TokenExpired : Auth("AUTH_009", "Token expired")
    }

    sealed class Network(code: String, message: String, cause: Throwable? = null) : SDKError(code, message, cause) {
        class ConnectionFailed(cause: Throwable? = null) : Network("NET_001", "Network connection failed", cause)
        class Timeout(cause: Throwable? = null) : Network("NET_002", "Request timed out", cause)
        class ServerError(statusCode: Int, detail: String? = null) : Network("NET_003", "Server error ($statusCode)${detail?.let { ": $it" } ?: ""}")
        class InvalidResponse(detail: String? = null) : Network("NET_004", "Invalid server response${detail?.let { ": $it" } ?: ""}")
    }

    sealed class Payment(code: String, message: String, cause: Throwable? = null) : SDKError(code, message, cause) {
        class NotInitialized : Payment("PAY_001", "Payment system not initialized")
        class ProductNotFound(productId: String) : Payment("PAY_002", "Product not found: $productId")
        class PurchaseFailed(detail: String? = null) : Payment("PAY_003", "Purchase failed${detail?.let { ": $it" } ?: ""}")
        class TransactionNotFound(transactionId: String) : Payment("PAY_004", "Transaction not found: $transactionId")
        class SecurityValidationFailed : Payment("PAY_005", "Payment security validation failed")
    }

    sealed class Config(code: String, message: String, cause: Throwable? = null) : SDKError(code, message, cause) {
        class FileNotFound(path: String) : Config("CFG_001", "Config file not found: $path")
        class ParseFailed(detail: String? = null) : Config("CFG_002", "Config parse failed${detail?.let { ": $it" } ?: ""}")
        class DecryptionFailed : Config("CFG_003", "Config decryption failed")
    }

    override fun toString(): String = "[$code] $message"
}
