package com.zinben.opendev.models

/**
 * 将 ThirdPartyProvider 映射为后端约定的 provider 字符串
 */
fun ThirdPartyProvider.toApiType(): String {
    return when (this) {
        ThirdPartyProvider.FACEBOOK -> "facebook"
        ThirdPartyProvider.GOOGLE -> "google"
        ThirdPartyProvider.APPLE -> "apple"
        ThirdPartyProvider.WECHAT -> "wechat"
        ThirdPartyProvider.QQ -> "qq"
    }
}

fun String?.toThirdPartyProviderOrNull(): ThirdPartyProvider? {
    return when (this?.uppercase()) {
        "FACEBOOK" -> ThirdPartyProvider.FACEBOOK
        "GOOGLE" -> ThirdPartyProvider.GOOGLE
        "APPLE" -> ThirdPartyProvider.APPLE
        "WECHAT", "WECHATPAY", "WECHAT_APP", "WX" -> ThirdPartyProvider.WECHAT
        "QQ" -> ThirdPartyProvider.QQ
        else -> null
    }
}

