package com.zinben.opendev.models

import kotlinx.serialization.Serializable

@Serializable
enum class ThirdPartyProvider {
    FACEBOOK,
    GOOGLE,
    APPLE,
    WECHAT,
    QQ
}

@Serializable
enum class Platform {
    ANDROID,
    IOS,
    DESKTOP,
    WASMJS
}
