package com.zinben.opendev.logger

interface LoggerInterface {
    fun info(msg: String)
    fun warn(msg: String)
    fun error(msg: String)
    fun debug(msg: String)
}

expect class LoggerImp() : LoggerInterface {
    override fun info(msg: String)
    override fun warn(msg: String)
    override fun error(msg: String)
    override fun debug(msg: String)
}

expect object LoggerProvider {
    val instance: LoggerImp
}

object LoggerConfiguration {
    private var customLogger: LoggerInterface? = null

    fun setLogger(logger: LoggerInterface) {
        customLogger = logger
    }

    fun resetToDefault() {
        customLogger = null
    }

    internal fun getLogger(): LoggerInterface = customLogger ?: LoggerProvider.instance
}

val Logger: LoggerInterface
    get() = LoggerConfiguration.getLogger()
