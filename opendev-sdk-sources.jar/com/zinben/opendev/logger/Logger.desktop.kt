package com.zinben.opendev.logger

import org.slf4j.LoggerFactory

actual class LoggerImp : LoggerInterface {
    private val logger = LoggerFactory.getLogger("Client.Logger")

    actual override fun info(msg: String) {
        logger.info(msg)
    }

    actual override fun warn(msg: String) {
        logger.warn(msg)
    }

    actual override fun error(msg: String) {
        logger.error(msg)
    }

    actual override fun debug(msg: String) {
        logger.debug(msg)
    }
}

actual object LoggerProvider {
    actual val instance: LoggerImp by lazy { LoggerImp() }
} 