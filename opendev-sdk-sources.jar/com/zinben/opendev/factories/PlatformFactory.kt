package com.zinben.opendev.factories

import com.zinben.opendev.network.SSLCertificateConfig
import com.zinben.opendev.adapters.PlatformAuthAdapter
import com.zinben.opendev.adapters.PaymentPlatformAdapter
import com.zinben.opendev.adapters.ClientPaymentAdapter
import com.zinben.opendev.models.ClientChannelConfig
import com.zinben.opendev.models.PaymentMethodType
import com.zinben.opendev.models.Platform
import com.zinben.opendev.models.SDKConfig

// 平台工厂类
object PlatformFactory {
    
    // 获取当前平台
    fun getCurrentPlatform(): Platform {
        return when (getPlatformName()) {
            "android" -> Platform.ANDROID
            "ios" -> Platform.IOS
            "desktop" -> Platform.DESKTOP
            "wasmjs" -> Platform.WASMJS
            else -> Platform.ANDROID // 默认值
        }
    }
    
    // 创建认证适配器
    fun createAuthAdapter(
        platform: Platform,
        config: PlatformConfig
    ): PlatformAuthAdapter {
        return PlatformAuthAdapter(config)
    }
    
    // 创建支付适配器映射
    fun createPaymentAdapters(
        platform: Platform,
        config: PlatformConfig
    ): Map<PaymentMethodType, PaymentPlatformAdapter> {
        return createPaymentAdaptersImpl(config)
    }
    
    // 创建客户端支付适配器
    fun createClientPaymentAdapter(
        platform: Platform,
        config: PlatformConfig
    ): ClientPaymentAdapter {
        return ClientPaymentAdapter(config)
    }
    
    // 获取平台名称
    // 使用 expect/actual 机制进行跨平台平台检测
    private fun getPlatformName(): String {
        return getPlatformNameImpl()
    }
    
}

// ==================== 通用平台适配器创建方法声明 ====================

// 声明通用的支付适配器创建方法
expect fun createPaymentAdaptersImpl(config: PlatformConfig): Map<PaymentMethodType, PaymentPlatformAdapter>

// 声明平台名称获取方法（跨平台实现）
expect fun getPlatformNameImpl(): String

// 声明创建默认平台配置的方法（跨平台实现）
// @param sdkConfig 从配置文件读取的SDK配置（可选，如果为null则使用默认值）
expect fun createDefaultPlatformConfig(sdkConfig: SDKConfig?): PlatformConfig

/**
 * 平台配置
 * 
 * SDK 初始化所需的平台相关配置参数
 * 
 * @property appId 应用唯一标识，用于账号服务按应用隔离
 * @property environment 运行环境（开发/预发/生产）
 * @property channelKey 渠道标识（如 google_global），用于区分不同分发渠道
 */
data class PlatformConfig(
    // ==================== 基础配置 ====================
    /** 应用唯一标识，用于账号服务按应用隔离 */
    val appId: String = "",
    /** 运行环境 */
    val environment: Environment = Environment.PRODUCTION,
    /** 渠道标识（如 google_global），用于区分不同分发渠道 */
    val channelKey: String = "",
    
    // ==================== API 配置 ====================
    /** API 服务基础 URL */
    val apiBaseUrl: String = "",
    /** OAuth 重定向 URI */
    val redirectUri: String = "",
    
    // ==================== CDN 配置 ====================
    /** CDN 基础 URL，用于下载配置文件 */
    val cdnBaseUrl: String = "",
    /** CDN 访问令牌（预签名 URL 参数） */
    val cdnToken: String = "",
    
    // ==================== 第三方登录配置 ====================
    // --- Facebook ---
    /** Facebook 应用 ID */
    val facebookAppId: String = "",
    /** Facebook 客户端令牌 */
    val facebookClientToken: String = "",
    
    // --- Google ---
    /** Google OAuth 客户端 ID */
    val googleClientId: String = "",
    
    // --- Apple ---
    /** Apple 服务 ID（用于 Sign in with Apple） */
    val appleClientId: String = "",
    
    // --- 微信 ---
    /** 微信开放平台应用 ID */
    val wechatAppId: String = "",
    /** 微信开放平台应用密钥（仅用于服务端） */
    val wechatAppSecret: String = "",
    /** 微信 Universal Link（iOS 必需） */
    val wechatUniversalLink: String = "",
    
    // ==================== 支付配置 ====================
    /** 应用密钥，用于支付 API 请求 HMAC 签名（编译时内嵌，与 appSignature.js 一致） */
    val appSecret: String = "",
    /** Google Pay 商家 ID */
    val googlePayMerchantId: String = "",
    /** Google Pay 商家名称 */
    val googlePayMerchantName: String = "OpenDev",
    /** Google Pay 环境（TEST/PRODUCTION） */
    val googlePayEnvironment: String = "TEST",
    
    // ==================== 网络配置 ====================
    /** SSL 证书配置 */
    val sslCertificateConfig: SSLCertificateConfig = SSLCertificateConfig.DEFAULT,

    // ==================== 渠道配置 ====================
    /** 客户端渠道配置（可在 SDK 初始化时注入，或从服务端配置自动派生） */
    val clientChannel: ClientChannelConfig? = null,
    /** 是否在初始化后自动从服务端拉取渠道配置 */
    val autoConfigureFromServer: Boolean = false,

    // ==================== 登录策略 ====================
    /** 是否启用游客登录（客户端本地能力，不依赖服务端配置） */
    val guestLoginEnabled: Boolean = true,

    // ==================== 法律信息（来自 CDN 配置 channel.publisher） ====================
    val privacyPolicyUrl: String = "",
    val termsOfUseUrl: String = ""
) {
    /**
     * 用 [other] 填充本配置中未设置的字段（空字符串 / 默认值视为未设置）。
     * 用于：宿主只传 cdnBaseUrl/channelKey 时，从 CDN 加载的配置填充 appId、apiBaseUrl 等。
     */
    fun fillDefaultsFrom(other: PlatformConfig): PlatformConfig = copy(
        appId = if (appId.isNotEmpty()) appId else other.appId,
        apiBaseUrl = if (apiBaseUrl.isNotEmpty()) apiBaseUrl else other.apiBaseUrl,
        redirectUri = if (redirectUri.isNotEmpty()) redirectUri else other.redirectUri,
        channelKey = if (channelKey.isNotEmpty()) channelKey else other.channelKey,
        cdnBaseUrl = if (cdnBaseUrl.isNotEmpty()) cdnBaseUrl else other.cdnBaseUrl,
        cdnToken = if (cdnToken.isNotEmpty()) cdnToken else other.cdnToken,
        facebookAppId = if (facebookAppId.isNotEmpty()) facebookAppId else other.facebookAppId,
        facebookClientToken = if (facebookClientToken.isNotEmpty()) facebookClientToken else other.facebookClientToken,
        googleClientId = if (googleClientId.isNotEmpty()) googleClientId else other.googleClientId,
        appleClientId = if (appleClientId.isNotEmpty()) appleClientId else other.appleClientId,
        wechatAppId = if (wechatAppId.isNotEmpty()) wechatAppId else other.wechatAppId,
        wechatAppSecret = if (wechatAppSecret.isNotEmpty()) wechatAppSecret else other.wechatAppSecret,
        wechatUniversalLink = if (wechatUniversalLink.isNotEmpty()) wechatUniversalLink else other.wechatUniversalLink,
        googlePayMerchantId = if (googlePayMerchantId.isNotEmpty()) googlePayMerchantId else other.googlePayMerchantId,
        googlePayMerchantName = if (googlePayMerchantName != "OpenDev") googlePayMerchantName else other.googlePayMerchantName,
        googlePayEnvironment = if (googlePayEnvironment != "TEST") googlePayEnvironment else other.googlePayEnvironment,
        privacyPolicyUrl = if (privacyPolicyUrl.isNotEmpty()) privacyPolicyUrl else other.privacyPolicyUrl,
        termsOfUseUrl = if (termsOfUseUrl.isNotEmpty()) termsOfUseUrl else other.termsOfUseUrl
    )
}

// 环境枚举
enum class Environment {
    DEVELOPMENT,
    STAGING,
    PRODUCTION
}
