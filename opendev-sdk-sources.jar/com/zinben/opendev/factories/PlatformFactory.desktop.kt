package com.zinben.opendev.factories

import com.zinben.opendev.network.SSLCertificateConfig
import com.zinben.opendev.adapters.DesktopPaymentAdapter
import com.zinben.opendev.adapters.PaymentPlatformAdapter
import com.zinben.opendev.models.PaymentMethodType
import com.zinben.opendev.models.SDKConfig

// Desktop平台支付适配器创建actual实现
actual fun createPaymentAdaptersImpl(config: PlatformConfig): Map<PaymentMethodType, PaymentPlatformAdapter> {
    return mapOf(
        PaymentMethodType.GOOGLE_PAY to DesktopPaymentAdapter(config)
        // Desktop 平台通过浏览器实现 Web 支付
    )
}

// Desktop平台名称获取actual实现
actual fun getPlatformNameImpl(): String = "desktop"

// Desktop平台默认配置创建actual实现
actual fun createDefaultPlatformConfig(sdkConfig: SDKConfig?): PlatformConfig {
    // Desktop 平台可以直接使用 localhost
    val defaultApiBaseUrl = "https://zinben.com"
    
    // 从SDKConfig中提取配置（如果存在）
    val apiBaseUrl = sdkConfig?.channel?.microservices?.firstOrNull { 
        it.serviceType == "account" 
    }?.getStringConfig("baseUrl") ?: defaultApiBaseUrl
    
    val appId = sdkConfig?.appId ?: ""
    val cdnBaseUrl = sdkConfig?.channel?.getStringConfig("cdnBaseUrl") ?: ""
    // cdnEncryptionKey 已移至 SDK 内部
    val cdnToken = sdkConfig?.channel?.getStringConfig("cdnToken") ?: ""
    
    // 从OAuth渠道配置中提取第三方登录配置
    val facebookConfig = sdkConfig?.channel?.oauthChannels?.firstOrNull { 
        it.providerType == "facebook" 
    }
    val googleConfig = sdkConfig?.channel?.oauthChannels?.firstOrNull { 
        it.providerType == "google" 
    }
    val appleConfig = sdkConfig?.channel?.oauthChannels?.firstOrNull { 
        it.providerType == "apple" 
    }
    val wechatConfig = sdkConfig?.channel?.oauthChannels?.firstOrNull { 
        it.providerType == "wechat" 
    }
    
    val facebookAppId = facebookConfig?.getStringConfig("appId") ?: ""
    val facebookClientToken = facebookConfig?.getStringConfig("clientToken") ?: ""
    val googleClientId = googleConfig?.getStringConfig("clientId") ?: ""
    val appleClientId = appleConfig?.getStringConfig("clientId") ?: ""
    val wechatAppId = wechatConfig?.getStringConfig("appId") ?: ""
    val wechatAppSecret = wechatConfig?.getStringConfig("appSecret") ?: ""
    val wechatUniversalLink = wechatConfig?.getStringConfig("universalLink") ?: ""
    
    // 解析环境
    val environment = when (sdkConfig?.environment?.lowercase()) {
        "dev" -> Environment.DEVELOPMENT
        "test" -> Environment.DEVELOPMENT
        "prod" -> Environment.PRODUCTION
        else -> Environment.DEVELOPMENT
    }
    
    val redirectUri = "${apiBaseUrl.trimEnd('/')}/auth/callback"
    
    // 从SDKConfig中提取channelKey
    val channelKey = sdkConfig?.channel?.channelKey ?: ""
    
    // Google Pay 配置
    val googlePayMerchantId = sdkConfig?.channel?.getStringConfig("googlePayMerchantId") ?: "BCR2DN4T3X7MLNRS"
    val googlePayMerchantName = sdkConfig?.channel?.getStringConfig("googlePayMerchantName") ?: "OpenDev"
    val googlePayEnvironment = sdkConfig?.channel?.getStringConfig("googlePayEnvironment")
        ?: if (environment == Environment.PRODUCTION) "PRODUCTION" else "TEST"
    
    return PlatformConfig(
        appId = appId,
        environment = environment,
        channelKey = channelKey,
        apiBaseUrl = apiBaseUrl,
        redirectUri = redirectUri,
        cdnBaseUrl = cdnBaseUrl,
        cdnToken = cdnToken,
        facebookAppId = facebookAppId,
        facebookClientToken = facebookClientToken,
        googleClientId = googleClientId,
        appleClientId = appleClientId,
        wechatAppId = wechatAppId,
        wechatAppSecret = wechatAppSecret,
        wechatUniversalLink = wechatUniversalLink,
        googlePayMerchantId = googlePayMerchantId,
        googlePayMerchantName = googlePayMerchantName,
        googlePayEnvironment = googlePayEnvironment,
        sslCertificateConfig = if (environment == Environment.PRODUCTION) {
            SSLCertificateConfig.DEFAULT
        } else {
            SSLCertificateConfig.DEVELOPMENT
        },
        privacyPolicyUrl = sdkConfig?.channel?.publisher?.privacyPolicyUrl ?: "",
        termsOfUseUrl = sdkConfig?.channel?.publisher?.termsOfUseUrl ?: ""
    )
}
