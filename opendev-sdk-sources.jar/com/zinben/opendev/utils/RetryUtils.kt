package com.zinben.opendev.utils

import com.zinben.opendev.logger.Logger
import kotlinx.coroutines.delay

suspend fun <T> withRetry(
    maxAttempts: Int = 3,
    initialDelayMs: Long = 1000,
    maxDelayMs: Long = 10000,
    factor: Double = 2.0,
    retryOn: (Exception) -> Boolean = { true },
    block: suspend (attempt: Int) -> T
): T {
    var currentDelay = initialDelayMs
    var lastException: Exception? = null

    repeat(maxAttempts) { attempt ->
        try {
            return block(attempt + 1)
        } catch (e: Exception) {
            lastException = e
            if (attempt == maxAttempts - 1 || !retryOn(e)) throw e
            Logger.debug("Retry attempt ${attempt + 2}/$maxAttempts after ${currentDelay}ms: ${e.message}")
            delay(currentDelay)
            currentDelay = (currentDelay * factor).toLong().coerceAtMost(maxDelayMs)
        }
    }

    throw lastException ?: IllegalStateException("Retry exhausted")
}
