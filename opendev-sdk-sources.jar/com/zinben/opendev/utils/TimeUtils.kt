package com.zinben.opendev.utils

import kotlin.time.Clock
import kotlin.time.Duration
import kotlin.time.DurationUnit
import kotlin.time.ExperimentalTime
import kotlin.time.toDuration

/**
 * 时间处理工具类
 * 完全基于 kotlin.time 库实现
 * 提供跨平台的时间处理功能
 */
object TimeUtils {

    /**
     * 获取当前时间戳（毫秒）
     */
    @OptIn(ExperimentalTime::class)
    fun getCurrentTimeMillis(): Long {
        return Clock.System.now().toEpochMilliseconds()
    }

    /**
     * 获取当前时间戳（秒）
     */
    @OptIn(ExperimentalTime::class)
    fun getCurrentTimeSeconds(): Long {
        return getCurrentTimeMillis() / 1000
    }

    /**
     * 获取当前时间的 ISO 字符串表示
     * 用于数据库存储和数据同步
     * 
     * @return ISO 8601 格式的时间字符串
     */
    @OptIn(ExperimentalTime::class)
    fun getCurrentTimestamp(): String {
        return Clock.System.now().toString()
    }

    /**
     * 获取未来指定天数后的时间戳字符串
     * 
     * @param daysFromNow 从现在开始的天数
     * @return ISO 8601 格式的时间字符串
     */
    @OptIn(ExperimentalTime::class)
    fun getFutureTimestamp(daysFromNow: Int): String {
        val duration = daysFromNow.toDuration(DurationUnit.DAYS)
        return Clock.System.now().plus(duration).toString()
    }

    /**
     * 计算两个时间戳之间的天数差
     */
    fun calculateDaysDifference(timestamp1: Long, timestamp2: Long): Int {
        val diffMillis = kotlin.math.abs(timestamp1 - timestamp2)
        return (diffMillis / (1000 * 60 * 60 * 24)).toInt()
    }

    /**
     * 计算指定时间戳距离现在的天数
     */
    fun getDaysFromNow(targetTimestamp: Long): Int {
        val now = getCurrentTimeMillis()
        val diffMillis = targetTimestamp - now
        return (diffMillis / (1000 * 60 * 60 * 24)).toInt()
    }

    /**
     * 格式化剩余时间显示
     */
    fun formatTimeRemaining(targetTimestamp: Long): String {
        val days = getDaysFromNow(targetTimestamp)
        return when {
            days <= 0 -> "已到期"
            days == 1 -> "明天到期"
            else -> "${days}天后到期"
        }
    }

    /**
     * 检查时间戳是否为今天
     */
    fun isToday(timestamp: Long): Boolean {
        val now = getCurrentTimeMillis()
        val todayStart = (now / (1000 * 60 * 60 * 24)) * (1000 * 60 * 60 * 24)
        val todayEnd = todayStart + (1000 * 60 * 60 * 24) - 1
        return timestamp in todayStart..todayEnd
    }

    /**
     * 检查时间戳是否为明天
     */
    fun isTomorrow(timestamp: Long): Boolean {
        val now = getCurrentTimeMillis()
        val tomorrowStart = ((now / (1000 * 60 * 60 * 24)) + 1) * (1000 * 60 * 60 * 24)
        val tomorrowEnd = tomorrowStart + (1000 * 60 * 60 * 24) - 1
        return timestamp in tomorrowStart..tomorrowEnd
    }

    /**
     * 获取时间戳对应的日期字符串（基于 Unix 时间戳计算）
     */
    fun getDateString(timestamp: Long): String {
        // 基于 Unix 时间戳的简化日期计算
        val daysSinceEpoch = timestamp / (1000 * 60 * 60 * 24)
        val date = calculateDateFromDaysSinceEpoch(daysSinceEpoch)
        return "${date.year}-${date.month.toString().padStart(2, '0')}-${
            date.day.toString().padStart(2, '0')
        }"
    }

    /**
     * 解析日期字符串为时间戳（基于 Unix 时间戳计算）
     */
    fun parseDateString(dateString: String): Long? {
        return try {
            val parts = dateString.split("-")
            if (parts.size == 3) {
                val year = parts[0].toInt()
                val month = parts[1].toInt()
                val day = parts[2].toInt()
                val daysSinceEpoch = calculateDaysSinceEpoch(year, month, day)
                daysSinceEpoch * (1000 * 60 * 60 * 24)
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * 获取当前日期字符串
     */
    fun getCurrentDateString(): String {
        return getDateString(getCurrentTimeMillis())
    }

    /**
     * 计算两个时间戳之间的持续时间
     */
    fun calculateDuration(timestamp1: Long, timestamp2: Long): Duration {
        val diffMillis = timestamp2 - timestamp1
        return diffMillis.toDuration(DurationUnit.MILLISECONDS)
    }

    /**
     * 格式化持续时间显示
     */
    fun formatDuration(duration: Duration): String {
        val days = duration.inWholeDays
        val hours = duration.inWholeHours % 24
        val minutes = duration.inWholeMinutes % 60
        return when {
            days > 0 -> "${days}天${hours}小时"
            hours > 0 -> "${hours}小时${minutes}分钟"
            minutes > 0 -> "${minutes}分钟"
            else -> "刚刚"
        }
    }

    /**
     * 获取当前时间戳对应的日期时间信息
     */
    @OptIn(ExperimentalTime::class)
    fun getCurrentDateTimeInfo(): DateTimeInfo {
        val now = Clock.System.now()
        val timestamp = now.toEpochMilliseconds()
        val dateString = getDateString(timestamp)
        return DateTimeInfo(
            timestamp = timestamp,
            dateString = dateString,
            isToday = true,
            isTomorrow = false
        )
    }

    /**
     * 日期时间信息数据类
     */
    data class DateTimeInfo(
        val timestamp: Long,
        val dateString: String,
        val isToday: Boolean,
        val isTomorrow: Boolean
    )

    /**
     * 日期数据类
     */
    private data class DateInfo(
        val year: Int,
        val month: Int,
        val day: Int
    )

    /**
     * 从 Unix 纪元天数计算日期（简化实现）
     */
    private fun calculateDateFromDaysSinceEpoch(daysSinceEpoch: Long): DateInfo {
        // 简化的日期计算算法
        var days = daysSinceEpoch.toInt()

        // 1970年1月1日是星期四
        val year = 1970 + (days / 365)
        days %= 365

        // 简化的月份计算
        val month = 1 + (days / 30)
        days %= 30

        val day = 1 + days

        return DateInfo(year, month, day)
    }

    /**
     * 计算从 Unix 纪元到指定日期的天数（简化实现）
     */
    private fun calculateDaysSinceEpoch(year: Int, month: Int, day: Int): Long {
        // 简化的反向计算
        val yearDiff = year - 1970
        val monthDiff = month - 1
        val dayDiff = day - 1

        return (yearDiff * 365L + monthDiff * 30L + dayDiff)
    }
}

