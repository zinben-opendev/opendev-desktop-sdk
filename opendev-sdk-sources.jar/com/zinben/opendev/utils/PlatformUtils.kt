package com.zinben.opendev.utils

import com.zinben.opendev.getPlatform

/**
 * 平台工具类 (Core层)
 * 提供纯净的跨平台检测功能，不依赖 UI 库
 */
object PlatformUtils {

    /**
     * 判断当前是否为移动端平台
     * @return true表示移动端（Android/iOS），false表示桌面端（Desktop/Web）
     */
    fun isMobilePlatform(): Boolean {
        val platformName = getPlatform().name
        return platformName.startsWith("Android") || platformName.startsWith("iOS")
    }

    /**
     * 判断当前是否为Android平台
     * @return true表示Android平台
     */
    fun isAndroidPlatform(): Boolean {
        val platformName = getPlatform().name
        return platformName.startsWith("Android")
    }

    /**
     * 判断当前是否为iOS平台
     * @return true表示iOS平台
     */
    fun isIOSPlatform(): Boolean {
        val platformName = getPlatform().name
        return platformName.startsWith("iOS")
    }

    /**
     * 判断当前是否为桌面端平台
     * @return true表示桌面端（Desktop/Web），false表示移动端
     */
    fun isDesktopPlatform(): Boolean {
        return !isMobilePlatform()
    }

    /**
     * 获取当前平台名称
     * @return 平台名称字符串
     */
    fun getCurrentPlatformName(): String {
        return getPlatform().name
    }
}

