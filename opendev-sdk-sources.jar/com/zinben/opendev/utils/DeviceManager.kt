package com.zinben.opendev.utils

import com.zinben.opendev.logger.Logger
import com.zinben.opendev.storage.KVUserDefault
import com.zinben.opendev.utils.TimeUtils
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.random.Random

/**
 * 设备管理模块
 * 统一管理设备ID的生成和获取
 */
object DeviceManager {
    private const val DEVICE_ID_KEY = "sdk_guest_device_id"
    private val mutex = Mutex()
    private var cachedDeviceId: String? = null

    /**
     * 获取或创建设备ID
     * 如果设备ID已存在，直接返回；否则创建新的设备ID并持久化
     * 
     * @return 设备ID
     */
    suspend fun getOrCreateDeviceId(): String {
        return mutex.withLock {
            // 先检查缓存
            if (cachedDeviceId != null) {
                Logger.debug("DeviceManager: Using cached device ID")
                return@withLock cachedDeviceId!!
            }

            // 从持久化存储中获取
            val existing = KVUserDefault.get<String>(DEVICE_ID_KEY)
            if (!existing.isNullOrBlank()) {
                Logger.debug("DeviceManager: Found existing device ID")
                cachedDeviceId = existing
                return@withLock existing
            }

            // 创建新的设备ID
            val newId = generateDeviceId()
            KVUserDefault.set(DEVICE_ID_KEY, newId)
            cachedDeviceId = newId
            Logger.debug("DeviceManager: Created new device ID: $newId")
            newId
        }
    }

    /**
     * 获取当前设备ID（不创建）
     * 
     * @return 设备ID，如果不存在则返回 null
     */
    suspend fun getDeviceId(): String? {
        return mutex.withLock {
            // 先检查缓存
            if (cachedDeviceId != null) {
                return@withLock cachedDeviceId
            }

            // 从持久化存储中获取
            val existing = KVUserDefault.get<String>(DEVICE_ID_KEY)
            if (!existing.isNullOrBlank()) {
                cachedDeviceId = existing
                return@withLock existing
            }

            null
        }
    }

    /**
     * 清除设备ID（用于测试或重置场景）
     */
    suspend fun clearDeviceId() {
        mutex.withLock {
            KVUserDefault.remove<String>(DEVICE_ID_KEY)
            cachedDeviceId = null
            Logger.debug("DeviceManager: Device ID cleared")
        }
    }

    /**
     * 生成新的设备ID
     * 格式：device_{timestamp}_{random}
     */
    private fun generateDeviceId(): String {
        val timestampPart = TimeUtils.getCurrentTimeMillis().toString(16)
        val randomBytes = Random.nextBytes(8)
        val randomPart = randomBytes.joinToString("") { byte ->
            byte.toUByte().toString(16).padStart(2, '0')
        }
        return "device_${timestampPart}_$randomPart"
    }
}

