package com.zinben.opendev.storage

import java.io.File

actual fun dataStorePath(name: String): String {
    val home = System.getProperty("user.home")
    val dir = File(home, ".walknote/datastore")
    if (!dir.exists()) dir.mkdirs()
    return File(dir, name).path
} 