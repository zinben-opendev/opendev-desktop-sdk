package com.zinben.opendev.storage

actual class KVLocalDataStore {

    val localDataStore = LocalDataStore.instance

    actual suspend inline fun <reified T> get(key: String, namespace: String): T? {
        return localDataStore.get(namespace, key)
    }

    actual suspend inline fun <reified T> set(key: String, value: T, namespace: String) {
        localDataStore.set(namespace, key, value)
    }

    actual suspend inline fun <reified T> remove(key: String, namespace: String) {
        localDataStore.remove<T>(namespace, key)
    }

    actual suspend inline fun <reified T> clear(namespace: String) {
        localDataStore.clear(namespace)
    }

    actual suspend inline fun <reified T> contains(key: String, namespace: String): Boolean {
        return localDataStore.contains<T>(namespace, key)
    }
}