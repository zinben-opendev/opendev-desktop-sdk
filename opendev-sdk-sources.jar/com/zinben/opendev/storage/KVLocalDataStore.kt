package com.zinben.opendev.storage

const val DEFAULT_NAMESPACE = "default"

expect class KVLocalDataStore() {

    suspend inline fun <reified T> get(key: String, namespace: String = DEFAULT_NAMESPACE): T?

    suspend inline fun <reified T> set(key: String, value: T, namespace: String = DEFAULT_NAMESPACE)

    suspend inline fun <reified T> remove(key: String, namespace: String = DEFAULT_NAMESPACE)

    suspend inline fun <reified T> clear(namespace: String = DEFAULT_NAMESPACE)

    suspend inline fun <reified T> contains(
        key: String,
        namespace: String = DEFAULT_NAMESPACE
    ): Boolean

}

object KVLocalDataStoreProvider {
    val instance: KVLocalDataStore by lazy { KVLocalDataStore() }
}

val KVUserDefault: KVLocalDataStore
    get() = KVLocalDataStoreProvider.instance