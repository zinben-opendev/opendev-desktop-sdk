package com.zinben.opendev.storage

import com.zinben.opendev.storage.LocalDataStore

class DataStoreTokenStorage : TokenStorage {
    private val store = LocalDataStore.instance
    private val NAMESPACE = "auth_prefs"
    private val TOKEN_KEY = "access_token"

    override suspend fun saveToken(token: String) {
        store.set(NAMESPACE, TOKEN_KEY, token)
    }

    override suspend fun getToken(): String? {
        return try {
            store.get<String>(NAMESPACE, TOKEN_KEY)
        } catch (e: Exception) {
            null
        }
    }

    override suspend fun clearToken() {
        store.remove<String>(NAMESPACE, TOKEN_KEY)
    }
}

