package com.zinben.opendev.storage

import com.zinben.opendev.logger.Logger
import com.zinben.opendev.models.SavedAccount
import com.zinben.opendev.models.SavedLoginMethod
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Persistent store for [SavedAccount] metadata — **physically isolated** from
 * [TokenStorage] and [com.zinben.opendev.db.LocalDatabase] auth data.
 *
 * §11 reliability constraint: [com.zinben.opendev.managers.AuthManager.clearLocalAuth],
 * `logout()`, and `initialize()` failure paths MUST NOT call [clearAll].
 * Only explicit user action (e.g. "forget all accounts on this device") may invoke it.
 *
 * Uses [KVLocalDataStore] with a dedicated namespace so that
 * `KVLocalDataStore.clear<T>(namespace = "token")` or similar operations
 * in other namespaces cannot affect saved accounts.
 */
class SavedAccountStore(
    private val kvStore: KVLocalDataStore = KVLocalDataStoreProvider.instance,
    private val maxAccounts: Int = DEFAULT_MAX_ACCOUNTS
) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    companion object {
        private const val NAMESPACE = "saved_accounts"
        private const val LIST_KEY = "account_list"
        const val DEFAULT_MAX_ACCOUNTS = 5
    }

    suspend fun getAll(): List<SavedAccount> {
        return try {
            val raw: String? = kvStore.get(LIST_KEY, NAMESPACE)
            if (raw.isNullOrBlank()) return emptyList()
            json.decodeFromString<List<SavedAccount>>(raw)
        } catch (e: Exception) {
            Logger.error("SavedAccountStore: Failed to read saved accounts: ${e.message}")
            emptyList()
        }
    }

    /**
     * Insert or update a saved account. Enforces LRU eviction at [maxAccounts].
     *
     * **A11 guest guard**: callers MUST NOT invoke this for pure guest accounts
     * (`loginMethod == GUEST && boundProviders.isEmpty()`). The guard is enforced
     * at the call-site in [com.zinben.opendev.managers.AuthManager].
     */
    suspend fun upsert(account: SavedAccount) {
        try {
            val current = getAll().toMutableList()
            current.removeAll { it.userId == account.userId }
            current.add(0, account)
            val trimmed = current.take(maxAccounts)
            persist(trimmed)
            Logger.debug("SavedAccountStore: Upserted account ${account.userId}, total=${trimmed.size}")
        } catch (e: Exception) {
            Logger.error("SavedAccountStore: Failed to upsert account: ${e.message}")
        }
    }

    suspend fun remove(userId: String) {
        try {
            val current = getAll().toMutableList()
            val removed = current.removeAll { it.userId == userId }
            if (removed) {
                persist(current)
                Logger.debug("SavedAccountStore: Removed account $userId")
            }
        } catch (e: Exception) {
            Logger.error("SavedAccountStore: Failed to remove account: ${e.message}")
        }
    }

    /**
     * Remove ALL saved accounts from this device.
     *
     * **§11**: This MUST NOT be called from `clearLocalAuth()`, `logout()`,
     * or `initialize()` failure paths. Only explicit user/host action.
     */
    suspend fun clearAll() {
        try {
            kvStore.remove<String>(LIST_KEY, NAMESPACE)
            Logger.debug("SavedAccountStore: Cleared all saved accounts")
        } catch (e: Exception) {
            Logger.error("SavedAccountStore: Failed to clear all accounts: ${e.message}")
        }
    }

    private suspend fun persist(accounts: List<SavedAccount>) {
        val raw = json.encodeToString(accounts)
        kvStore.set(LIST_KEY, raw, NAMESPACE)
    }
}
