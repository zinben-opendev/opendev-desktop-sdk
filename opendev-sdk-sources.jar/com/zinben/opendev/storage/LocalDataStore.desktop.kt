package com.zinben.opendev.storage

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class LocalDataStore private constructor() {
    companion object {
        const val DEFAULT_NAMESPACE = "default"
        val instance by lazy {
            LocalDataStore()
        }
    }

    private val dataStoreMap: MutableMap<String, DataStore<Preferences>> by lazy {
        mutableMapOf()
    }

    private val mutex by lazy { Mutex() }

    suspend inline fun <reified T> get(namespace: String = DEFAULT_NAMESPACE, key: String): T? {
        return when (T::class) {
            Int::class -> {
                val intKey = intPreferencesKey(key)
                getDataStore(namespace).data.map { preferences ->
                    preferences[intKey]
                }.first() as T
            }

            Long::class -> {
                val longKey = longPreferencesKey(key)
                getDataStore(namespace).data.map { preferences ->
                    preferences[longKey]
                }.first() as T
            }

            Boolean::class -> {
                val booleanKey = booleanPreferencesKey(key)
                getDataStore(namespace).data.map { preferences ->
                    preferences[booleanKey]
                }.first() as T
            }

            String::class -> {
                val stringKey = stringPreferencesKey(key)
                getDataStore(namespace).data.map { preferences ->
                    preferences[stringKey]
                }.first() as T
            }

            Float::class -> {
                val floatKey = floatPreferencesKey(key)
                getDataStore(namespace).data.map { preferences ->
                    preferences[floatKey]
                }.first() as T
            }

            else -> {
                val stringKey = stringPreferencesKey(key)
                val json = getDataStore(namespace).data.map { preferences ->
                    preferences[stringKey]
                }.first()
                // 这里需要你实现decodeFromString<T>()
                null
            }
        }
    }

    suspend inline fun <reified T> set(
        namespace: String = DEFAULT_NAMESPACE,
        key: String,
        value: T
    ) {
        when (value) {
            is Int -> {
                val intKey = intPreferencesKey(key)
                getDataStore(namespace).edit { preferences ->
                    preferences[intKey] = value
                }
            }

            is Long -> {
                val longKey = longPreferencesKey(key)
                getDataStore(namespace).edit { preferences ->
                    preferences[longKey] = value
                }
            }

            is Boolean -> {
                val booleanKey = booleanPreferencesKey(key)
                getDataStore(namespace).edit { preferences ->
                    preferences[booleanKey] = value
                }
            }

            is String -> {
                val stringKey = stringPreferencesKey(key)
                getDataStore(namespace).edit { preferences ->
                    preferences[stringKey] = value
                }
            }

            is Float -> {
                val floatKey = floatPreferencesKey(key)
                getDataStore(namespace).edit { preferences ->
                    preferences[floatKey] = value
                }
            }

            else -> {
                val stringKey = stringPreferencesKey(key)
                // 这里需要你实现encodeToString()
                val json = value.toString()
                getDataStore(namespace).edit { preferences ->
                    preferences[stringKey] = json
                }
            }
        }
    }

    suspend inline fun <reified T> remove(namespace: String = DEFAULT_NAMESPACE, key: String) {
        when (T::class) {
            Int::class -> {
                val intKey = intPreferencesKey(key)
                getDataStore(namespace).edit { preferences ->
                    preferences.remove(intKey)
                }
            }

            Long::class -> {
                val longKey = longPreferencesKey(key)
                getDataStore(namespace).edit { preferences ->
                    preferences.remove(longKey)
                }
            }

            Boolean::class -> {
                val booleanKey = booleanPreferencesKey(key)
                getDataStore(namespace).edit { preferences ->
                    preferences.remove(booleanKey)
                }
            }

            String::class -> {
                val stringKey = stringPreferencesKey(key)
                getDataStore(namespace).edit { preferences ->
                    preferences.remove(stringKey)
                }
            }

            Float::class -> {
                val floatKey = floatPreferencesKey(key)
                getDataStore(namespace).edit { preferences ->
                    preferences.remove(floatKey)
                }
            }

            else -> {
                val stringKey = stringPreferencesKey(key)
                getDataStore(namespace).edit { preferences ->
                    preferences.remove(stringKey)
                }
            }
        }
    }

    suspend fun clear(namespace: String = DEFAULT_NAMESPACE) {
        getDataStore(namespace).edit { preferences ->
            preferences.clear()
        }
    }

    suspend inline fun <reified T> contains(
        namespace: String = DEFAULT_NAMESPACE,
        key: String
    ): Boolean {
        return when (T::class) {
            Int::class -> {
                val intKey = intPreferencesKey(key)
                getDataStore(namespace).data.map { preferences ->
                    preferences.contains(intKey)
                }.first()
            }

            Long::class -> {
                val longKey = longPreferencesKey(key)
                getDataStore(namespace).data.map { preferences ->
                    preferences.contains(longKey)
                }.first()
            }

            Boolean::class -> {
                val booleanKey = booleanPreferencesKey(key)
                getDataStore(namespace).data.map { preferences ->
                    preferences.contains(booleanKey)
                }.first()
            }

            String::class -> {
                val stringKey = stringPreferencesKey(key)
                getDataStore(namespace).data.map { preferences ->
                    preferences.contains(stringKey)
                }.first()
            }

            Float::class -> {
                val floatKey = floatPreferencesKey(key)
                getDataStore(namespace).data.map { preferences ->
                    preferences.contains(floatKey)
                }.first()
            }

            else -> {
                val stringKey = stringPreferencesKey(key)
                getDataStore(namespace).data.map { preferences ->
                    preferences.contains(stringKey)
                }.first()
            }
        }
    }

    suspend fun getDataStore(namespace: String = DEFAULT_NAMESPACE): DataStore<Preferences> {
        return mutex.withLock {
            (if (dataStoreMap[namespace] == null) {
                val dataStore = dataStorePreferences(
                    path = namespace,
                )
                dataStoreMap[namespace] = dataStore
                dataStore
            } else {
                dataStoreMap[namespace]!!
            })
        }
    }
}

