package com.zinben.opendev.storage

actual fun createTokenStorage(): TokenStorage = DataStoreTokenStorage()

