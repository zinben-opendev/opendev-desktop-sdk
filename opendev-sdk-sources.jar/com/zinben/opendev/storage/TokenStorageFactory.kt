package com.zinben.opendev.storage

expect fun createTokenStorage(): TokenStorage

