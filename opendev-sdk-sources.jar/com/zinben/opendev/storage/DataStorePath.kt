package com.zinben.opendev.storage

expect fun dataStorePath(name: String): String 