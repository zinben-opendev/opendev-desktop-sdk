package com.zinben.opendev.providers

import com.zinben.opendev.models.PlatformAuthResult
import com.zinben.opendev.models.PlatformUserInfo

/**
 * 原生认证提供商接口（旧版）
 * 
 * @deprecated 请迁移到 [com.zinben.opendev.auth.AuthProvider]，它提供统一的
 * providerId、AuthCredential 和 AuthProviderRegistry 机制。
 * 
 * 定义跨平台原生 SDK 集成的标准接口。
 * 所有平台的原生三方 SDK 集成（如 Google、Facebook、Apple Sign-In 等）必须实现此接口。
 * 
 * ## 设计原则
 * 1. **平台无关性**：接口定义在 commonMain，具体实现在各平台
 * 2. **统一数据模型**：使用 PlatformAuthResult/PlatformUserInfo 保持与浏览器方案一致
 * 3. **降级策略**：支持检测能力，便于降级到浏览器轮询方案
 * 4. **扩展性**：为后续添加新的第三方提供商预留标准接口
 * 
 * ## 使用场景
 * - Android: Credential Manager (Google), Facebook SDK, WeChat SDK
 * - iOS: Sign in with Apple, Google Sign-In iOS SDK, Facebook SDK
 * 
 * ## 实现示例
 * ```kotlin
 * class GoogleSignInProvider(private val config: PlatformConfig) : NativeAuthProvider {
 *     override fun isSupported(): Boolean = checkGooglePlayServices()
 *     override suspend fun authenticate(userId: String?) = performGoogleSignIn()
 *     override suspend fun getUserInfo() = cachedGoogleUserInfo
 *     override suspend fun signOut() = googleSignInClient.signOut()
 * }
 * ```
 */
interface NativeAuthProvider {
    /**
     * 检查当前平台是否支持此原生提供商
     * 
     * 此方法用于在运行时检测：
     * - SDK 是否已配置（如 Client ID）
     * - 平台服务是否可用（如 Google Play Services）
     * - 设备是否满足要求（如 iOS 版本）
     * 
     * @return true 表示支持，可以使用原生登录；false 表示不支持，需降级到浏览器方案
     */
    fun isSupported(): Boolean

    /**
     * 执行原生认证流程
     * 
     * 此方法会触发平台原生的登录 UI（如 Android Credential Manager、iOS Sign In sheet）。
     * 
     * @param userId 可选的用户 ID，用于多账号场景或指定账号登录
     * @return PlatformAuthResult 认证结果，包含：
     *   - Success: 认证成功，包含 Token 和用户信息
     *   - Failure: 认证失败，包含错误码和错误消息
     *   - Cancelled: 用户取消了认证
     * 
     * ## 错误码规范
     * - `NO_CREDENTIAL_AVAILABLE`: 无可用凭据（如未配置 Google 账号）
     * - `PROVIDER_CONFIG_ERROR`: 提供商配置错误（如 OAuth Client ID 未配置）
     * - `NETWORK_ERROR`: 网络错误
     * - `USER_CANCELLED`: 用户取消
     * - `SDK_NOT_INITIALIZED`: SDK 未初始化
     */
    suspend fun authenticate(userId: String? = null): PlatformAuthResult

    /**
     * 获取已登录用户的信息
     * 
     * 注意：
     * - 部分原生 SDK 在 authenticate 后会缓存用户信息，此方法直接返回缓存
     * - 部分 SDK 需要重新请求用户信息
     * - 如果用户未登录或已过期，返回 null
     * 
     * @return PlatformUserInfo? 用户信息，未登录返回 null
     */
    suspend fun getUserInfo(): PlatformUserInfo?
    
    /**
     * 登出并清理原生 SDK 状态
     * 
     * 此方法会：
     * - 清除原生 SDK 的登录状态
     * - 清除缓存的用户信息
     * - 清除本地凭据（如 Android Credential Manager）
     * 
     * 注意：此方法仅清理本地状态，不会调用后端登出接口
     */
    suspend fun signOut()
}
