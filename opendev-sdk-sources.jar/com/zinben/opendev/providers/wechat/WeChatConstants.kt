package com.zinben.opendev.providers.wechat

internal const val WECHAT_AUTH_NOTIFICATION_NAME = "WeChatAuthResponseNotification"

