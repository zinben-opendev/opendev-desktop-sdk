package com.zinben.opendev.providers.wechat

import com.zinben.opendev.factories.PlatformConfig
import com.zinben.opendev.models.PlatformAuthResult
import com.zinben.opendev.models.PlatformUserInfo
import com.zinben.opendev.models.ThirdPartyProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal suspend fun fetchWeChatProfile(
    config: PlatformConfig,
    authorizationCode: String
): PlatformAuthResult = withContext(Dispatchers.Default) {
    if (config.wechatAppId.isBlank() || config.wechatAppSecret.isBlank()) {
        return@withContext PlatformAuthResult.Failure(
            errorCode = "CONFIG_UNAVAILABLE",
            errorMessage = "WeChat App ID or Secret is not configured"
        )
    }

    val tokenResponse = WeChatApiClient.exchangeCode(
        appId = config.wechatAppId,
        appSecret = config.wechatAppSecret,
        code = authorizationCode
    ) ?: return@withContext PlatformAuthResult.Failure(
        errorCode = "TOKEN_REQUEST_FAILED",
        errorMessage = "Failed to exchange WeChat authorization code"
    )

    if (tokenResponse.errorCode != null) {
        return@withContext PlatformAuthResult.Failure(
            errorCode = tokenResponse.errorCode.toString(),
            errorMessage = tokenResponse.errorMessage ?: "WeChat authorization failed"
        )
    }

    val accessToken = tokenResponse.accessToken
    val openId = tokenResponse.openId

    if (accessToken.isNullOrBlank() || openId.isNullOrBlank()) {
        return@withContext PlatformAuthResult.Failure(
            errorCode = "INVALID_TOKEN",
            errorMessage = "WeChat access token or open id is empty"
        )
    }

    val userInfoResponse = WeChatApiClient.fetchUserInfo(accessToken, openId)
        ?: return@withContext PlatformAuthResult.Failure(
            errorCode = "USERINFO_REQUEST_FAILED",
            errorMessage = "Failed to fetch WeChat user info"
        )

    if (userInfoResponse.errorCode != null) {
        return@withContext PlatformAuthResult.Failure(
            errorCode = userInfoResponse.errorCode.toString(),
            errorMessage = userInfoResponse.errorMessage ?: "Failed to fetch WeChat user info"
        )
    }

    val providerUserId = userInfoResponse.unionId ?: userInfoResponse.openId ?: openId
    val nickname = userInfoResponse.nickname ?: "WeChat User"

    val info = PlatformUserInfo(
        providerUserId = providerUserId,
        username = nickname,
        email = null,
        avatar = userInfoResponse.avatarUrl,
        nickname = nickname,
        provider = ThirdPartyProvider.WECHAT
    )

    PlatformAuthResult.Success(
        providerUserId = providerUserId,
        accessToken = accessToken,
        userInfo = info
    )
}

