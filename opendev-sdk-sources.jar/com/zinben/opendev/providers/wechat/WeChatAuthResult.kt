package com.zinben.opendev.providers.wechat

internal sealed class WeChatAuthResult {
    data class Success(val code: String) : WeChatAuthResult()
    object Cancelled : WeChatAuthResult()
    data class Failure(val errorCode: String, val errorMessage: String) : WeChatAuthResult()
}

