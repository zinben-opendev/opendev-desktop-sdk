package com.zinben.opendev.providers.wechat

import com.zinben.opendev.logger.Logger
import com.zinben.opendev.network.URLSession
import io.ktor.client.call.body
import io.ktor.client.request.get
import io.ktor.client.request.parameter
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

internal object WeChatApiClient {
    private const val TOKEN_URL = "https://api.weixin.qq.com/sns/oauth2/access_token"
    private const val USER_INFO_URL = "https://api.weixin.qq.com/sns/userinfo"

    suspend fun exchangeCode(
        appId: String,
        appSecret: String,
        code: String
    ): WeChatTokenResponse? {
        return runCatching {
            URLSession.get(TOKEN_URL) {
                parameter("appid", appId)
                parameter("secret", appSecret)
                parameter("code", code)
                parameter("grant_type", "authorization_code")
            }.body<WeChatTokenResponse>()
        }.onFailure { error ->
            Logger.error("WeChatApiClient: Failed to exchange code -> ${error.message}")
        }.getOrNull()
    }

    suspend fun fetchUserInfo(
        accessToken: String,
        openId: String
    ): WeChatUserInfoResponse? {
        return runCatching {
            URLSession.get(USER_INFO_URL) {
                parameter("access_token", accessToken)
                parameter("openid", openId)
                parameter("lang", "zh_CN")
            }.body<WeChatUserInfoResponse>()
        }.onFailure { error ->
            Logger.error("WeChatApiClient: Failed to fetch user info -> ${error.message}")
        }.getOrNull()
    }
}

@Serializable
internal data class WeChatTokenResponse(
    @SerialName("access_token") val accessToken: String? = null,
    @SerialName("expires_in") val expiresIn: Long? = null,
    @SerialName("refresh_token") val refreshToken: String? = null,
    @SerialName("openid") val openId: String? = null,
    @SerialName("scope") val scope: String? = null,
    @SerialName("unionid") val unionId: String? = null,
    @SerialName("errcode") val errorCode: Int? = null,
    @SerialName("errmsg") val errorMessage: String? = null
)

@Serializable
internal data class WeChatUserInfoResponse(
    @SerialName("openid") val openId: String? = null,
    @SerialName("nickname") val nickname: String? = null,
    @SerialName("headimgurl") val avatarUrl: String? = null,
    @SerialName("unionid") val unionId: String? = null,
    @SerialName("errcode") val errorCode: Int? = null,
    @SerialName("errmsg") val errorMessage: String? = null
)

