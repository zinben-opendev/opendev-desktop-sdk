package com.zinben.opendev

import com.zinben.opendev.models.AuthResult
import com.zinben.opendev.models.BoundAccountInfo
import com.zinben.opendev.models.OtpSendResult
import com.zinben.opendev.models.OtpTargetType
import com.zinben.opendev.models.SavedAccount
import com.zinben.opendev.models.ThirdPartyProvider
import com.zinben.opendev.models.User
import kotlinx.coroutines.flow.StateFlow

/**
 * 认证子 API — 通过 [OpenDevSDK.auth] 访问。
 *
 * 包装 [OpenDevClient] 的认证、用户管理、OTP 等能力，
 * 外部不应直接操作 [OpenDevClient]。
 */
class OpenDevAuth @InternalOpenDevApi constructor(
    private val client: OpenDevClient,
) {
    // ==================== 状态观察 ====================

    val initializationState: StateFlow<InitializationState> get() = client.initializationState
    val loginState: StateFlow<LoginState> get() = client.loginState
    val currentUser: StateFlow<User?> get() = client.currentUser
    val showLoginDialog: StateFlow<LoginUIDialogState?> get() = client.showLoginDialog
    val guestLoginEnabled: Boolean get() = client.guestLoginEnabled

    // ==================== 认证 ====================

    suspend fun login(method: LoginMethod = LoginMethod.GUEST): Result<AuthResult> =
        client.login(method)

    suspend fun loginUI(onResult: (Result<AuthResult>) -> Unit) =
        client.loginUI(onResult)

    suspend fun handleLoginDialogAction(method: LoginMethod) =
        client.handleLoginDialogAction(method)

    fun dismissLoginDialog() =
        client.dismissLoginDialog()

    suspend fun logout(): Result<Unit> =
        client.logout()

    suspend fun switchToGuest(): Result<Unit> =
        client.switchToGuest()

    suspend fun selectAccount(user: User): Result<AuthResult> =
        client.selectAccount(user)

    suspend fun refreshToken(): AuthResult =
        client.refreshToken()

    suspend fun enableAutoLogin() =
        client.enableAutoLogin()

    suspend fun ensureLoggedIn(onResult: ((Result<AuthResult>) -> Unit)? = null) =
        client.ensureLoggedIn(onResult)

    // ==================== 账号绑定 ====================

    suspend fun bindProvider(provider: ThirdPartyProvider): Result<AuthResult> =
        client.bindProvider(provider)

    suspend fun unbindProvider(provider: ThirdPartyProvider): Result<AuthResult> =
        client.unbindProvider(provider)

    suspend fun bindOtp(targetType: OtpTargetType, target: String): Result<AuthResult> =
        client.bindOtp(targetType, target)

    suspend fun unbindOtp(targetType: OtpTargetType, target: String): Result<AuthResult> =
        client.unbindOtp(targetType, target)

    // ==================== OTP ====================

    suspend fun sendOtp(
        targetType: OtpTargetType,
        target: String,
        channelKey: String? = null,
    ): Result<OtpSendResult> = client.sendOtp(targetType, target, channelKey)

    suspend fun verifyOtpAndLogin(
        targetType: OtpTargetType,
        target: String,
        sessionId: String,
        code: String,
        channelKey: String? = null,
    ): Result<AuthResult> = client.verifyOtpAndLogin(targetType, target, sessionId, code, channelKey)

    // ==================== 用户信息 ====================

    fun getCurrentUser(): User? = client.getCurrentUser()

    fun isLoggedIn(): Boolean = client.isLoggedIn()

    fun getAccessToken(): String? = client.getAccessToken()

    fun getTokenInfo(): TokenInfo? = client.getTokenInfo()

    suspend fun getAvailableLoginMethods(channelKey: String? = null): AvailableLoginMethods =
        client.getAvailableLoginMethods(channelKey)

    suspend fun getSupportedAuthProviders(): List<ThirdPartyProvider> =
        client.getSupportedAuthProviders()

    suspend fun updateProfile(
        username: String,
        nickname: String? = null,
        avatar: String? = null,
    ): Result<User> = client.updateProfile(username, nickname, avatar)

    suspend fun uploadAvatar(
        imageBytes: ByteArray,
        fileName: String,
        mimeType: String,
    ): Result<User> = client.uploadAvatar(imageBytes, fileName, mimeType)

    suspend fun refreshLoginState() = client.refreshLoginState()

    // ==================== Saved Accounts ====================

    suspend fun listSavedAccounts(): List<SavedAccount> =
        client.listSavedAccounts()

    suspend fun removeSavedAccount(userId: String) =
        client.removeSavedAccount(userId)

    suspend fun clearAllSavedAccounts() =
        client.clearAllSavedAccounts()
}
