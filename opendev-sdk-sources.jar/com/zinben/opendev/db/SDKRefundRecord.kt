package com.zinben.opendev.db

import kotlin.Long
import kotlin.String

public data class SDKRefundRecord(
  public val id: String,
  public val transaction_id: String,
  public val order_id: String,
  public val amount_value: String,
  public val currency: String,
  public val reason: String?,
  public val status: String,
  public val refund_time: Long?,
  public val created_at: Long,
  public val updated_at: Long,
)
