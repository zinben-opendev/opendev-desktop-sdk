package com.zinben.opendev.db

import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import kotlin.Any
import kotlin.Long
import kotlin.String

public class SDKPaymentResultQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun <T : Any> selectPaymentResultByTransactionId(transaction_id: String, mapper: (
    transaction_id: String,
    order_id: String,
    amount_value: String,
    currency: String,
    payment_time: Long,
  ) -> T): Query<T> = SelectPaymentResultByTransactionIdQuery(transaction_id) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!,
      cursor.getLong(4)!!
    )
  }

  public fun selectPaymentResultByTransactionId(transaction_id: String): Query<SDKPaymentResult> = selectPaymentResultByTransactionId(transaction_id, ::SDKPaymentResult)

  public fun <T : Any> selectPaymentResultByOrderId(order_id: String, mapper: (
    transaction_id: String,
    order_id: String,
    amount_value: String,
    currency: String,
    payment_time: Long,
  ) -> T): Query<T> = SelectPaymentResultByOrderIdQuery(order_id) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!,
      cursor.getLong(4)!!
    )
  }

  public fun selectPaymentResultByOrderId(order_id: String): Query<SDKPaymentResult> = selectPaymentResultByOrderId(order_id, ::SDKPaymentResult)

  public fun <T : Any> selectAllPaymentResults(mapper: (
    transaction_id: String,
    order_id: String,
    amount_value: String,
    currency: String,
    payment_time: Long,
  ) -> T): Query<T> = Query(1_426_000_602, arrayOf("SDKPaymentResult"), driver, "SDKPaymentResult.sq", "selectAllPaymentResults", "SELECT SDKPaymentResult.transaction_id, SDKPaymentResult.order_id, SDKPaymentResult.amount_value, SDKPaymentResult.currency, SDKPaymentResult.payment_time FROM SDKPaymentResult") { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!,
      cursor.getLong(4)!!
    )
  }

  public fun selectAllPaymentResults(): Query<SDKPaymentResult> = selectAllPaymentResults(::SDKPaymentResult)

  /**
   * @return The number of rows updated.
   */
  public fun insertOrReplacePaymentResult(
    transaction_id: String,
    order_id: String,
    amount_value: String,
    currency: String,
    payment_time: Long,
  ): QueryResult<Long> {
    val result = driver.execute(1_101_291_974, """
        |INSERT OR REPLACE INTO SDKPaymentResult(transaction_id, order_id, amount_value, currency, payment_time)
        |VALUES (?, ?, ?, ?, ?)
        """.trimMargin(), 5) {
          var parameterIndex = 0
          bindString(parameterIndex++, transaction_id)
          bindString(parameterIndex++, order_id)
          bindString(parameterIndex++, amount_value)
          bindString(parameterIndex++, currency)
          bindLong(parameterIndex++, payment_time)
        }
    notifyQueries(1_101_291_974) { emit ->
      emit("SDKPaymentResult")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deletePaymentResultByTransactionId(transaction_id: String): QueryResult<Long> {
    val result = driver.execute(-79_180_283, """DELETE FROM SDKPaymentResult WHERE transaction_id = ?""", 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, transaction_id)
        }
    notifyQueries(-79_180_283) { emit ->
      emit("SDKPaymentResult")
    }
    return result
  }

  private inner class SelectPaymentResultByTransactionIdQuery<out T : Any>(
    public val transaction_id: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("SDKPaymentResult", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("SDKPaymentResult", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-262_452_778, """SELECT SDKPaymentResult.transaction_id, SDKPaymentResult.order_id, SDKPaymentResult.amount_value, SDKPaymentResult.currency, SDKPaymentResult.payment_time FROM SDKPaymentResult WHERE transaction_id = ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, transaction_id)
    }

    override fun toString(): String = "SDKPaymentResult.sq:selectPaymentResultByTransactionId"
  }

  private inner class SelectPaymentResultByOrderIdQuery<out T : Any>(
    public val order_id: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("SDKPaymentResult", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("SDKPaymentResult", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(1_213_633_542, """SELECT SDKPaymentResult.transaction_id, SDKPaymentResult.order_id, SDKPaymentResult.amount_value, SDKPaymentResult.currency, SDKPaymentResult.payment_time FROM SDKPaymentResult WHERE order_id = ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, order_id)
    }

    override fun toString(): String = "SDKPaymentResult.sq:selectPaymentResultByOrderId"
  }
}
