package com.zinben.opendev.db

import app.cash.sqldelight.Transacter
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.db.SqlSchema
import com.zinben.opendev.db.core.newInstance
import com.zinben.opendev.db.core.schema
import kotlin.Unit

public interface SDKDatabase : Transacter {
  public val sDKPaymentOrderQueries: SDKPaymentOrderQueries

  public val sDKPaymentResultQueries: SDKPaymentResultQueries

  public val sDKRefundRecordQueries: SDKRefundRecordQueries

  public val sDKTransactionQueries: SDKTransactionQueries

  public val sDKUserQueries: SDKUserQueries

  public companion object {
    public val Schema: SqlSchema<QueryResult.Value<Unit>>
      get() = SDKDatabase::class.schema

    public operator fun invoke(driver: SqlDriver): SDKDatabase = SDKDatabase::class.newInstance(driver)
  }
}
