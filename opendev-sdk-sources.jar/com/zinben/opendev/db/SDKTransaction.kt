package com.zinben.opendev.db

import kotlin.Long
import kotlin.String

public data class SDKTransaction(
  public val transaction_id: String,
  public val product_id: String,
  public val user_id: String,
  public val platform: String,
  public val purchase_time: Long,
  public val original_transaction_id: String?,
  public val is_restored: Long,
  public val is_finished: Long,
  public val receipt: String?,
  public val signature: String?,
  public val purchase_token: String?,
)
