package com.zinben.opendev.db

import kotlin.Long
import kotlin.String

public data class SDKPaymentOrder(
  public val id: String,
  public val user_id: String,
  public val product_id: String,
  public val product_name: String,
  public val product_description: String?,
  public val amount_value: String,
  public val currency: String,
  public val payment_method: String,
  public val platform: String,
  public val status: String,
  public val created_at: Long,
  public val updated_at: Long,
  public val expires_at: Long?,
  public val metadata: String?,
)
