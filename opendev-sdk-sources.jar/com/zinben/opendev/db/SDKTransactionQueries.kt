package com.zinben.opendev.db

import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import kotlin.Any
import kotlin.Long
import kotlin.String

public class SDKTransactionQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun <T : Any> selectTransactionByTransactionId(transaction_id: String, mapper: (
    transaction_id: String,
    product_id: String,
    user_id: String,
    platform: String,
    purchase_time: Long,
    original_transaction_id: String?,
    is_restored: Long,
    is_finished: Long,
    receipt: String?,
    signature: String?,
    purchase_token: String?,
  ) -> T): Query<T> = SelectTransactionByTransactionIdQuery(transaction_id) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!,
      cursor.getLong(4)!!,
      cursor.getString(5),
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getString(8),
      cursor.getString(9),
      cursor.getString(10)
    )
  }

  public fun selectTransactionByTransactionId(transaction_id: String): Query<SDKTransaction> = selectTransactionByTransactionId(transaction_id, ::SDKTransaction)

  public fun <T : Any> selectTransactionByProductId(product_id: String, mapper: (
    transaction_id: String,
    product_id: String,
    user_id: String,
    platform: String,
    purchase_time: Long,
    original_transaction_id: String?,
    is_restored: Long,
    is_finished: Long,
    receipt: String?,
    signature: String?,
    purchase_token: String?,
  ) -> T): Query<T> = SelectTransactionByProductIdQuery(product_id) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!,
      cursor.getLong(4)!!,
      cursor.getString(5),
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getString(8),
      cursor.getString(9),
      cursor.getString(10)
    )
  }

  public fun selectTransactionByProductId(product_id: String): Query<SDKTransaction> = selectTransactionByProductId(product_id, ::SDKTransaction)

  public fun <T : Any> selectPendingTransactions(mapper: (
    transaction_id: String,
    product_id: String,
    user_id: String,
    platform: String,
    purchase_time: Long,
    original_transaction_id: String?,
    is_restored: Long,
    is_finished: Long,
    receipt: String?,
    signature: String?,
    purchase_token: String?,
  ) -> T): Query<T> = Query(-1_353_062_310, arrayOf("SDKTransaction"), driver, "SDKTransaction.sq", "selectPendingTransactions", "SELECT SDKTransaction.transaction_id, SDKTransaction.product_id, SDKTransaction.user_id, SDKTransaction.platform, SDKTransaction.purchase_time, SDKTransaction.original_transaction_id, SDKTransaction.is_restored, SDKTransaction.is_finished, SDKTransaction.receipt, SDKTransaction.signature, SDKTransaction.purchase_token FROM SDKTransaction WHERE is_finished = 0") { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!,
      cursor.getLong(4)!!,
      cursor.getString(5),
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getString(8),
      cursor.getString(9),
      cursor.getString(10)
    )
  }

  public fun selectPendingTransactions(): Query<SDKTransaction> = selectPendingTransactions(::SDKTransaction)

  public fun <T : Any> selectTransactionHistoryByUserId(
    user_id: String,
    `value`: Long,
    mapper: (
      transaction_id: String,
      product_id: String,
      user_id: String,
      platform: String,
      purchase_time: Long,
      original_transaction_id: String?,
      is_restored: Long,
      is_finished: Long,
      receipt: String?,
      signature: String?,
      purchase_token: String?,
    ) -> T,
  ): Query<T> = SelectTransactionHistoryByUserIdQuery(user_id, value) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!,
      cursor.getLong(4)!!,
      cursor.getString(5),
      cursor.getLong(6)!!,
      cursor.getLong(7)!!,
      cursor.getString(8),
      cursor.getString(9),
      cursor.getString(10)
    )
  }

  public fun selectTransactionHistoryByUserId(user_id: String, value_: Long): Query<SDKTransaction> = selectTransactionHistoryByUserId(user_id, value_, ::SDKTransaction)

  /**
   * @return The number of rows updated.
   */
  public fun insertOrReplaceTransaction(
    transaction_id: String,
    product_id: String,
    user_id: String,
    platform: String,
    purchase_time: Long,
    original_transaction_id: String?,
    is_restored: Long,
    is_finished: Long,
    receipt: String?,
    signature: String?,
    purchase_token: String?,
  ): QueryResult<Long> {
    val result = driver.execute(-96_689_668, """
        |INSERT OR REPLACE INTO SDKTransaction(transaction_id, product_id, user_id, platform, purchase_time, original_transaction_id, is_restored, is_finished, receipt, signature, purchase_token)
        |VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """.trimMargin(), 11) {
          var parameterIndex = 0
          bindString(parameterIndex++, transaction_id)
          bindString(parameterIndex++, product_id)
          bindString(parameterIndex++, user_id)
          bindString(parameterIndex++, platform)
          bindLong(parameterIndex++, purchase_time)
          bindString(parameterIndex++, original_transaction_id)
          bindLong(parameterIndex++, is_restored)
          bindLong(parameterIndex++, is_finished)
          bindString(parameterIndex++, receipt)
          bindString(parameterIndex++, signature)
          bindString(parameterIndex++, purchase_token)
        }
    notifyQueries(-96_689_668) { emit ->
      emit("SDKTransaction")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun updateTransactionFinished(transaction_id: String): QueryResult<Long> {
    val result = driver.execute(708_193_361, """
        |UPDATE SDKTransaction
        |SET is_finished = 1
        |WHERE transaction_id = ?
        """.trimMargin(), 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, transaction_id)
        }
    notifyQueries(708_193_361) { emit ->
      emit("SDKTransaction")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteTransactionByTransactionId(transaction_id: String): QueryResult<Long> {
    val result = driver.execute(-2_122_045_659, """DELETE FROM SDKTransaction WHERE transaction_id = ?""", 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, transaction_id)
        }
    notifyQueries(-2_122_045_659) { emit ->
      emit("SDKTransaction")
    }
    return result
  }

  private inner class SelectTransactionByTransactionIdQuery<out T : Any>(
    public val transaction_id: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("SDKTransaction", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("SDKTransaction", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-633_969_866, """SELECT SDKTransaction.transaction_id, SDKTransaction.product_id, SDKTransaction.user_id, SDKTransaction.platform, SDKTransaction.purchase_time, SDKTransaction.original_transaction_id, SDKTransaction.is_restored, SDKTransaction.is_finished, SDKTransaction.receipt, SDKTransaction.signature, SDKTransaction.purchase_token FROM SDKTransaction WHERE transaction_id = ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, transaction_id)
    }

    override fun toString(): String = "SDKTransaction.sq:selectTransactionByTransactionId"
  }

  private inner class SelectTransactionByProductIdQuery<out T : Any>(
    public val product_id: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("SDKTransaction", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("SDKTransaction", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-120_917_113, """SELECT SDKTransaction.transaction_id, SDKTransaction.product_id, SDKTransaction.user_id, SDKTransaction.platform, SDKTransaction.purchase_time, SDKTransaction.original_transaction_id, SDKTransaction.is_restored, SDKTransaction.is_finished, SDKTransaction.receipt, SDKTransaction.signature, SDKTransaction.purchase_token FROM SDKTransaction WHERE product_id = ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, product_id)
    }

    override fun toString(): String = "SDKTransaction.sq:selectTransactionByProductId"
  }

  private inner class SelectTransactionHistoryByUserIdQuery<out T : Any>(
    public val user_id: String,
    public val `value`: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("SDKTransaction", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("SDKTransaction", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-81_241_115, """SELECT SDKTransaction.transaction_id, SDKTransaction.product_id, SDKTransaction.user_id, SDKTransaction.platform, SDKTransaction.purchase_time, SDKTransaction.original_transaction_id, SDKTransaction.is_restored, SDKTransaction.is_finished, SDKTransaction.receipt, SDKTransaction.signature, SDKTransaction.purchase_token FROM SDKTransaction WHERE user_id = ? ORDER BY purchase_time DESC LIMIT ?""", mapper, 2) {
      var parameterIndex = 0
      bindString(parameterIndex++, user_id)
      bindLong(parameterIndex++, value)
    }

    override fun toString(): String = "SDKTransaction.sq:selectTransactionHistoryByUserId"
  }
}
