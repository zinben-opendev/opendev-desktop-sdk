package com.zinben.opendev.db

import app.cash.sqldelight.driver.jdbc.sqlite.JdbcSqliteDriver
import java.io.File

private var sdkDatabaseInstance: SDKDatabase? = null

actual fun getDatabase(): SDKDatabase {
    return sdkDatabaseInstance ?: run {
        val dbPath = File(System.getProperty("user.home"), "walknote_sdk.db").absolutePath
        val dbFile = File(dbPath)
        val isNewDatabase = !dbFile.exists()
        
        val driver = JdbcSqliteDriver("jdbc:sqlite:$dbPath")
        
        // 仅在数据库文件不存在时创建表结构
        if (isNewDatabase) {
            SDKDatabase.Schema.create(driver)
        }
        
        SDKDatabase(driver).also { sdkDatabaseInstance = it }
    }
}
