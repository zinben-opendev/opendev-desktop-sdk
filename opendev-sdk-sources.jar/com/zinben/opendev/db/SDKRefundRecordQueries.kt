package com.zinben.opendev.db

import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import kotlin.Any
import kotlin.Long
import kotlin.String

public class SDKRefundRecordQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun <T : Any> selectRefundRecordById(id: String, mapper: (
    id: String,
    transaction_id: String,
    order_id: String,
    amount_value: String,
    currency: String,
    reason: String?,
    status: String,
    refund_time: Long?,
    created_at: Long,
    updated_at: Long,
  ) -> T): Query<T> = SelectRefundRecordByIdQuery(id) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!,
      cursor.getString(4)!!,
      cursor.getString(5),
      cursor.getString(6)!!,
      cursor.getLong(7),
      cursor.getLong(8)!!,
      cursor.getLong(9)!!
    )
  }

  public fun selectRefundRecordById(id: String): Query<SDKRefundRecord> = selectRefundRecordById(id, ::SDKRefundRecord)

  public fun <T : Any> selectRefundRecordByOrderId(order_id: String, mapper: (
    id: String,
    transaction_id: String,
    order_id: String,
    amount_value: String,
    currency: String,
    reason: String?,
    status: String,
    refund_time: Long?,
    created_at: Long,
    updated_at: Long,
  ) -> T): Query<T> = SelectRefundRecordByOrderIdQuery(order_id) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!,
      cursor.getString(4)!!,
      cursor.getString(5),
      cursor.getString(6)!!,
      cursor.getLong(7),
      cursor.getLong(8)!!,
      cursor.getLong(9)!!
    )
  }

  public fun selectRefundRecordByOrderId(order_id: String): Query<SDKRefundRecord> = selectRefundRecordByOrderId(order_id, ::SDKRefundRecord)

  public fun <T : Any> selectAllRefundRecords(mapper: (
    id: String,
    transaction_id: String,
    order_id: String,
    amount_value: String,
    currency: String,
    reason: String?,
    status: String,
    refund_time: Long?,
    created_at: Long,
    updated_at: Long,
  ) -> T): Query<T> = Query(-331_624_846, arrayOf("SDKRefundRecord"), driver, "SDKRefundRecord.sq", "selectAllRefundRecords", "SELECT SDKRefundRecord.id, SDKRefundRecord.transaction_id, SDKRefundRecord.order_id, SDKRefundRecord.amount_value, SDKRefundRecord.currency, SDKRefundRecord.reason, SDKRefundRecord.status, SDKRefundRecord.refund_time, SDKRefundRecord.created_at, SDKRefundRecord.updated_at FROM SDKRefundRecord") { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!,
      cursor.getString(4)!!,
      cursor.getString(5),
      cursor.getString(6)!!,
      cursor.getLong(7),
      cursor.getLong(8)!!,
      cursor.getLong(9)!!
    )
  }

  public fun selectAllRefundRecords(): Query<SDKRefundRecord> = selectAllRefundRecords(::SDKRefundRecord)

  /**
   * @return The number of rows updated.
   */
  public fun insertOrReplaceRefundRecord(
    id: String,
    transaction_id: String,
    order_id: String,
    amount_value: String,
    currency: String,
    reason: String?,
    status: String,
    refund_time: Long?,
    created_at: Long,
    updated_at: Long,
  ): QueryResult<Long> {
    val result = driver.execute(-556_916_492, """
        |INSERT OR REPLACE INTO SDKRefundRecord(id, transaction_id, order_id, amount_value, currency, reason, status, refund_time, created_at, updated_at)
        |VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """.trimMargin(), 10) {
          var parameterIndex = 0
          bindString(parameterIndex++, id)
          bindString(parameterIndex++, transaction_id)
          bindString(parameterIndex++, order_id)
          bindString(parameterIndex++, amount_value)
          bindString(parameterIndex++, currency)
          bindString(parameterIndex++, reason)
          bindString(parameterIndex++, status)
          bindLong(parameterIndex++, refund_time)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, updated_at)
        }
    notifyQueries(-556_916_492) { emit ->
      emit("SDKRefundRecord")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteRefundRecordById(id: String): QueryResult<Long> {
    val result = driver.execute(1_609_051_891, """DELETE FROM SDKRefundRecord WHERE id = ?""", 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, id)
        }
    notifyQueries(1_609_051_891) { emit ->
      emit("SDKRefundRecord")
    }
    return result
  }

  private inner class SelectRefundRecordByIdQuery<out T : Any>(
    public val id: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("SDKRefundRecord", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("SDKRefundRecord", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-301_851_580, """SELECT SDKRefundRecord.id, SDKRefundRecord.transaction_id, SDKRefundRecord.order_id, SDKRefundRecord.amount_value, SDKRefundRecord.currency, SDKRefundRecord.reason, SDKRefundRecord.status, SDKRefundRecord.refund_time, SDKRefundRecord.created_at, SDKRefundRecord.updated_at FROM SDKRefundRecord WHERE id = ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, id)
    }

    override fun toString(): String = "SDKRefundRecord.sq:selectRefundRecordById"
  }

  private inner class SelectRefundRecordByOrderIdQuery<out T : Any>(
    public val order_id: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("SDKRefundRecord", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("SDKRefundRecord", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(435_353_472, """SELECT SDKRefundRecord.id, SDKRefundRecord.transaction_id, SDKRefundRecord.order_id, SDKRefundRecord.amount_value, SDKRefundRecord.currency, SDKRefundRecord.reason, SDKRefundRecord.status, SDKRefundRecord.refund_time, SDKRefundRecord.created_at, SDKRefundRecord.updated_at FROM SDKRefundRecord WHERE order_id = ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, order_id)
    }

    override fun toString(): String = "SDKRefundRecord.sq:selectRefundRecordByOrderId"
  }
}
