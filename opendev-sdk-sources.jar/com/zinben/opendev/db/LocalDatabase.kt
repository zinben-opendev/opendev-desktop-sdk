package com.zinben.opendev.db

import com.zinben.opendev.models.PaymentOrder
import com.zinben.opendev.models.PaymentResult
import com.zinben.opendev.models.PaymentStatus
import com.zinben.opendev.models.RefundRecord
import com.zinben.opendev.models.Transaction
import com.zinben.opendev.models.User

interface LocalDatabase {
    suspend fun saveUser(user: User)
    suspend fun updateUser(user: User)
    suspend fun getCurrentUser(): User?
    suspend fun clearAuth()

    suspend fun savePaymentOrder(order: PaymentOrder)
    suspend fun savePaymentResult(result: PaymentResult.Success)
    suspend fun saveRefundRecord(refund: RefundRecord)
    suspend fun getPaymentOrder(orderId: String): PaymentOrder?
    suspend fun getPaymentStatus(orderId: String): PaymentStatus?
    suspend fun updatePaymentStatus(orderId: String, status: PaymentStatus)
    suspend fun getPaymentHistory(userId: String, limit: Int): List<PaymentOrder>

    suspend fun saveTransaction(transaction: Transaction)
    suspend fun getTransaction(transactionId: String): Transaction?
    suspend fun getTransactionByProductId(productId: String): Transaction?
    suspend fun getPendingTransactions(): List<Transaction>
    suspend fun finishTransaction(transactionId: String): Boolean
    suspend fun getTransactionHistory(userId: String, limit: Int): List<Transaction>
}
