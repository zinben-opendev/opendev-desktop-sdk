package com.zinben.opendev.db

import kotlin.Long
import kotlin.String

public data class SDKPaymentResult(
  public val transaction_id: String,
  public val order_id: String,
  public val amount_value: String,
  public val currency: String,
  public val payment_time: Long,
)
