package com.zinben.opendev.db

import com.zinben.opendev.models.PaymentOrder
import com.zinben.opendev.models.PaymentResult
import com.zinben.opendev.models.RefundRecord
import com.zinben.opendev.models.User

interface CloudDatabase {
    suspend fun syncUser(user: User)
    suspend fun clearUserSession(userId: String?)

    suspend fun syncPaymentOrder(order: PaymentOrder)
    suspend fun syncPaymentResult(result: PaymentResult.Success)
    suspend fun syncRefundRecord(refund: RefundRecord)
}
