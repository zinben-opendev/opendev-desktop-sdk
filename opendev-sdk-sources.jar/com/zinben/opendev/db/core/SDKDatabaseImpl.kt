package com.zinben.opendev.db.core

import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.AfterVersion
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.db.SqlSchema
import com.zinben.opendev.db.SDKDatabase
import com.zinben.opendev.db.SDKPaymentOrderQueries
import com.zinben.opendev.db.SDKPaymentResultQueries
import com.zinben.opendev.db.SDKRefundRecordQueries
import com.zinben.opendev.db.SDKTransactionQueries
import com.zinben.opendev.db.SDKUserQueries
import kotlin.Long
import kotlin.Unit
import kotlin.reflect.KClass

internal val KClass<SDKDatabase>.schema: SqlSchema<QueryResult.Value<Unit>>
  get() = SDKDatabaseImpl.Schema

internal fun KClass<SDKDatabase>.newInstance(driver: SqlDriver): SDKDatabase = SDKDatabaseImpl(driver)

private class SDKDatabaseImpl(
  driver: SqlDriver,
) : TransacterImpl(driver),
    SDKDatabase {
  override val sDKPaymentOrderQueries: SDKPaymentOrderQueries = SDKPaymentOrderQueries(driver)

  override val sDKPaymentResultQueries: SDKPaymentResultQueries = SDKPaymentResultQueries(driver)

  override val sDKRefundRecordQueries: SDKRefundRecordQueries = SDKRefundRecordQueries(driver)

  override val sDKTransactionQueries: SDKTransactionQueries = SDKTransactionQueries(driver)

  override val sDKUserQueries: SDKUserQueries = SDKUserQueries(driver)

  public object Schema : SqlSchema<QueryResult.Value<Unit>> {
    override val version: Long
      get() = 1

    override fun create(driver: SqlDriver): QueryResult.Value<Unit> {
      driver.execute(null, """
          |CREATE TABLE IF NOT EXISTS SDKPaymentOrder (
          |    id TEXT NOT NULL PRIMARY KEY,
          |    user_id TEXT NOT NULL,
          |    product_id TEXT NOT NULL,
          |    product_name TEXT NOT NULL,
          |    product_description TEXT,
          |    amount_value TEXT NOT NULL, -- Money.value as String
          |    currency TEXT NOT NULL,
          |    payment_method TEXT NOT NULL, -- PaymentMethodType enum
          |    platform TEXT NOT NULL, -- Platform enum
          |    status TEXT NOT NULL, -- PaymentStatus enum
          |    created_at INTEGER NOT NULL,
          |    updated_at INTEGER NOT NULL,
          |    expires_at INTEGER,
          |    metadata TEXT, -- JSON object
          |    FOREIGN KEY (user_id) REFERENCES SDKUser(id) ON DELETE CASCADE
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE IF NOT EXISTS SDKPaymentResult (
          |    transaction_id TEXT NOT NULL PRIMARY KEY,
          |    order_id TEXT NOT NULL,
          |    amount_value TEXT NOT NULL, -- Money.value as String
          |    currency TEXT NOT NULL,
          |    payment_time INTEGER NOT NULL,
          |    FOREIGN KEY (order_id) REFERENCES SDKPaymentOrder(id) ON DELETE CASCADE
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE IF NOT EXISTS SDKRefundRecord (
          |    id TEXT NOT NULL PRIMARY KEY,
          |    transaction_id TEXT NOT NULL,
          |    order_id TEXT NOT NULL,
          |    amount_value TEXT NOT NULL, -- Money.value as String
          |    currency TEXT NOT NULL,
          |    reason TEXT,
          |    status TEXT NOT NULL, -- PaymentStatus enum
          |    refund_time INTEGER,
          |    created_at INTEGER NOT NULL,
          |    updated_at INTEGER NOT NULL,
          |    FOREIGN KEY (order_id) REFERENCES SDKPaymentOrder(id) ON DELETE CASCADE
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE IF NOT EXISTS SDKTransaction (
          |    transaction_id TEXT NOT NULL PRIMARY KEY,
          |    product_id TEXT NOT NULL,
          |    user_id TEXT NOT NULL,
          |    platform TEXT NOT NULL, -- Platform enum
          |    purchase_time INTEGER NOT NULL,
          |    original_transaction_id TEXT,
          |    is_restored INTEGER NOT NULL DEFAULT 0,
          |    is_finished INTEGER NOT NULL DEFAULT 0,
          |    receipt TEXT,
          |    signature TEXT,
          |    purchase_token TEXT,
          |    FOREIGN KEY (user_id) REFERENCES SDKUser(id) ON DELETE CASCADE
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE IF NOT EXISTS SDKUser (
          |    id TEXT NOT NULL PRIMARY KEY,
          |    username TEXT,
          |    email TEXT,
          |    avatar TEXT,
          |    nickname TEXT,
          |    login_type TEXT NOT NULL,
          |    bound_accounts TEXT NOT NULL, -- JSON array of ThirdPartyProvider
          |    created_at INTEGER NOT NULL,
          |    last_login_at INTEGER NOT NULL,
          |    is_synced INTEGER NOT NULL DEFAULT 0
          |)
          """.trimMargin(), 0)
      return QueryResult.Unit
    }

    override fun migrate(
      driver: SqlDriver,
      oldVersion: Long,
      newVersion: Long,
      vararg callbacks: AfterVersion,
    ): QueryResult.Value<Unit> = QueryResult.Unit
  }
}
