package com.zinben.opendev.db

import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import kotlin.Any
import kotlin.Long
import kotlin.String

public class SDKUserQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun <T : Any> selectUserById(id: String, mapper: (
    id: String,
    username: String?,
    email: String?,
    avatar: String?,
    nickname: String?,
    login_type: String,
    bound_accounts: String,
    created_at: Long,
    last_login_at: Long,
    is_synced: Long,
  ) -> T): Query<T> = SelectUserByIdQuery(id) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1),
      cursor.getString(2),
      cursor.getString(3),
      cursor.getString(4),
      cursor.getString(5)!!,
      cursor.getString(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!
    )
  }

  public fun selectUserById(id: String): Query<SDKUser> = selectUserById(id, ::SDKUser)

  public fun <T : Any> selectUserByEmail(email: String?, mapper: (
    id: String,
    username: String?,
    email: String?,
    avatar: String?,
    nickname: String?,
    login_type: String,
    bound_accounts: String,
    created_at: Long,
    last_login_at: Long,
    is_synced: Long,
  ) -> T): Query<T> = SelectUserByEmailQuery(email) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1),
      cursor.getString(2),
      cursor.getString(3),
      cursor.getString(4),
      cursor.getString(5)!!,
      cursor.getString(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!
    )
  }

  public fun selectUserByEmail(email: String?): Query<SDKUser> = selectUserByEmail(email, ::SDKUser)

  public fun <T : Any> selectCurrentUser(mapper: (
    id: String,
    username: String?,
    email: String?,
    avatar: String?,
    nickname: String?,
    login_type: String,
    bound_accounts: String,
    created_at: Long,
    last_login_at: Long,
    is_synced: Long,
  ) -> T): Query<T> = Query(-1_993_687_623, arrayOf("SDKUser"), driver, "SDKUser.sq", "selectCurrentUser", "SELECT SDKUser.id, SDKUser.username, SDKUser.email, SDKUser.avatar, SDKUser.nickname, SDKUser.login_type, SDKUser.bound_accounts, SDKUser.created_at, SDKUser.last_login_at, SDKUser.is_synced FROM SDKUser ORDER BY last_login_at DESC LIMIT 1") { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1),
      cursor.getString(2),
      cursor.getString(3),
      cursor.getString(4),
      cursor.getString(5)!!,
      cursor.getString(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!
    )
  }

  public fun selectCurrentUser(): Query<SDKUser> = selectCurrentUser(::SDKUser)

  public fun <T : Any> selectAllUsers(mapper: (
    id: String,
    username: String?,
    email: String?,
    avatar: String?,
    nickname: String?,
    login_type: String,
    bound_accounts: String,
    created_at: Long,
    last_login_at: Long,
    is_synced: Long,
  ) -> T): Query<T> = Query(-1_820_380_110, arrayOf("SDKUser"), driver, "SDKUser.sq", "selectAllUsers", "SELECT SDKUser.id, SDKUser.username, SDKUser.email, SDKUser.avatar, SDKUser.nickname, SDKUser.login_type, SDKUser.bound_accounts, SDKUser.created_at, SDKUser.last_login_at, SDKUser.is_synced FROM SDKUser") { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1),
      cursor.getString(2),
      cursor.getString(3),
      cursor.getString(4),
      cursor.getString(5)!!,
      cursor.getString(6)!!,
      cursor.getLong(7)!!,
      cursor.getLong(8)!!,
      cursor.getLong(9)!!
    )
  }

  public fun selectAllUsers(): Query<SDKUser> = selectAllUsers(::SDKUser)

  public fun getUserCount(): Query<Long> = Query(1_407_558_461, arrayOf("SDKUser"), driver, "SDKUser.sq", "getUserCount", "SELECT COUNT(*) FROM SDKUser") { cursor ->
    cursor.getLong(0)!!
  }

  /**
   * @return The number of rows updated.
   */
  public fun insertOrReplaceUser(
    id: String,
    username: String?,
    email: String?,
    avatar: String?,
    nickname: String?,
    login_type: String,
    bound_accounts: String,
    created_at: Long,
    last_login_at: Long,
    is_synced: Long,
  ): QueryResult<Long> {
    val result = driver.execute(240_732_084, """
        |INSERT OR REPLACE INTO SDKUser(id, username, email, avatar, nickname, login_type, bound_accounts, created_at, last_login_at, is_synced)
        |VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """.trimMargin(), 10) {
          var parameterIndex = 0
          bindString(parameterIndex++, id)
          bindString(parameterIndex++, username)
          bindString(parameterIndex++, email)
          bindString(parameterIndex++, avatar)
          bindString(parameterIndex++, nickname)
          bindString(parameterIndex++, login_type)
          bindString(parameterIndex++, bound_accounts)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, last_login_at)
          bindLong(parameterIndex++, is_synced)
        }
    notifyQueries(240_732_084) { emit ->
      emit("SDKUser")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun updateUser(
    username: String?,
    email: String?,
    avatar: String?,
    nickname: String?,
    login_type: String,
    bound_accounts: String,
    last_login_at: Long,
    is_synced: Long,
    id: String,
  ): QueryResult<Long> {
    val result = driver.execute(2_109_723_107, """
        |UPDATE SDKUser
        |SET username = ?, email = ?, avatar = ?, nickname = ?, login_type = ?, bound_accounts = ?, last_login_at = ?, is_synced = ?
        |WHERE id = ?
        """.trimMargin(), 9) {
          var parameterIndex = 0
          bindString(parameterIndex++, username)
          bindString(parameterIndex++, email)
          bindString(parameterIndex++, avatar)
          bindString(parameterIndex++, nickname)
          bindString(parameterIndex++, login_type)
          bindString(parameterIndex++, bound_accounts)
          bindLong(parameterIndex++, last_login_at)
          bindLong(parameterIndex++, is_synced)
          bindString(parameterIndex++, id)
        }
    notifyQueries(2_109_723_107) { emit ->
      emit("SDKUser")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteUserById(id: String): QueryResult<Long> {
    val result = driver.execute(1_708_278_583, """DELETE FROM SDKUser WHERE id = ?""", 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, id)
        }
    notifyQueries(1_708_278_583) { emit ->
      emit("SDKPaymentOrder")
      emit("SDKTransaction")
      emit("SDKUser")
    }
    return result
  }

  private inner class SelectUserByIdQuery<out T : Any>(
    public val id: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("SDKUser", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("SDKUser", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(418_582_920, """SELECT SDKUser.id, SDKUser.username, SDKUser.email, SDKUser.avatar, SDKUser.nickname, SDKUser.login_type, SDKUser.bound_accounts, SDKUser.created_at, SDKUser.last_login_at, SDKUser.is_synced FROM SDKUser WHERE id = ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, id)
    }

    override fun toString(): String = "SDKUser.sq:selectUserById"
  }

  private inner class SelectUserByEmailQuery<out T : Any>(
    public val email: String?,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("SDKUser", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("SDKUser", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(null, """SELECT SDKUser.id, SDKUser.username, SDKUser.email, SDKUser.avatar, SDKUser.nickname, SDKUser.login_type, SDKUser.bound_accounts, SDKUser.created_at, SDKUser.last_login_at, SDKUser.is_synced FROM SDKUser WHERE email ${ if (email == null) "IS" else "=" } ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, email)
    }

    override fun toString(): String = "SDKUser.sq:selectUserByEmail"
  }
}
