package com.zinben.opendev.db

import kotlin.Long
import kotlin.String

public data class SDKUser(
  public val id: String,
  public val username: String?,
  public val email: String?,
  public val avatar: String?,
  public val nickname: String?,
  public val login_type: String,
  public val bound_accounts: String,
  public val created_at: Long,
  public val last_login_at: Long,
  public val is_synced: Long,
)
