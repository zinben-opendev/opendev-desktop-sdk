package com.zinben.opendev.db

import com.zinben.opendev.logger.Logger
import com.zinben.opendev.db.LocalDatabase
import com.zinben.opendev.db.CloudDatabase
import com.zinben.opendev.models.*
import com.zinben.opendev.utils.TimeUtils
import kotlinx.coroutines.delay
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.MapSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json
import kotlin.random.Random

/**
 * 获取当前时间戳（毫秒）
 * 
 * 使用 TimeUtils 封装的时间API，避免直接依赖实验性 API
 * 便于统一维护和后续升级
 */
private fun currentTimeMillis(): Long {
    return TimeUtils.getCurrentTimeMillis()
}

/**
 * 本地数据库实现
 * 
 * 提供本地数据库功能，支持用户数据、认证令牌、支付订单等数据的本地存储和检索。
 * 
 * 特性：
 * - 使用 SQLDelight 数据库进行持久化存储
 * - 支持事务操作
 * - 数据持久化到本地 SQLite 数据库
 * - 完整的CRUD操作
 */
class LocalDatabaseImpl : LocalDatabase {
    
    // 获取数据库实例
    private val database = getDatabase()
    
    // JSON序列化器
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        // Money 类型使用 @Serializable，跨平台兼容
    }
    
    // 当前用户ID（从数据库查询获取）
    private var currentUserId: String? = null
    
    override suspend fun saveUser(user: User) {
        val boundAccountsJson = json.encodeToString(
            ListSerializer(BoundAccountInfo.serializer()),
            user.boundAccounts
        )
        
        database.sDKUserQueries.insertOrReplaceUser(
            id = user.id,
            username = user.username,
            email = user.email,
            avatar = user.avatar,
            nickname = user.nickname,
            login_type = user.loginType.name,
            bound_accounts = boundAccountsJson,
            created_at = user.createdAt,
            last_login_at = user.lastLoginAt,
            is_synced = if (user.isSynced) 1L else 0L
        )
        
        currentUserId = user.id
        Logger.debug("LocalDB: Saved user ${user.id}")
    }
    
    override suspend fun updateUser(user: User) {
        val boundAccountsJson = json.encodeToString(
            ListSerializer(BoundAccountInfo.serializer()),
            user.boundAccounts
        )
        
        database.sDKUserQueries.updateUser(
            username = user.username,
            email = user.email,
            avatar = user.avatar,
            nickname = user.nickname,
            login_type = user.loginType.name,
            bound_accounts = boundAccountsJson,
            last_login_at = user.lastLoginAt,
            is_synced = if (user.isSynced) 1L else 0L,
            id = user.id
        )
        
        Logger.debug("LocalDB: Updated user ${user.id}")
    }
    
    override suspend fun getCurrentUser(): User? {
        val userRow = database.sDKUserQueries.selectCurrentUser().executeAsOneOrNull()
        userRow?.let { row ->
            currentUserId = row.id
            return rowToUser(row)
        }
        return null
    }
    
    override suspend fun clearAuth() {
        currentUserId = null
        
        Logger.debug("LocalDB: Cleared auth data")
    }
    
    // 辅助方法：从数据库获取当前用户ID
    private fun getCurrentUserIdFromDB(): String? {
        val userRow = database.sDKUserQueries.selectCurrentUser().executeAsOneOrNull()
        return userRow?.id
    }
    
    override suspend fun savePaymentOrder(order: PaymentOrder) {
        val metadataJson = json.encodeToString(
            MapSerializer(String.serializer(), String.serializer()),
            order.metadata
        )
        
        database.sDKPaymentOrderQueries.insertOrReplacePaymentOrder(
            id = order.id,
            user_id = order.userId,
            product_id = order.productId,
            product_name = order.productName,
            product_description = order.productDescription,
            amount_value = order.amount.value,
            currency = order.currency,
            payment_method = order.paymentMethod.name,
            platform = order.platform.name,
            status = order.status.name,
            created_at = order.createdAt,
            updated_at = order.updatedAt,
            expires_at = order.expiresAt,
            metadata = metadataJson
        )
        
        Logger.debug("LocalDB: Saved payment order ${order.id}")
    }
    
    override suspend fun savePaymentResult(result: PaymentResult.Success) {
        database.sDKPaymentResultQueries.insertOrReplacePaymentResult(
            transaction_id = result.transactionId,
            order_id = result.orderId,
            amount_value = result.amount.value,
            currency = result.currency,
            payment_time = result.paymentTime
        )
        
        // 更新订单状态
        updatePaymentStatus(result.orderId, PaymentStatus.SUCCESS)
        
        Logger.debug("LocalDB: Saved payment result ${result.transactionId}")
    }
    
    override suspend fun saveRefundRecord(refund: RefundRecord) {
        database.sDKRefundRecordQueries.insertOrReplaceRefundRecord(
            id = refund.id,
            transaction_id = refund.transactionId,
            order_id = refund.orderId,
            amount_value = refund.amount.value,
            currency = refund.currency,
            reason = refund.reason,
            status = refund.status.name,
            refund_time = refund.refundTime,
            created_at = refund.createdAt,
            updated_at = refund.updatedAt
        )
        
        // 更新订单状态
        updatePaymentStatus(refund.orderId, PaymentStatus.REFUNDED)
        
        Logger.debug("LocalDB: Saved refund record ${refund.id}")
    }
    
    override suspend fun getPaymentOrder(orderId: String): PaymentOrder? {
        val orderRow = database.sDKPaymentOrderQueries.selectPaymentOrderById(orderId).executeAsOneOrNull()
        return orderRow?.let { rowToPaymentOrder(it) }
    }
    
    override suspend fun getPaymentStatus(orderId: String): PaymentStatus? {
        val orderRow = database.sDKPaymentOrderQueries.selectPaymentOrderById(orderId).executeAsOneOrNull()
        return orderRow?.let { PaymentStatus.valueOf(it.status) }
    }
    
    override suspend fun updatePaymentStatus(orderId: String, status: PaymentStatus) {
        val currentTime = currentTimeMillis()
        database.sDKPaymentOrderQueries.updatePaymentOrderStatus(
            status = status.name,
            updated_at = currentTime,
            id = orderId
        )
        
        Logger.debug("LocalDB: Updated payment status for order $orderId to $status")
    }
    
    override suspend fun getPaymentHistory(userId: String, limit: Int): List<PaymentOrder> {
        val orderRows = database.sDKPaymentOrderQueries.selectPaymentHistoryByUserId(userId, limit.toLong()).executeAsList()
        return orderRows.map { rowToPaymentOrder(it) }
    }
    
    // ==================== 交易相关方法 ====================
    
    override suspend fun saveTransaction(transaction: Transaction) {
        database.sDKTransactionQueries.insertOrReplaceTransaction(
            transaction_id = transaction.transactionId,
            product_id = transaction.productId,
            user_id = transaction.userId,
            platform = transaction.platform.name,
            purchase_time = transaction.purchaseTime,
            original_transaction_id = transaction.originalTransactionId,
            is_restored = if (transaction.isRestored) 1L else 0L,
            is_finished = if (transaction.isFinished) 1L else 0L,
            receipt = transaction.receipt,
            signature = transaction.signature,
            purchase_token = transaction.purchaseToken
        )
        
        Logger.debug("LocalDB: Saved transaction ${transaction.transactionId}")
    }
    
    override suspend fun getTransaction(transactionId: String): Transaction? {
        val transactionRow = database.sDKTransactionQueries.selectTransactionByTransactionId(transactionId).executeAsOneOrNull()
        return transactionRow?.let { rowToTransaction(it) }
    }
    
    override suspend fun getTransactionByProductId(productId: String): Transaction? {
        val transactionRow = database.sDKTransactionQueries.selectTransactionByProductId(productId).executeAsOneOrNull()
        return transactionRow?.let { rowToTransaction(it) }
    }
    
    override suspend fun getPendingTransactions(): List<Transaction> {
        val transactionRows = database.sDKTransactionQueries.selectPendingTransactions().executeAsList()
        return transactionRows.map { rowToTransaction(it) }
    }
    
    override suspend fun finishTransaction(transactionId: String): Boolean {
        val transaction = getTransaction(transactionId)
        if (transaction != null) {
            database.sDKTransactionQueries.updateTransactionFinished(transactionId)
            Logger.debug("LocalDB: Finished transaction $transactionId")
            return true
        }
        return false
    }
    
    override suspend fun getTransactionHistory(userId: String, limit: Int): List<Transaction> {
        val transactionRows = database.sDKTransactionQueries.selectTransactionHistoryByUserId(userId, limit.toLong()).executeAsList()
        return transactionRows.map { rowToTransaction(it) }
    }
    
    // ==================== 数据转换方法 ====================
    
    /**
     * 将数据库行转换为 User 模型
     */
    private fun rowToUser(row: SDKUser): User {
        val boundAccounts = try {
            // 尝试解析新格式 (List<BoundAccountInfo>)
            json.decodeFromString(
                ListSerializer(BoundAccountInfo.serializer()),
                row.bound_accounts
            )
        } catch (e: Exception) {
            try {
                // 兼容旧格式 (List<ThirdPartyProvider>)，转换为新格式
                val oldFormat = json.decodeFromString(
                    ListSerializer(ThirdPartyProvider.serializer()),
                    row.bound_accounts
                )
                oldFormat.map { provider ->
                    BoundAccountInfo(providerType = provider.toApiType())
                }
            } catch (e2: Exception) {
                // 如果都失败，返回空列表
                emptyList()
            }
        }
        
        return User(
            id = row.id,
            username = row.username,
            email = row.email,
            avatar = row.avatar,
            nickname = row.nickname,
            loginType = LoginType.valueOf(row.login_type),
            boundAccounts = boundAccounts,
            createdAt = row.created_at,
            lastLoginAt = row.last_login_at,
            isSynced = row.is_synced == 1L
        )
    }
    
    /**
     * 将数据库行转换为 PaymentOrder 模型
     */
    private fun rowToPaymentOrder(row: SDKPaymentOrder): PaymentOrder {
        val metadata = try {
            if (row.metadata != null) {
                json.decodeFromString(
                    MapSerializer(String.serializer(), String.serializer()),
                    row.metadata
                )
            } else {
                emptyMap()
            }
        } catch (e: Exception) {
            emptyMap()
        }
        
        return PaymentOrder(
            id = row.id,
            userId = row.user_id,
            productId = row.product_id,
            productName = row.product_name,
            productDescription = row.product_description,
            amount = Money(row.amount_value),
            currency = row.currency,
            paymentMethod = PaymentMethodType.valueOf(row.payment_method),
            platform = Platform.valueOf(row.platform),
            status = PaymentStatus.valueOf(row.status),
            createdAt = row.created_at,
            updatedAt = row.updated_at,
            expiresAt = row.expires_at,
            metadata = metadata
        )
    }
    
    /**
     * 将数据库行转换为 Transaction 模型
     */
    private fun rowToTransaction(row: SDKTransaction): Transaction {
        return Transaction(
            transactionId = row.transaction_id,
            productId = row.product_id,
            userId = row.user_id,
            platform = Platform.valueOf(row.platform),
            purchaseTime = row.purchase_time,
            originalTransactionId = row.original_transaction_id,
            isRestored = row.is_restored == 1L,
            isFinished = row.is_finished == 1L,
            receipt = row.receipt,
            signature = row.signature,
            purchaseToken = row.purchase_token
        )
    }
    
    // ==================== 扩展功能（更新为使用数据库）====================
    
    /**
     * 获取所有用户
     */
    suspend fun getAllUsers(): List<User> {
        val userRows = database.sDKUserQueries.selectAllUsers().executeAsList()
        return userRows.map { rowToUser(it) }
    }
    
    /**
     * 根据邮箱查找用户
     */
    suspend fun findUserByEmail(email: String): User? {
        val userRow = database.sDKUserQueries.selectUserByEmail(email).executeAsOneOrNull()
        return userRow?.let { rowToUser(it) }
    }
    
    /**
     * 删除用户
     */
    suspend fun deleteUser(userId: String) {
        database.sDKUserQueries.deleteUserById(userId)
        
        if (currentUserId == userId) {
            currentUserId = null
        }
        
        Logger.debug("LocalDB: Deleted user $userId")
    }
    
    /**
     * 获取数据库统计信息
     */
    suspend fun getDatabaseStats(): DatabaseStats {
        val userCount = database.sDKUserQueries.getUserCount().executeAsOne()
        val tokenCount = 0L // Token storage moved to DataStore/Settings
        val paymentOrderCount = database.sDKPaymentOrderQueries.selectAllPaymentOrders().executeAsList().size.toLong()
        val paymentResultCount = database.sDKPaymentResultQueries.selectAllPaymentResults().executeAsList().size.toLong()
        val refundRecordCount = database.sDKRefundRecordQueries.selectAllRefundRecords().executeAsList().size.toLong()
        
        return DatabaseStats(
            userCount = userCount.toInt(),
            tokenCount = tokenCount.toInt(),
            paymentOrderCount = paymentOrderCount.toInt(),
            paymentResultCount = paymentResultCount.toInt(),
            refundRecordCount = refundRecordCount.toInt()
        )
    }
}

/**
 * 云端数据库实现
 * 
 * 提供云端数据库功能，支持数据同步、冲突解决、离线支持等功能。
 */
class CloudDatabaseImpl : CloudDatabase {
    
    // 云端存储
    private val cloudUsers = mutableMapOf<String, User>()
    private val cloudPaymentOrders = mutableMapOf<String, PaymentOrder>()
    private val cloudPaymentResults = mutableMapOf<String, PaymentResult.Success>()
    private val cloudRefundRecords = mutableMapOf<String, RefundRecord>()
    private val syncQueue = mutableListOf<SyncOperation>()
    
    // 网络状态
    private var isOnline = true
    private var networkDelay = 500L
    
    override suspend fun syncUser(user: User) {
        if (!isOnline) {
            // 添加到同步队列
            syncQueue.add(SyncOperation.SyncUser(user))
            return
        }
        
        // 网络延迟
        delay(networkDelay)
        
        // 网络错误
        if (Random.nextFloat() < 0.05f) { // 5% 网络错误率
            throw RuntimeException("Network error during user sync")
        }
        
        cloudUsers[user.id] = user.copy(isSynced = true)
        
        Logger.debug("CloudDB: Synced user ${user.id}")
    }
    
    override suspend fun clearUserSession(userId: String?) {
        if (!isOnline) {
            syncQueue.add(SyncOperation.ClearSession(userId))
            return
        }
        
        // 网络延迟
        delay(networkDelay)
        
        userId?.let {
            // 在实际实现中，这里会清理云端会话
            Logger.debug("CloudDB: Cleared session for user $userId")
        }
    }
    
    override suspend fun syncPaymentOrder(order: PaymentOrder) {
        if (!isOnline) {
            syncQueue.add(SyncOperation.SyncPaymentOrder(order))
            return
        }
        
        // 网络延迟
        delay(networkDelay)
        
        cloudPaymentOrders[order.id] = order
        
        Logger.debug("CloudDB: Synced payment order ${order.id}")
    }
    
    override suspend fun syncPaymentResult(result: PaymentResult.Success) {
        if (!isOnline) {
            syncQueue.add(SyncOperation.SyncPaymentResult(result))
            return
        }
        
        // 网络延迟
        delay(networkDelay)
        
        cloudPaymentResults[result.transactionId] = result
        
        Logger.debug("CloudDB: Synced payment result ${result.transactionId}")
    }
    
    override suspend fun syncRefundRecord(refund: RefundRecord) {
        if (!isOnline) {
            syncQueue.add(SyncOperation.SyncRefundRecord(refund))
            return
        }
        
        // 网络延迟
        delay(networkDelay)
        
        cloudRefundRecords[refund.id] = refund
        
        Logger.debug("CloudDB: Synced refund record ${refund.id}")
    }
    
    // ==================== 扩展功能 ====================
    
    /**
     * 设置网络状态
     */
    fun setNetworkStatus(online: Boolean) {
        isOnline = online
        Logger.debug("CloudDB: Network status changed to ${if (online) "online" else "offline"}")
    }
    
    /**
     * 设置网络延迟
     */
    fun setNetworkDelay(delay: Long) {
        networkDelay = delay
    }
    
    /**
     * 处理同步队列
     */
    suspend fun processSyncQueue() {
        if (!isOnline || syncQueue.isEmpty()) return
        
        Logger.debug("CloudDB: Processing ${syncQueue.size} queued operations")
        
        val operations = syncQueue.toList()
        syncQueue.clear()
        
        for (operation in operations) {
            try {
                when (operation) {
                    is SyncOperation.SyncUser -> syncUser(operation.user)
                    is SyncOperation.ClearSession -> clearUserSession(operation.userId)
                    is SyncOperation.SyncPaymentOrder -> syncPaymentOrder(operation.order)
                    is SyncOperation.SyncPaymentResult -> syncPaymentResult(operation.result)
                    is SyncOperation.SyncRefundRecord -> syncRefundRecord(operation.refund)
                }
            } catch (e: Exception) {
                // 同步失败，重新加入队列
                syncQueue.add(operation)
                Logger.error("CloudDB: Sync failed for ${operation::class.simpleName}, re-queued")
            }
        }
    }
    
    /**
     * 获取云端用户
     */
    suspend fun getCloudUser(userId: String): User? {
        delay(networkDelay)
        return cloudUsers[userId]
    }
    
    /**
     * 获取云端支付订单
     */
    suspend fun getCloudPaymentOrder(orderId: String): PaymentOrder? {
        delay(networkDelay)
        return cloudPaymentOrders[orderId]
    }
    
    /**
     * 数据冲突解决
     */
    suspend fun resolveConflict(localData: Any, cloudData: Any): Any {
        delay(100)
        
        // 简单的冲突解决策略：使用时间戳较新的数据
        return when {
            localData is User && cloudData is User -> {
                if (localData.lastLoginAt > cloudData.lastLoginAt) localData else cloudData
            }
            else -> cloudData // 默认使用云端数据
        }
    }
    
    /**
     * 获取同步状态
     */
    suspend fun getSyncStatus(): SyncStatus {
        delay(50)
        return SyncStatus(
            isOnline = isOnline,
            queuedOperations = syncQueue.size,
            lastSyncTime = currentTimeMillis(),
            networkDelay = networkDelay
        )
    }
}

// ==================== 数据模型 ====================

/**
 * 数据库统计信息
 */
@Serializable
data class DatabaseStats(
    val userCount: Int,
    val tokenCount: Int,
    val paymentOrderCount: Int,
    val paymentResultCount: Int,
    val refundRecordCount: Int
)

/**
 * 数据库备份
 */
@Serializable
data class DatabaseBackup(
    val users: Map<String, User>,
    val tokens: Map<String, String>,
    val paymentOrders: Map<String, PaymentOrder>,
    val paymentResults: Map<String, PaymentResult.Success>,
    val refundRecords: Map<String, RefundRecord>,
    val paymentHistory: Map<String, List<PaymentOrder>>,
    val timestamp: Long
)

/**
 * 同步操作
 */
sealed class SyncOperation {
    data class SyncUser(val user: User) : SyncOperation()
    data class ClearSession(val userId: String?) : SyncOperation()
    data class SyncPaymentOrder(val order: PaymentOrder) : SyncOperation()
    data class SyncPaymentResult(val result: PaymentResult.Success) : SyncOperation()
    data class SyncRefundRecord(val refund: RefundRecord) : SyncOperation()
}

/**
 * 同步状态
 */
@Serializable
data class SyncStatus(
    val isOnline: Boolean,
    val queuedOperations: Int,
    val lastSyncTime: Long,
    val networkDelay: Long
)

