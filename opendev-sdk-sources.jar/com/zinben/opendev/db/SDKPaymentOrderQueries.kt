package com.zinben.opendev.db

import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import kotlin.Any
import kotlin.Long
import kotlin.String

public class SDKPaymentOrderQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun <T : Any> selectPaymentOrderById(id: String, mapper: (
    id: String,
    user_id: String,
    product_id: String,
    product_name: String,
    product_description: String?,
    amount_value: String,
    currency: String,
    payment_method: String,
    platform: String,
    status: String,
    created_at: Long,
    updated_at: Long,
    expires_at: Long?,
    metadata: String?,
  ) -> T): Query<T> = SelectPaymentOrderByIdQuery(id) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!,
      cursor.getString(4),
      cursor.getString(5)!!,
      cursor.getString(6)!!,
      cursor.getString(7)!!,
      cursor.getString(8)!!,
      cursor.getString(9)!!,
      cursor.getLong(10)!!,
      cursor.getLong(11)!!,
      cursor.getLong(12),
      cursor.getString(13)
    )
  }

  public fun selectPaymentOrderById(id: String): Query<SDKPaymentOrder> = selectPaymentOrderById(id, ::SDKPaymentOrder)

  public fun <T : Any> selectPaymentHistoryByUserId(
    user_id: String,
    `value`: Long,
    mapper: (
      id: String,
      user_id: String,
      product_id: String,
      product_name: String,
      product_description: String?,
      amount_value: String,
      currency: String,
      payment_method: String,
      platform: String,
      status: String,
      created_at: Long,
      updated_at: Long,
      expires_at: Long?,
      metadata: String?,
    ) -> T,
  ): Query<T> = SelectPaymentHistoryByUserIdQuery(user_id, value) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!,
      cursor.getString(4),
      cursor.getString(5)!!,
      cursor.getString(6)!!,
      cursor.getString(7)!!,
      cursor.getString(8)!!,
      cursor.getString(9)!!,
      cursor.getLong(10)!!,
      cursor.getLong(11)!!,
      cursor.getLong(12),
      cursor.getString(13)
    )
  }

  public fun selectPaymentHistoryByUserId(user_id: String, value_: Long): Query<SDKPaymentOrder> = selectPaymentHistoryByUserId(user_id, value_, ::SDKPaymentOrder)

  public fun <T : Any> selectAllPaymentOrders(mapper: (
    id: String,
    user_id: String,
    product_id: String,
    product_name: String,
    product_description: String?,
    amount_value: String,
    currency: String,
    payment_method: String,
    platform: String,
    status: String,
    created_at: Long,
    updated_at: Long,
    expires_at: Long?,
    metadata: String?,
  ) -> T): Query<T> = Query(-1_472_832_110, arrayOf("SDKPaymentOrder"), driver, "SDKPaymentOrder.sq", "selectAllPaymentOrders", "SELECT SDKPaymentOrder.id, SDKPaymentOrder.user_id, SDKPaymentOrder.product_id, SDKPaymentOrder.product_name, SDKPaymentOrder.product_description, SDKPaymentOrder.amount_value, SDKPaymentOrder.currency, SDKPaymentOrder.payment_method, SDKPaymentOrder.platform, SDKPaymentOrder.status, SDKPaymentOrder.created_at, SDKPaymentOrder.updated_at, SDKPaymentOrder.expires_at, SDKPaymentOrder.metadata FROM SDKPaymentOrder") { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!,
      cursor.getString(4),
      cursor.getString(5)!!,
      cursor.getString(6)!!,
      cursor.getString(7)!!,
      cursor.getString(8)!!,
      cursor.getString(9)!!,
      cursor.getLong(10)!!,
      cursor.getLong(11)!!,
      cursor.getLong(12),
      cursor.getString(13)
    )
  }

  public fun selectAllPaymentOrders(): Query<SDKPaymentOrder> = selectAllPaymentOrders(::SDKPaymentOrder)

  /**
   * @return The number of rows updated.
   */
  public fun insertOrReplacePaymentOrder(
    id: String,
    user_id: String,
    product_id: String,
    product_name: String,
    product_description: String?,
    amount_value: String,
    currency: String,
    payment_method: String,
    platform: String,
    status: String,
    created_at: Long,
    updated_at: Long,
    expires_at: Long?,
    metadata: String?,
  ): QueryResult<Long> {
    val result = driver.execute(1_023_312_148, """
        |INSERT OR REPLACE INTO SDKPaymentOrder(id, user_id, product_id, product_name, product_description, amount_value, currency, payment_method, platform, status, created_at, updated_at, expires_at, metadata)
        |VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """.trimMargin(), 14) {
          var parameterIndex = 0
          bindString(parameterIndex++, id)
          bindString(parameterIndex++, user_id)
          bindString(parameterIndex++, product_id)
          bindString(parameterIndex++, product_name)
          bindString(parameterIndex++, product_description)
          bindString(parameterIndex++, amount_value)
          bindString(parameterIndex++, currency)
          bindString(parameterIndex++, payment_method)
          bindString(parameterIndex++, platform)
          bindString(parameterIndex++, status)
          bindLong(parameterIndex++, created_at)
          bindLong(parameterIndex++, updated_at)
          bindLong(parameterIndex++, expires_at)
          bindString(parameterIndex++, metadata)
        }
    notifyQueries(1_023_312_148) { emit ->
      emit("SDKPaymentOrder")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun updatePaymentOrderStatus(
    status: String,
    updated_at: Long,
    id: String,
  ): QueryResult<Long> {
    val result = driver.execute(1_241_177_263, """
        |UPDATE SDKPaymentOrder
        |SET status = ?, updated_at = ?
        |WHERE id = ?
        """.trimMargin(), 3) {
          var parameterIndex = 0
          bindString(parameterIndex++, status)
          bindLong(parameterIndex++, updated_at)
          bindString(parameterIndex++, id)
        }
    notifyQueries(1_241_177_263) { emit ->
      emit("SDKPaymentOrder")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deletePaymentOrderById(id: String): QueryResult<Long> {
    val result = driver.execute(302_365_873, """DELETE FROM SDKPaymentOrder WHERE id = ?""", 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, id)
        }
    notifyQueries(302_365_873) { emit ->
      emit("SDKPaymentOrder")
      emit("SDKPaymentResult")
      emit("SDKRefundRecord")
    }
    return result
  }

  private inner class SelectPaymentOrderByIdQuery<out T : Any>(
    public val id: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("SDKPaymentOrder", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("SDKPaymentOrder", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-1_608_537_598, """SELECT SDKPaymentOrder.id, SDKPaymentOrder.user_id, SDKPaymentOrder.product_id, SDKPaymentOrder.product_name, SDKPaymentOrder.product_description, SDKPaymentOrder.amount_value, SDKPaymentOrder.currency, SDKPaymentOrder.payment_method, SDKPaymentOrder.platform, SDKPaymentOrder.status, SDKPaymentOrder.created_at, SDKPaymentOrder.updated_at, SDKPaymentOrder.expires_at, SDKPaymentOrder.metadata FROM SDKPaymentOrder WHERE id = ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, id)
    }

    override fun toString(): String = "SDKPaymentOrder.sq:selectPaymentOrderById"
  }

  private inner class SelectPaymentHistoryByUserIdQuery<out T : Any>(
    public val user_id: String,
    public val `value`: Long,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("SDKPaymentOrder", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("SDKPaymentOrder", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(1_202_753_139, """SELECT SDKPaymentOrder.id, SDKPaymentOrder.user_id, SDKPaymentOrder.product_id, SDKPaymentOrder.product_name, SDKPaymentOrder.product_description, SDKPaymentOrder.amount_value, SDKPaymentOrder.currency, SDKPaymentOrder.payment_method, SDKPaymentOrder.platform, SDKPaymentOrder.status, SDKPaymentOrder.created_at, SDKPaymentOrder.updated_at, SDKPaymentOrder.expires_at, SDKPaymentOrder.metadata FROM SDKPaymentOrder WHERE user_id = ? ORDER BY created_at DESC LIMIT ?""", mapper, 2) {
      var parameterIndex = 0
      bindString(parameterIndex++, user_id)
      bindLong(parameterIndex++, value)
    }

    override fun toString(): String = "SDKPaymentOrder.sq:selectPaymentHistoryByUserId"
  }
}
