package com.zinben.opendev.db

import com.zinben.opendev.db.SDKDatabase

/**
 * SDK 数据库提供者
 * 
 * 为 SDK 层提供 SDKDatabase 实例的平台无关接口。
 * 各平台需要实现具体的数据库驱动创建逻辑。
 */
expect fun getDatabase(): SDKDatabase
