package com.zinben.opendev.managers

import com.zinben.opendev.adapters.PlatformAuthAdapter
import com.zinben.opendev.logger.Logger
import com.zinben.opendev.services.AuthService
import com.zinben.opendev.models.*
import com.zinben.opendev.db.LocalDatabase
import com.zinben.opendev.db.CloudDatabase
import com.zinben.opendev.utils.TimeUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.random.Random

import com.zinben.opendev.storage.SavedAccountStore
import com.zinben.opendev.storage.TokenStorage

class AuthManager(
    private val authService: AuthService,
    private val platformAdapter: PlatformAuthAdapter,
    private val localDatabase: LocalDatabase,
    private val tokenStorage: TokenStorage,
    private val cloudDatabase: CloudDatabase,
    private val savedAccountStore: SavedAccountStore,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Main)
) {
    
    private var currentUser: User? = null
    private var currentToken: String? = null
    private var currentJwtToken: String? = null
    private var currentExpiresAt: Long? = null

    private data class LoginContext(
        val provider: ThirdPartyProvider,
        val platformUserInfo: PlatformUserInfo,
        val accessToken: String?,
        val createdAt: Long = TimeUtils.getCurrentTimeMillis(),
        val requestId: String = generateRequestId()
    )

    private var pendingLoginContext: LoginContext? = null

    companion object {
        private const val LOGIN_CONTEXT_TTL_MS = 5 * 60 * 1000L

        private fun generateRequestId(): String {
            val chars = "abcdefghijklmnopqrstuvwxyz0123456789"
            return (1..16).map { chars[Random.nextInt(chars.length)] }.joinToString("")
        }
    }
    
    private suspend fun handleLoginSuccess(authResult: AuthResult.Success) {
        saveLocalAuth(authResult.user, authResult.sessionToken)
        scope.launch {
            try {
                cloudDatabase.syncUser(authResult.user)
                Logger.debug("AuthManager: User synced to cloud successfully")
            } catch (e: Exception) {
                Logger.error("AuthManager: Failed to sync user to cloud: ${e.message}")
            }
        }
        currentUser = authResult.user
        currentToken = authResult.sessionToken
        currentJwtToken = authResult.jwtToken
        currentExpiresAt = authResult.expiresAt

        trySaveSavedAccount(authResult.user)
    }

    /**
     * Persist non-sensitive metadata for the "Recent Accounts" list.
     *
     * **A11 guest guard**: pure guests (GUEST + no bound providers) are skipped
     * because they have no stable identity and cannot re-authenticate via OAuth/OTP.
     * Bound guests are saved with their actual bound login method.
     */
    private suspend fun trySaveSavedAccount(user: User) {
        try {
            val thirdPartyProviders = user.boundAccounts.mapNotNull { it.provider }
            val isGuestWithoutBinding = user.loginType == LoginType.GUEST && thirdPartyProviders.isEmpty()
                && user.boundAccounts.none { it.isOtp }
            if (isGuestWithoutBinding) {
                Logger.debug("SavedAccount: Skipping pure guest ${user.id} (A11 guard)")
                return
            }

            val loginMethod = resolveLoginMethodForSave(user)
            val maskedId = resolveMaskedIdentifier(user)

            savedAccountStore.upsert(
                SavedAccount(
                    userId = user.id,
                    displayName = user.nickname ?: user.username,
                    avatar = user.avatar,
                    loginMethod = loginMethod,
                    maskedIdentifier = maskedId,
                    lastUsedAt = TimeUtils.getCurrentTimeMillis(),
                    lastProvider = thirdPartyProviders.firstOrNull(),
                    boundProviders = thirdPartyProviders
                )
            )
        } catch (e: Exception) {
            Logger.error("SavedAccount: Failed to save account metadata: ${e.message}")
        }
    }

    private fun resolveLoginMethodForSave(user: User): SavedLoginMethod {
        return when (user.loginType) {
            LoginType.GUEST -> {
                val firstBound = user.boundAccounts.firstOrNull()
                firstBound?.provider?.toSavedLoginMethod()
                    ?: firstBound?.otpTargetType?.toSavedLoginMethod()
                    ?: SavedLoginMethod.GUEST
            }
            LoginType.OTP -> {
                if (user.email != null) SavedLoginMethod.EMAIL else SavedLoginMethod.PHONE
            }
            LoginType.THIRD_PARTY, LoginType.BOUND -> {
                val first = user.boundAccounts.firstOrNull()
                first?.provider?.toSavedLoginMethod()
                    ?: first?.otpTargetType?.toSavedLoginMethod()
                    ?: SavedLoginMethod.GUEST
            }
        }
    }

    private fun resolveMaskedIdentifier(user: User): String? {
        val otpBound = user.boundAccounts.firstOrNull { it.isOtp }
        if (otpBound != null) {
            val raw = otpBound.providerUserId ?: otpBound.providerUserName
            return raw?.maskIdentifier()
        }
        return user.email?.maskIdentifier()
    }
    
    // 初始化
    suspend fun initialize() {
        withContext(Dispatchers.Default) {
            platformAdapter.initializeSDK()
            
            // 尝试恢复本地登录状态并验证令牌有效性
            Logger.debug("AuthManager: Starting initialization, attempting to restore local session...")
            val localUser = localDatabase.getCurrentUser()
            val localToken = tokenStorage.getToken()
            
            Logger.debug("AuthManager: Local user: ${localUser?.id ?: "null"}, Local token: ${localToken?.take(10) ?: "null"}...")

            if (localUser != null && localToken != null) {
                Logger.debug("AuthManager: Found local user and token, validating...")
                val tokenValid = isTokenValid(localToken)
                Logger.debug("AuthManager: Token validation result: $tokenValid")
                if (tokenValid) {
                    currentUser = localUser
                    currentToken = localToken
                    Logger.debug("AuthManager: Restored local session for user ${localUser.id}")
                } else {
                    Logger.debug("AuthManager: Local token invalid, attempting refresh...")
                    // 尝试刷新 Token
                    // 需要临时设置 currentToken 和 currentUser 以便 refreshToken() 使用
                    currentToken = localToken
                    currentUser = localUser
                    
                    val refreshResult = refreshToken()
                    if (refreshResult is AuthResult.Success) {
                        Logger.debug("AuthManager: Token refreshed successfully during initialization")
                        // refreshToken() 内部已经更新了 currentToken 和数据库
                        currentUser = refreshResult.user
                    } else {
                        Logger.debug("AuthManager: Token refresh failed, clearing local auth")
                        clearLocalAuth()
                    }
                }
            } else {
                Logger.debug("AuthManager: No local user or token found, clearing local auth")
                if (localUser == null) {
                    Logger.debug("AuthManager: Local user is null")
                }
                if (localToken == null) {
                    Logger.debug("AuthManager: Local token is null")
                }
                clearLocalAuth()
            }
        }
    }
    
    // 执行第三方登录
    suspend fun performThirdPartyLogin(provider: ThirdPartyProvider): AuthResult {
        return withContext(Dispatchers.Default) {
            try {
                // 1. 检查平台是否可用
                if (!platformAdapter.isProviderAvailable(provider)) {
                    Logger.debug("AuthManager: Provider $provider not available on current platform")
                    return@withContext AuthResult.Failure(AuthError.PLATFORM_AUTH_FAILED)
                }
                
                Logger.debug("AuthManager: performThirdPartyLogin called for provider=$provider, isLoggedIn=${isLoggedIn()}")
                
                // 3. 平台认证
                Logger.debug("AuthManager: Starting platform authentication for $provider")
                val platformResult = platformAdapter.authenticate(provider, currentUser?.id)
                if (platformResult !is PlatformAuthResult.Success) {
                    return@withContext when (platformResult) {
                        is PlatformAuthResult.Cancelled -> {
                            Logger.debug("AuthManager: Platform authentication cancelled by user")
                            AuthResult.Cancelled
                        }
                        is PlatformAuthResult.Failure -> {
                            Logger.error("AuthManager: Platform authentication failed: ${platformResult.errorMessage}")
                            AuthResult.Failure(AuthError.PLATFORM_AUTH_FAILED)
                        }
                    }
                }
                
                // 4. 获取平台用户信息
                val platformUserInfo = platformAdapter.getUserInfo(provider)
                if (platformUserInfo == null) {
                    Logger.error("AuthManager: Failed to get platform user info for $provider")
                    return@withContext AuthResult.Failure(AuthError.USER_INFO_NOT_FOUND)
                }
                
                // 5. 调用后端认证服务
                Logger.debug("AuthManager: Calling backend authentication service")
                val platformResultSuccess = platformResult as PlatformAuthResult.Success
                val authResult = authService.thirdPartyLogin(
                    provider = provider,
                    platformUserInfo = platformUserInfo,
                    accessToken = platformResultSuccess.accessToken
                )

                if (authResult is AuthResult.MultipleAccounts) {
                    Logger.debug("AuthManager: Multiple accounts found, saving login context")
                    pendingLoginContext = LoginContext(provider, platformUserInfo, platformResultSuccess.accessToken)
                    return@withContext authResult
                }

                if (authResult is AuthResult.Unlinked) {
                    Logger.debug("AuthManager: Provider ${provider.name} unlinked, auto-registering guest + binding")
                    return@withContext autoRegisterAndBind(
                        provider = provider,
                        platformUserInfo = platformUserInfo,
                        accessToken = platformResultSuccess.accessToken
                    )
                }

                if (authResult !is AuthResult.Success) {
                    when (authResult) {
                        is AuthResult.Failure -> Logger.error("AuthManager: Backend authentication failed: ${authResult.error}")
                        is AuthResult.Pending -> Logger.debug("AuthManager: Backend authentication pending: ${authResult.message}")
                        is AuthResult.Cancelled -> Logger.debug("AuthManager: Backend authentication cancelled")
                    }
                    return@withContext authResult
                }
                
                pendingLoginContext = null
                handleLoginSuccess(authResult)
                Logger.debug("AuthManager: Third party login successful for user ${authResult.user.id}")
                authResult
            } catch (e: Exception) {
                Logger.error("AuthManager: Third party login error: ${e.message}")
                AuthResult.Failure(AuthError.NETWORK_ERROR)
            }
        }
    }

    /**
     * Auto register a guest account and bind the third-party provider.
     * Triggered when backend returns `unlinked` (provider has no associated account).
     * The entire flow is transparent to the caller — returns Success or Failure.
     */
    private suspend fun autoRegisterAndBind(
        provider: ThirdPartyProvider,
        platformUserInfo: PlatformUserInfo,
        accessToken: String?
    ): AuthResult {
        val guestResult = performGuestLogin()
        if (guestResult !is AuthResult.Success) {
            Logger.error("AuthManager: Auto-register guest failed during unlinked flow")
            return AuthResult.Failure(AuthError.NETWORK_ERROR)
        }

        Logger.debug("AuthManager: Guest created (${guestResult.user.id}), binding ${provider.name}")

        val bindPayload = PlatformAuthResult.Success(
            providerUserId = platformUserInfo.providerUserId,
            accessToken = accessToken ?: "",
            userInfo = platformUserInfo
        )
        val bindResult = authService.bindAccount(
            provider = provider,
            authToken = guestResult.sessionToken,
            authPayload = bindPayload
        )

        if (bindResult is AuthResult.Success) {
            saveLocalAuth(bindResult.user, guestResult.sessionToken)
            currentUser = bindResult.user
            Logger.debug("AuthManager: Auto-register + bind successful for user ${bindResult.user.id}")
            return AuthResult.Success(
                user = bindResult.user,
                sessionToken = guestResult.sessionToken,
                jwtToken = guestResult.jwtToken,
                expiresAt = guestResult.expiresAt
            )
        }

        Logger.error("AuthManager: Bind failed after guest creation, cleaning up orphan guest")
        try {
            authService.logout(guestResult.sessionToken)
        } catch (e: Exception) {
            Logger.error("AuthManager: Failed to cleanup orphan guest: ${e.message}")
        }
        clearLocalAuth()
        return AuthResult.Failure(
            (bindResult as? AuthResult.Failure)?.error ?: AuthError.NETWORK_ERROR
        )
    }

    /**
     * 选择账号登录（多账号场景）
     *
     * Cleanup strategy:
     * - Success → clear pending (login complete)
     * - Failure → preserve pending (allow user to retry or pick another account)
     */
    suspend fun loginSelectedAccount(user: User): AuthResult {
        return withContext(Dispatchers.Default) {
            try {
                val context = pendingLoginContext
                if (context == null) {
                    Logger.error("AuthManager: No pending login context found")
                    return@withContext AuthResult.Failure(AuthError.UNKNOWN_ERROR)
                }

                val elapsed = TimeUtils.getCurrentTimeMillis() - context.createdAt
                if (elapsed > LOGIN_CONTEXT_TTL_MS) {
                    Logger.error("AuthManager: Pending login context expired (${elapsed}ms > ${LOGIN_CONTEXT_TTL_MS}ms)")
                    pendingLoginContext = null
                    return@withContext AuthResult.Failure(AuthError.LOGIN_CONTEXT_EXPIRED)
                }
                
                Logger.debug("AuthManager: Logging in with selected user: ${user.id}, requestId=${context.requestId}")
                
                val authResult = authService.thirdPartyLogin(
                    provider = context.provider,
                    platformUserInfo = context.platformUserInfo,
                    accessToken = context.accessToken,
                    targetUserId = user.id
                )
                
                when (authResult) {
                    is AuthResult.Success -> {
                        handleLoginSuccess(authResult)
                        pendingLoginContext = null
                        Logger.debug("AuthManager: Selected account login successful for user ${authResult.user.id}")
                    }
                    is AuthResult.Failure -> {
                        Logger.error("AuthManager: Selected account login failed: ${authResult.error}, pending preserved for retry")
                    }
                    else -> {}
                }
                
                authResult
            } catch (e: Exception) {
                Logger.error("AuthManager: Selected account login error: ${e.message}")
                AuthResult.Failure(AuthError.NETWORK_ERROR)
            }
        }
    }

    // 游客登录
    suspend fun performGuestLogin(): AuthResult {
        return withContext(Dispatchers.Default) {
            try {
                // 检查是否已有用户登录
                if (isLoggedIn()) {
                    Logger.debug("AuthManager: User already logged in, returning current user")
                    return@withContext AuthResult.Success(
                        user = currentUser!!,
                        sessionToken = currentToken!!,
                        jwtToken = null,
                        expiresAt = null
                    )
                }
                
                Logger.debug("AuthManager: Starting guest login")
                val authResult = authService.guestLogin()
                if (authResult is AuthResult.Success) {
                    handleLoginSuccess(authResult)
                    Logger.debug("AuthManager: Guest login successful for user ${authResult.user.id}")
                } else {
                    when (authResult) {
                        is AuthResult.Failure -> Logger.error("AuthManager: Guest login failed: ${authResult.error}")
                        is AuthResult.Pending -> Logger.debug("AuthManager: Guest login pending: ${authResult.message}")
                        is AuthResult.MultipleAccounts -> Logger.error("AuthManager: Guest login returned multiple accounts (unexpected)")
                        is AuthResult.Unlinked -> Logger.error("AuthManager: Guest login returned unlinked (unexpected)")
                        is AuthResult.Cancelled -> Logger.debug("AuthManager: Guest login cancelled")
                    }
                }
                authResult
            } catch (e: Exception) {
                Logger.error("AuthManager: Guest login error: ${e.message}")
                AuthResult.Failure(AuthError.NETWORK_ERROR)
            }
        }
    }
    
    // 账号绑定
    suspend fun bindAccount(provider: ThirdPartyProvider): AuthResult {
        return withContext(Dispatchers.Default) {
            try {
                // 1. 检查用户是否已登录
                if (!isLoggedIn()) {
                    Logger.debug("AuthManager: No user logged in, cannot bind account")
                    return@withContext AuthResult.Failure(AuthError.USER_NOT_FOUND)
                }
                
                // 2. 检查是否已经绑定该提供商
                if (currentUser?.boundAccounts?.any { it.provider == provider } == true) {
                    Logger.debug("AuthManager: Account already bound to $provider")
                    return@withContext AuthResult.Success(
                        user = currentUser!!,
                        sessionToken = currentToken!!,
                        jwtToken = null,
                        expiresAt = null
                    )
                }
                
                // 3. 检查平台是否可用
                if (!platformAdapter.isProviderAvailable(provider)) {
                    Logger.debug("AuthManager: Provider $provider not available for binding")
                    return@withContext AuthResult.Failure(AuthError.PLATFORM_AUTH_FAILED)
                }
                
                // 4. 平台认证
                Logger.debug("AuthManager: Starting platform authentication for account binding")
                val platformResult = platformAdapter.authenticate(provider, currentUser?.id)
                if (platformResult !is PlatformAuthResult.Success) {
                    return@withContext when (platformResult) {
                        is PlatformAuthResult.Cancelled -> {
                            Logger.debug("AuthManager: Platform authentication cancelled during binding")
                            AuthResult.Cancelled
                        }
                        is PlatformAuthResult.Failure -> {
                            Logger.error("AuthManager: Platform authentication failed during binding: ${platformResult.errorMessage}")
                            AuthResult.Failure(AuthError.PLATFORM_AUTH_FAILED)
                        }
                    }
                }
                
                // 5. 获取当前认证 token
                val authToken = currentToken ?: tokenStorage.getToken()
                    ?: return@withContext AuthResult.Failure(AuthError.INVALID_CREDENTIALS)
                
                // 6. 调用后端绑定服务
                Logger.debug("AuthManager: Calling backend account binding service")
                val authResult = authService.bindAccount(provider, authToken, platformResult)
                if (authResult !is AuthResult.Success) {
                    when (authResult) {
                        is AuthResult.Failure -> Logger.error("AuthManager: Backend account binding failed: ${authResult.error}")
                        is AuthResult.Pending -> Logger.debug("AuthManager: Backend account binding pending: ${authResult.message}")
                        is AuthResult.MultipleAccounts -> Logger.error("AuthManager: bindAccount returned multiple accounts (unexpected)")
                        is AuthResult.Unlinked -> Logger.error("AuthManager: bindAccount returned unlinked (unexpected)")
                        is AuthResult.Cancelled -> Logger.debug("AuthManager: Backend account binding cancelled")
                    }
                    return@withContext authResult
                }
                
                // 7. 更新本地数据
                currentUser = authResult.user
                localDatabase.updateUser(authResult.user)
                
                // 8. 同步到云端
                scope.launch {
                    try {
                        cloudDatabase.syncUser(authResult.user)
                        Logger.debug("AuthManager: Bound account synced to cloud successfully")
                    } catch (e: Exception) {
                        Logger.error("AuthManager: Failed to sync bound account to cloud: ${e.message}")
                    }
                }
                
                Logger.debug("AuthManager: Account binding successful for $provider")
                authResult
            } catch (e: Exception) {
                Logger.error("AuthManager: Account binding error: ${e.message}")
                AuthResult.Failure(AuthError.NETWORK_ERROR)
            }
        }
    }
    
    suspend fun unbindAccount(provider: ThirdPartyProvider): AuthResult {
        return withContext(Dispatchers.Default) {
            try {
                if (!isLoggedIn()) {
                    Logger.error("AuthManager: No user logged in, cannot unbind account")
                    return@withContext AuthResult.Failure(AuthError.USER_NOT_FOUND)
                }
                
                val authToken = currentToken ?: tokenStorage.getToken()
                    ?: return@withContext AuthResult.Failure(AuthError.INVALID_CREDENTIALS)

                val boundAccount = currentUser?.boundAccounts?.firstOrNull { it.provider == provider }
                if (boundAccount == null) {
                    Logger.error("AuthManager: No bound account found for provider=$provider")
                    return@withContext AuthResult.Failure(AuthError.USER_NOT_FOUND)
                }

                Logger.debug("AuthManager: Starting unbindAccount for provider=$provider")
                val authResult = authService.unbindAccount(provider, authToken, boundAccount)
                if (authResult is AuthResult.Success) {
                    currentUser = authResult.user
                    localDatabase.updateUser(authResult.user)
                    
                    scope.launch {
                        try {
                            cloudDatabase.syncUser(authResult.user)
                            Logger.debug("AuthManager: Unbound account synced to cloud successfully")
                        } catch (e: Exception) {
                            Logger.error("AuthManager: Failed to sync unbound account to cloud: ${e.message}")
                        }
                    }
                }
                authResult
            } catch (e: Exception) {
                Logger.error("AuthManager: Unbind account error: ${e.message}")
                AuthResult.Failure(AuthError.NETWORK_ERROR)
            }
        }
    }

    suspend fun bindOtpAccount(targetType: OtpTargetType, target: String): AuthResult {
        return withContext(Dispatchers.Default) {
            try {
                if (!isLoggedIn()) return@withContext AuthResult.Failure(AuthError.USER_NOT_FOUND)
                val authToken = currentToken ?: tokenStorage.getToken()
                    ?: return@withContext AuthResult.Failure(AuthError.INVALID_CREDENTIALS)

                val authResult = authService.bindOtpAccount(targetType, target, authToken)
                if (authResult is AuthResult.Success) {
                    currentUser = authResult.user
                    localDatabase.updateUser(authResult.user)
                    scope.launch {
                        runCatching { cloudDatabase.syncUser(authResult.user) }
                    }
                }
                authResult
            } catch (e: Exception) {
                Logger.error("AuthManager: Bind OTP account error: ${e.message}")
                AuthResult.Failure(AuthError.NETWORK_ERROR)
            }
        }
    }

    suspend fun unbindOtpAccount(targetType: OtpTargetType, target: String): AuthResult {
        return withContext(Dispatchers.Default) {
            try {
                if (!isLoggedIn()) return@withContext AuthResult.Failure(AuthError.USER_NOT_FOUND)
                val authToken = currentToken ?: tokenStorage.getToken()
                    ?: return@withContext AuthResult.Failure(AuthError.INVALID_CREDENTIALS)

                val authResult = authService.unbindOtpAccount(targetType, target, authToken)
                if (authResult is AuthResult.Success) {
                    currentUser = authResult.user
                    localDatabase.updateUser(authResult.user)
                    scope.launch {
                        runCatching { cloudDatabase.syncUser(authResult.user) }
                    }
                }
                authResult
            } catch (e: Exception) {
                Logger.error("AuthManager: Unbind OTP account error: ${e.message}")
                AuthResult.Failure(AuthError.NETWORK_ERROR)
            }
        }
    }

    // 登出
    suspend fun logout(): AuthResult {
        return withContext(Dispatchers.Default) {
            try {
                // 检查用户是否已登录
                if (!isLoggedIn()) {
                    Logger.debug("AuthManager: No user logged in, logout not needed")
                    return@withContext AuthResult.Success(
                        user = User(
                            id = "",
                            username = "",
                            loginType = LoginType.GUEST,
                            createdAt = 0L,
                            lastLoginAt = 0L
                        ),
                        sessionToken = "",
                        jwtToken = null,
                        expiresAt = null
                    )
                }
                
                val userId = currentUser?.id
                Logger.debug("AuthManager: Starting logout for user $userId")
                
                // 获取当前认证 token（可能为 null，如果用户未登录）
                val authToken = currentToken ?: tokenStorage.getToken()
                
                // 调用后端登出服务
                val authResult = authService.logout(authToken)
                
                // 清理本地数据
                clearLocalAuth()
                
                // 异步清理云端会话（使用 try-catch 包裹，避免 scope 被取消时导致 logout 失败）
                try {
                    scope.launch {
                        try {
                            cloudDatabase.clearUserSession(userId)
                            Logger.debug("AuthManager: User session cleared from cloud successfully")
                        } catch (e: Exception) {
                            Logger.error("AuthManager: Failed to clear user session from cloud: ${e.message}")
                        }
                    }
                } catch (e: Exception) {
                    // 如果 scope 已被取消，记录日志但不影响登出流程
                    Logger.debug("AuthManager: Scope cancelled, skipping cloud session cleanup: ${e.message}")
                }
                
                Logger.debug("AuthManager: Logout successful")
                authResult
            } catch (e: Exception) {
                Logger.error("AuthManager: Logout error: ${e.message}")
                // 即使网络失败，也要清理本地数据
                clearLocalAuth()
                AuthResult.Failure(AuthError.NETWORK_ERROR)
            }
        }
    }
    
    // 刷新令牌
    suspend fun refreshToken(): AuthResult {
        return withContext(Dispatchers.Default) {
            try {
                // 检查用户是否已登录
                if (!isLoggedIn()) {
                    Logger.debug("AuthManager: No user logged in, cannot refresh token")
                    return@withContext AuthResult.Failure(AuthError.USER_NOT_FOUND)
                }
                
                // 获取当前认证 token
                val authToken = currentToken ?: tokenStorage.getToken()
                    ?: return@withContext AuthResult.Failure(AuthError.INVALID_CREDENTIALS)
                
                Logger.debug("AuthManager: Refreshing token for user ${currentUser?.id}")
                
                // 调用后端刷新令牌服务
                val authResult = authService.refreshToken(authToken)
                if (authResult is AuthResult.Success) {
                    // 更新当前令牌
                    currentToken = authResult.sessionToken
                    tokenStorage.saveToken(authResult.sessionToken)
                    
                    Logger.debug("AuthManager: Token refreshed successfully")
                } else {
                    when (authResult) {
                        is AuthResult.Failure -> Logger.error("AuthManager: Token refresh failed: ${authResult.error}")
                        is AuthResult.Pending -> Logger.debug("AuthManager: Token refresh pending: ${authResult.message}")
                        is AuthResult.MultipleAccounts -> Logger.error("AuthManager: Token refresh returned multiple accounts (unexpected)")
                        is AuthResult.Unlinked -> Logger.error("AuthManager: Token refresh returned unlinked (unexpected)")
                        is AuthResult.Cancelled -> Logger.debug("AuthManager: Token refresh cancelled")
                    }
                }
                authResult
            } catch (e: Exception) {
                Logger.error("AuthManager: Token refresh error: ${e.message}")
                AuthResult.Failure(AuthError.NETWORK_ERROR)
            }
        }
    }
    
    // 更新用户信息
    suspend fun updateUserInfo(user: User): AuthResult {
        return withContext(Dispatchers.Default) {
            try {
                // 检查用户是否已登录
                if (!isLoggedIn()) {
                    Logger.debug("AuthManager: No user logged in, cannot update user info")
                    return@withContext AuthResult.Failure(AuthError.USER_NOT_FOUND)
                }
                
                val authToken = currentToken ?: tokenStorage.getToken()
                    ?: return@withContext AuthResult.Failure(AuthError.INVALID_CREDENTIALS)

                Logger.debug("AuthManager: Updating user info for ${user.id}")
                val authResult = authService.updateUserInfo(user, authToken)
                
                if (authResult is AuthResult.Success) {
                    // 更新本地缓存和数据库
                    currentUser = authResult.user
                    localDatabase.updateUser(authResult.user)
                    
                    // 同步到云端
                    scope.launch {
                        try {
                            cloudDatabase.syncUser(authResult.user)
                            Logger.debug("AuthManager: Updated user info synced to cloud successfully")
                        } catch (e: Exception) {
                            Logger.error("AuthManager: Failed to sync updated user info to cloud: ${e.message}")
                        }
                    }
                    
                    Logger.debug("AuthManager: User info updated successfully")
                }
                
                authResult
            } catch (e: Exception) {
                Logger.error("AuthManager: Update user info error: ${e.message}")
                AuthResult.Failure(AuthError.NETWORK_ERROR)
            }
        }
    }
    
    suspend fun uploadAvatar(imageBytes: ByteArray, fileName: String, mimeType: String, authToken: String): String {
        return withContext(Dispatchers.Default) {
            Logger.debug("AuthManager: Uploading avatar ($fileName, ${imageBytes.size} bytes)")
            val avatarUrl = authService.uploadAvatar(imageBytes, fileName, mimeType, authToken).getOrThrow()

            val user = currentUser
            if (user != null) {
                val updatedUser = user.copy(avatar = avatarUrl)
                currentUser = updatedUser
                localDatabase.updateUser(updatedUser)
                Logger.debug("AuthManager: Avatar persisted locally for user ${user.id}")
            }

            avatarUrl
        }
    }

    suspend fun updateLocalUser(user: User) {
        currentUser = user
        localDatabase.updateUser(user)
    }

    fun getCurrentUser(): User? = currentUser
    
    // 检查登录状态
    fun isLoggedIn(): Boolean = currentUser != null && currentToken != null
    
    // 获取访问令牌
    fun getAccessToken(): String? = currentToken
    
    // 保存本地认证信息
    private suspend fun saveLocalAuth(user: User, token: String) {
        Logger.debug("AuthManager: Saving local auth - user: ${user.id}, token: ${token.take(10)}...")
        localDatabase.saveUser(user)
        tokenStorage.saveToken(token)
        Logger.debug("AuthManager: Local auth saved successfully")
        
        // 验证保存是否成功
        val savedUser = localDatabase.getCurrentUser()
        val savedToken = tokenStorage.getToken()
        Logger.debug("AuthManager: Verification - saved user: ${savedUser?.id ?: "null"}, saved token: ${savedToken?.take(10) ?: "null"}...")
    }
    
    // 清理本地认证信息
    private suspend fun clearLocalAuth() {
        currentUser = null
        currentToken = null
        localDatabase.clearAuth()
        tokenStorage.clearToken()
    }

    
    // 验证令牌有效性
    private suspend fun isTokenValid(token: String): Boolean {
        return try {
            authService.checkLoginStatus(token)
        } catch (e: Exception) {
            false
        }
    }
    
    suspend fun getSupportedProviders(): List<ThirdPartyProvider> {
        return platformAdapter.getSupportedProviders()
    }

    suspend fun getOAuthConfig(appId: String, channelKey: String? = null): OAuthConfigResponse {
        return authService.getOAuthConfig(appId, channelKey)
    }

    suspend fun getAvailableChannels(appId: String): List<ChannelInfo> {
        return authService.getAvailableChannels(appId)
    }

    fun getJwtToken(): String? = currentJwtToken

    fun getExpiresAt(): Long? = currentExpiresAt

    // ==================== OTP ====================

    suspend fun sendOtp(
        appId: String,
        targetType: OtpTargetType,
        target: String,
        channelKey: String? = null
    ): OtpSendResult {
        return withContext(Dispatchers.Default) {
            Logger.debug("AuthManager: Sending OTP to $targetType:$target")
            authService.sendOtp(appId, targetType, target, channelKey)
        }
    }

    suspend fun verifyOtpAndLogin(
        appId: String,
        targetType: OtpTargetType,
        target: String,
        sessionId: String,
        code: String,
        channelKey: String? = null
    ): AuthResult {
        return withContext(Dispatchers.Default) {
            try {
                Logger.debug("AuthManager: Verifying OTP for $targetType:$target")
                val verifyResult = authService.verifyOtp(appId, targetType, target, sessionId, code, channelKey)

                Logger.debug("AuthManager: OTP verified, fetching auth payload for sessionId=${verifyResult.sessionId}")
                val payloadResponse = authService.getAuthPayload(
                    userId = verifyResult.sessionId,
                    provider = verifyResult.provider ?: targetType.toApiType(),
                    appId = appId
                )

                val entry = payloadResponse.payloads.firstOrNull()
                    ?: throw IllegalStateException("No auth payload found after OTP verification")

                val providerType = entry.provider?.toThirdPartyProviderOrNull()
                val otpProviderUserId = entry.email ?: target
                val userInfo = PlatformUserInfo(
                    providerUserId = otpProviderUserId,
                    username = entry.name,
                    email = entry.email ?: if (targetType == OtpTargetType.EMAIL) target else null,
                    provider = providerType ?: ThirdPartyProvider.GOOGLE
                )

                Logger.debug("AuthManager: Calling account login with OTP payload")
                val authResult = authService.thirdPartyLogin(
                    provider = providerType ?: ThirdPartyProvider.GOOGLE,
                    platformUserInfo = userInfo,
                    accessToken = entry.accessToken
                )

                when (authResult) {
                    is AuthResult.Success -> {
                        pendingLoginContext = null
                        handleLoginSuccess(authResult)
                        Logger.debug("AuthManager: OTP login successful for user ${authResult.user.id}")
                    }
                    is AuthResult.Failure -> Logger.error("AuthManager: OTP login failed: ${authResult.error}")
                    is AuthResult.MultipleAccounts -> {
                        pendingLoginContext = LoginContext(
                            provider = providerType ?: ThirdPartyProvider.GOOGLE,
                            platformUserInfo = userInfo,
                            accessToken = entry.accessToken
                        )
                        Logger.debug("AuthManager: OTP login returned ${authResult.users.size} accounts, pendingLoginContext saved (requestId=${pendingLoginContext?.requestId})")
                    }
                    is AuthResult.Unlinked -> {
                        Logger.debug("AuthManager: OTP provider unlinked, auto-registering guest + binding")
                        return@withContext autoRegisterAndBind(
                            provider = providerType ?: ThirdPartyProvider.GOOGLE,
                            platformUserInfo = userInfo,
                            accessToken = entry.accessToken
                        )
                    }
                    is AuthResult.Pending -> Logger.debug("AuthManager: OTP login pending: ${authResult.message}")
                    is AuthResult.Cancelled -> Logger.debug("AuthManager: OTP login cancelled")
                }
                authResult
            } catch (e: Exception) {
                Logger.error("AuthManager: OTP login error: ${e.message}")
                AuthResult.Failure(AuthError.NETWORK_ERROR)
            }
        }
    }

    // ==================== Saved Accounts API ====================

    suspend fun getSavedAccounts(): List<SavedAccount> = savedAccountStore.getAll()

    suspend fun removeSavedAccount(userId: String) = savedAccountStore.remove(userId)

    suspend fun clearAllSavedAccounts() = savedAccountStore.clearAll()

    suspend fun cleanup() {
        platformAdapter.cleanup()
    }
}

private fun ThirdPartyProvider.toSavedLoginMethod(): SavedLoginMethod = when (this) {
    ThirdPartyProvider.FACEBOOK -> SavedLoginMethod.FACEBOOK
    ThirdPartyProvider.GOOGLE -> SavedLoginMethod.GOOGLE
    ThirdPartyProvider.APPLE -> SavedLoginMethod.APPLE
    ThirdPartyProvider.WECHAT -> SavedLoginMethod.WECHAT
    ThirdPartyProvider.QQ -> SavedLoginMethod.QQ
}

private fun OtpTargetType.toSavedLoginMethod(): SavedLoginMethod = when (this) {
    OtpTargetType.PHONE -> SavedLoginMethod.PHONE
    OtpTargetType.EMAIL -> SavedLoginMethod.EMAIL
}

private fun String.maskIdentifier(): String {
    if (contains("@")) {
        val parts = split("@", limit = 2)
        val local = parts[0]
        val domain = parts.getOrElse(1) { "" }
        val masked = if (local.length <= 2) "$local***" else "${local.take(2)}***${local.takeLast(1)}"
        return "$masked@$domain"
    }
    if (length <= 4) return "$this***"
    return "${take(3)}****${takeLast(4)}"
}
