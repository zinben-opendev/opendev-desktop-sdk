package com.zinben.opendev.managers

import com.zinben.opendev.adapters.PaymentPlatformAdapter
import com.zinben.opendev.logger.Logger
import com.zinben.opendev.services.PaymentService
import com.zinben.opendev.models.*
import com.zinben.opendev.db.LocalDatabase
import com.zinben.opendev.db.CloudDatabase
import com.zinben.opendev.utils.TimeUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 支付管理器
 * 
 * 时间处理：使用 TimeUtils 统一封装，避免直接依赖实验性 API
 */
class PaymentManager(
    private val paymentService: PaymentService,
    private val platformAdapters: Map<PaymentMethodType, PaymentPlatformAdapter>,
    private val localDatabase: LocalDatabase,
    private val cloudDatabase: CloudDatabase,
    private val securityManager: PaymentSecurityManager,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Main)
) {
    
    // 执行支付
    suspend fun performPayment(paymentRequest: PaymentRequest): PaymentResult {
        return withContext(Dispatchers.Default) {
            try {
                // 1. 验证支付请求
                if (!securityManager.validatePaymentRequest(paymentRequest)) {
                    return@withContext PaymentResult.Failure(
                        orderId = paymentRequest.orderId,
                        errorCode = "INVALID_REQUEST",
                        errorMessage = "Invalid payment request"
                    )
                }
                
                // 2. 获取支付平台适配器
                val adapter = platformAdapters[paymentRequest.paymentMethod]
                    ?: return@withContext PaymentResult.Failure(
                        orderId = paymentRequest.orderId,
                        errorCode = "UNSUPPORTED_PAYMENT_METHOD",
                        errorMessage = "Payment method not supported"
                    )
                
                // 3. 检查支付方式是否可用
                if (!adapter.isPaymentMethodAvailable(paymentRequest.paymentMethod)) {
                    return@withContext PaymentResult.Failure(
                        orderId = paymentRequest.orderId,
                        errorCode = "PAYMENT_METHOD_UNAVAILABLE",
                        errorMessage = "Payment method is currently unavailable"
                    )
                }
                
                // 4. 执行平台支付
                val platformResult = adapter.createPayment(paymentRequest)
                if (platformResult !is PlatformPaymentResult.Success) {
                    return@withContext when (platformResult) {
                        is PlatformPaymentResult.Cancelled -> PaymentResult.Failure(
                            orderId = paymentRequest.orderId,
                            errorCode = "USER_CANCELLED",
                            errorMessage = "Payment cancelled by user"
                        )
                        is PlatformPaymentResult.Failed -> PaymentResult.Failure(
                            orderId = paymentRequest.orderId,
                            errorCode = platformResult.errorCode,
                            errorMessage = platformResult.errorMessage
                        )
                        is PlatformPaymentResult.Success -> {
                            // 不会执行到这里
                            PaymentResult.Failure(
                                orderId = paymentRequest.orderId,
                                errorCode = "UNKNOWN",
                                errorMessage = "Unknown error"
                            )
                        }
                    }
                }
                
                // 5. 获取订单信息（用于获取金额和货币）
                val order = localDatabase.getPaymentOrder(paymentRequest.orderId)
                    ?: return@withContext PaymentResult.Failure(
                        orderId = paymentRequest.orderId,
                        errorCode = "ORDER_NOT_FOUND",
                        errorMessage = "Payment order not found"
                    )
                
                // 6. 验证支付结果
                if (!adapter.verifyPayment(platformResult.paymentData)) {
                    return@withContext PaymentResult.Failure(
                        orderId = paymentRequest.orderId,
                        errorCode = "PAYMENT_VERIFICATION_FAILED",
                        errorMessage = "Payment verification failed"
                    )
                }
                
                // 7. 更新订单状态
                val paymentResult = PaymentResult.Success(
                    orderId = paymentRequest.orderId,
                    transactionId = platformResult.transactionId,
                    amount = order.amount,
                    currency = order.currency,
                    paymentTime = TimeUtils.getCurrentTimeMillis()
                )
                
                // 7. 保存到本地数据库
                localDatabase.savePaymentResult(paymentResult)
                
                // 8. 同步到云端数据库
                scope.launch {
                    cloudDatabase.syncPaymentResult(paymentResult)
                }
                
                paymentResult
            } catch (e: Exception) {
                PaymentResult.Failure(
                    orderId = paymentRequest.orderId,
                    errorCode = "PAYMENT_ERROR",
                    errorMessage = e.message ?: "Payment failed"
                )
            }
        }
    }
    
    // 创建支付订单
    suspend fun createPaymentOrder(request: CreatePaymentRequest): PaymentOrder {
        return withContext(Dispatchers.Default) {
            try {
                // 通过PaymentService创建订单
                val order = paymentService.createPaymentOrder(request)
                
                // 保存到本地数据库
                localDatabase.savePaymentOrder(order)
                
                // 同步到云端
                scope.launch {
                    cloudDatabase.syncPaymentOrder(order)
                }
                
                order
            } catch (e: Exception) {
                throw RuntimeException("Failed to create payment order: ${e.message}")
            }
        }
    }
    
    // 查询支付状态
    suspend fun queryPaymentStatus(orderId: String): PaymentStatus {
        return withContext(Dispatchers.Default) {
            try {
                // 先查询本地数据库
                val localStatus = localDatabase.getPaymentStatus(orderId)
                if (localStatus != null) {
                    return@withContext localStatus
                }
                
                // 通过PaymentService查询云端状态
                val cloudStatus = paymentService.queryPaymentStatus(orderId)
                
                // 更新本地状态
                localDatabase.updatePaymentStatus(orderId, cloudStatus)
                
                cloudStatus
            } catch (e: Exception) {
                PaymentStatus.FAILED
            }
        }
    }
    
    // 申请退款
    suspend fun requestRefund(refundRequest: RefundRequest): RefundResult {
        return withContext(Dispatchers.Default) {
            try {
                // 1. 验证退款请求
                if (!securityManager.validateRefundRequest(refundRequest)) {
                    return@withContext RefundResult.Failure(
                        errorCode = "INVALID_REFUND_REQUEST",
                        errorMessage = "Invalid refund request"
                    )
                }
                
                // 2. 获取支付平台适配器
                val order = localDatabase.getPaymentOrder(refundRequest.orderId)
                    ?: throw RuntimeException("Payment order not found")
                
                val adapter = platformAdapters[order.paymentMethod]
                    ?: throw RuntimeException("Payment method not supported")
                
                // 3. 执行平台退款
                val platformRefundResult = adapter.refundPayment(refundRequest)
                if (platformRefundResult !is PlatformRefundResult.Success) {
                    return@withContext when (platformRefundResult) {
                        is PlatformRefundResult.Failure -> {
                            RefundResult.Failure(
                                errorCode = platformRefundResult.errorCode,
                                errorMessage = platformRefundResult.errorMessage
                            )
                        }
                        is PlatformRefundResult.Success -> {
                            // 不会执行到这里
                            RefundResult.Failure(
                                errorCode = "UNKNOWN",
                                errorMessage = "Unknown error"
                            )
                        }
                    }
                }
                
                // 4. 通过PaymentService申请退款
                val refundResult = paymentService.requestRefund(refundRequest)
                
                // 5. 保存退款记录
                if (refundResult !is RefundResult.Success) {
                    return@withContext when (refundResult) {
                        is RefundResult.Failure -> refundResult
                        is RefundResult.Success -> {
                            // 不会执行到这里
                            RefundResult.Failure("UNKNOWN", "Unknown error")
                        }
                    }
                }
                
                val refundRecord = RefundRecord(
                    id = refundResult.refundId,
                    transactionId = refundRequest.transactionId,
                    orderId = refundRequest.orderId,
                    amount = refundRequest.amount,
                    currency = refundRequest.currency,
                    reason = refundRequest.reason,
                    status = PaymentStatus.SUCCESS,
                    refundTime = refundResult.refundTime,
                    createdAt = TimeUtils.getCurrentTimeMillis(),
                    updatedAt = TimeUtils.getCurrentTimeMillis()
                )
                
                localDatabase.saveRefundRecord(refundRecord)
                
                // 6. 同步到云端
                scope.launch {
                    cloudDatabase.syncRefundRecord(refundRecord)
                }
                
                refundResult
            } catch (e: Exception) {
                RefundResult.Failure(
                    errorCode = "REFUND_ERROR",
                    errorMessage = e.message ?: "Refund failed"
                )
            }
        }
    }
    
    // 获取支付方式列表
    suspend fun getPaymentMethods(): List<PaymentMethod> {
        return withContext(Dispatchers.Default) {
            try {
                // 通过PaymentService获取支付方式列表
                val allMethods = paymentService.getPaymentMethods()
                
                // 过滤当前平台支持的支付方式
                allMethods.filter { method ->
                    method.platformSupport.contains(getCurrentPlatform())
                }
            } catch (e: Exception) {
                emptyList()
            }
        }
    }
    
    // ==================== 支付历史（SWR + Network-first；全平台共用 commonMain 逻辑） ====================

    /**
     * 仅读本地 SQLite（不发起网络）。用于 SWR 首屏：立即展示缓存，再在后台 [syncPaymentHistoryFromServer]。
     */
    suspend fun readCachedPaymentHistory(userId: String, limit: Int = 20): List<PaymentOrder> {
        return withContext(Dispatchers.Default) {
            try {
                localDatabase.getPaymentHistory(userId, limit)
            } catch (e: Exception) {
                Logger.error("[PaymentManager] readCachedPaymentHistory failed: ${e.message}")
                emptyList()
            }
        }
    }

    /**
     * 从服务端拉取支付历史并落库；成功则以服务端列表为准（含空列表）。
     * 失败时抛出异常，由调用方决定是否保留已展示的缓存（SWR）。
     */
    suspend fun syncPaymentHistoryFromServer(userId: String, limit: Int = 20): List<PaymentOrder> {
        return withContext(Dispatchers.Default) {
            val cloudHistory = paymentService.getPaymentHistory(userId, limit)
            cloudHistory.forEach { order ->
                localDatabase.savePaymentOrder(order)
            }
            Logger.debug(
                "[PaymentManager] syncPaymentHistoryFromServer: count=${cloudHistory.size} userId=$userId limit=$limit",
            )
            cloudHistory
        }
    }

    /**
     * 单次调用：网络优先，失败则回退缓存（与 [syncPaymentHistoryFromServer] + 本地回退等价）。
     * 适合不需要分帧更新 UI 的集成方；Walknote 支付记录页优先在 ViewModel 层做 SWR。
     */
    suspend fun getPaymentHistory(userId: String, limit: Int = 20): List<PaymentOrder> {
        return try {
            syncPaymentHistoryFromServer(userId, limit)
        } catch (e: Exception) {
            Logger.error("[PaymentManager] getPaymentHistory: sync failed, using cache: ${e.message}")
            readCachedPaymentHistory(userId, limit)
        }
    }
    
    // 处理支付回调
    suspend fun handlePaymentCallback(callbackData: String): Boolean {
        return withContext(Dispatchers.Default) {
            try {
                // 1. 通过PaymentService验证回调
                if (!paymentService.verifyPaymentCallback(callbackData)) {
                    return@withContext false
                }
                
                // 2. 解析回调数据
                val callback = parsePaymentCallback(callbackData)
                
                // 3. 更新订单状态
                updateOrderStatus(callback)
                
                // 4. 发送通知
                sendPaymentNotification(callback)
                
                true
            } catch (e: Exception) {
                false
            }
        }
    }
    
    // 获取当前平台
    private fun getCurrentPlatform(): Platform {
        // 这里需要根据实际平台返回
        return Platform.ANDROID // 默认值
    }
    
    // 解析支付回调（简化版）
    private fun parsePaymentCallback(callbackData: String): PaymentCallback {
        // 实际实现需要根据具体支付平台的回调格式
        return PaymentCallback(
            orderId = "",
            status = PaymentStatus.PENDING,
            message = ""
        )
    }
    
    // 更新订单状态
    private suspend fun updateOrderStatus(callback: PaymentCallback) {
        // 实现订单状态更新逻辑
    }
    
    // 发送支付通知
    private suspend fun sendPaymentNotification(callback: PaymentCallback) {
        // 实现支付通知逻辑
    }
    
    // 清理资源
    suspend fun cleanup() {
        platformAdapters.values.forEach { adapter ->
            adapter.cleanup()
        }
    }
}

// 支付回调数据
data class PaymentCallback(
    val orderId: String,
    val status: PaymentStatus,
    val message: String
)

// 注意：LocalDatabase和CloudDatabase接口已在SDK.kt中定义，包含支付相关方法

// 支付安全管理器接口
interface PaymentSecurityManager {
    suspend fun validatePaymentRequest(request: PaymentRequest): Boolean
    suspend fun validateRefundRequest(request: RefundRequest): Boolean
    suspend fun verifyCallbackSignature(callbackData: String): Boolean
}
