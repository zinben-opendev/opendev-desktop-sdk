package com.zinben.opendev.network

import io.ktor.client.HttpClient
import io.ktor.client.HttpClientConfig
import io.ktor.client.call.body
import io.ktor.client.network.sockets.ConnectTimeoutException
import io.ktor.client.plugins.ClientRequestException
import io.ktor.client.plugins.HttpRequestTimeoutException
import io.ktor.client.plugins.ServerResponseException
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.cookies.AcceptAllCookiesStorage
import io.ktor.client.plugins.cookies.HttpCookies
import io.ktor.client.plugins.logging.DEFAULT
import io.ktor.client.plugins.logging.LogLevel
import io.ktor.client.plugins.logging.Logger
import io.ktor.client.plugins.logging.Logging
import io.ktor.client.request.get
import io.ktor.client.request.post
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.json.Json

/**
 * 全局 SSL 证书配置
 * 可以通过设置此变量来配置全局的 SSL 证书验证行为
 * 注意：此配置在 URLSession 创建时生效，修改后需要重新创建 HttpClient
 */
var globalSSLCertificateConfig: SSLCertificateConfig? = null

/**
 * 默认 URLSession（使用系统默认 SSL 证书验证或全局 SSL 配置）
 */
val URLSession: HttpClient by lazy {
    createHttpClient(globalSSLCertificateConfig)
}

/**
 * 创建带 SSL 证书配置的 HttpClient
 *
 * @param sslConfig SSL 证书配置，如果为 null 则使用系统默认配置
 * @param clientConfigExtra 在默认插件（JSON/Cookies/Logging）之前执行，用于例如 [io.ktor.client.plugins.HttpTimeout]。
 * @return 配置好的 HttpClient 实例
 */
fun createHttpClient(
    sslConfig: SSLCertificateConfig? = null,
    clientConfigExtra: HttpClientConfig<*>.() -> Unit = {},
): HttpClient {
    val config = sslConfig ?: SSLCertificateConfig.DEFAULT
    
    // 调试日志：显示 SSL 配置
    Logger.DEFAULT.log("Creating HttpClient with SSL config: enableCustomCertificate=${config.enableCustomCertificate}, allowSelfSignedCertificates=${config.allowSelfSignedCertificates}, allowExpiredCertificates=${config.allowExpiredCertificates}")
    
    return createHttpClientWithEngine(config) {
        clientConfigExtra()
        install(ContentNegotiation) {
            json(Json {
                ignoreUnknownKeys = true
                encodeDefaults = true
                explicitNulls = false  // 不序列化 null 值，避免服务器端处理 null 时出错
            })
        }
        install(HttpCookies) {
            storage = AcceptAllCookiesStorage()
        }
        install(Logging) {
            logger = Logger.DEFAULT
            level = LogLevel.INFO
        }
        expectSuccess = true
    }
}

/**
 * 创建带 SSL 证书配置的 HttpClient（带引擎配置）
 * 使用 expect/actual 机制实现跨平台支持
 * 
 * @param config SSL 证书配置
 * @param block HttpClient 配置块
 * @return 配置好的 HttpClient 实例
 * 
 * 注意：不同平台的引擎配置方式不同：
 * - Android: 使用 OkHttp 引擎，通过 OkHttpClient 配置 SSL
 * - iOS: 使用 NSURLSession，通过 URLSessionDelegate 配置 SSL
 * - Desktop: 使用 Java 引擎，通过 SSLContext 配置 SSL
 * - WasmJS: 使用浏览器引擎，无法自定义 SSL 配置
 */
expect fun createHttpClientWithEngine(
    config: SSLCertificateConfig,
    block: HttpClientConfig<*>.() -> Unit
): HttpClient

// append try-catch
suspend fun <T> safeCall(
    client: HttpClient = URLSession,
    call: suspend HttpClient.() -> T
): Result<T> {
    return try {
        val result = call(client)
        Logger.DEFAULT.log("Request succeed: $result")
        Result(data = result)
    } catch (e: ConnectTimeoutException) {
        Logger.DEFAULT.log("Connection timed out: ${e.message}")
        Result(exception = e)
    } catch (e: HttpRequestTimeoutException) {
        Logger.DEFAULT.log("Request timed out: ${e.message}")
        Result(exception = e)
    } catch (e: ClientRequestException) {
        // 4xx responses
        Logger.DEFAULT.log("Client request error: ${e.response.status.description}")
        Result(exception = e)
    } catch (e: ServerResponseException) {
        // 5xx responses
        Logger.DEFAULT.log("Server response error: ${e.response.status.description}")
        Result(exception = e)
    } catch (e: Exception) {
        Logger.DEFAULT.log("An unexpected error occurred: ${e.message}")
        Result(exception = e)
    }
}

suspend inline fun <reified T> GET(
    source: String
): Result<T> =
    safeCall {
        get(source).body<T>()
    }

suspend inline fun <reified T> POST(
    source: String
): Result<T> =
    safeCall {
        post(source).body<T>()
    }

data class Result<T>(
    val data: T? = null,
    val exception: Throwable? = null
)

fun <T> Result<T>.isSucceed() = data != null

fun <T> Result<T>.isFailed() = exception != null

inline fun <T> Result<T>.dispose(
    onSucceed: (T) -> Unit,
    onFailed: (Throwable) -> Unit
) {
    if (data != null) {
        onSucceed.invoke(data)
    } else {
        onFailed.invoke(exception ?: RuntimeException("Unknown Exception"))
    }
}

inline fun <T> Result<T>.disposeSucceed(
    onSucceed: (T) -> Unit,
) = this.apply {
    if (data != null) {
        onSucceed.invoke(data)
    }
}

inline fun <T> Result<T>.disposeFailed(
    onFailed: (Throwable) -> Unit,
) = this.apply {
    if (exception != null) {
        onFailed.invoke(exception)
    }
}