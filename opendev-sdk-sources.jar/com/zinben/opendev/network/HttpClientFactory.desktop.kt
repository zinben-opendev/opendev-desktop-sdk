package com.zinben.opendev.network

import io.ktor.client.HttpClient
import io.ktor.client.HttpClientConfig
import io.ktor.client.engine.cio.CIO
import io.ktor.client.engine.cio.CIOEngineConfig
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import java.security.cert.X509Certificate

/**
 * Desktop (JVM) 平台 HttpClient 创建（带 SSL 证书配置）
 * 
 * Desktop 平台使用 CIO 引擎
 */
actual fun createHttpClientWithEngine(
    config: SSLCertificateConfig,
    block: HttpClientConfig<*>.() -> Unit
): HttpClient {
    if (!config.enableCustomCertificate) {
        // 使用默认配置
        return HttpClient(CIO, block)
    }
    
    // 创建自定义 TrustManager
    val trustManager = object : X509TrustManager {
        override fun checkClientTrusted(
            chain: Array<out X509Certificate>?,
            authType: String?
        ) {
            // 客户端证书验证（通常不需要）
        }
        
        override fun checkServerTrusted(
            chain: Array<out X509Certificate>?,
            authType: String?
        ) {
            if (chain == null || chain.isEmpty()) {
                throw java.security.cert.CertificateException("No server certificates")
            }
            
            // 检查证书是否过期
            if (!config.allowExpiredCertificates) {
                chain.forEach { cert ->
                    try {
                        cert.checkValidity()
                    } catch (e: java.security.cert.CertificateExpiredException) {
                        if (!config.allowExpiredCertificates) {
                            throw e
                        }
                    } catch (e: java.security.cert.CertificateNotYetValidException) {
                        throw e
                    }
                }
            }
            
            // 证书固定（Certificate Pinning）验证
            if (config.pinnedCertificates.isNotEmpty()) {
                // TODO: 实现证书固定验证
                // 需要计算证书的 SHA-256 哈希并与配置的哈希比较
            }
        }
        
        override fun getAcceptedIssuers(): Array<X509Certificate> {
            return emptyArray()
        }
    }
    
    // 返回配置好的 HttpClient
    // CIO 引擎支持在 https 配置块中设置 trustManager
    return HttpClient(CIO) {
        engine {
            https {
                // 设置自定义的 TrustManager
                // 注意：CIO 引擎的 trustManager 属性需要是 X509TrustManager 类型
                this.trustManager = trustManager
            }
        }
        // 应用其他配置
        block()
    }
}

