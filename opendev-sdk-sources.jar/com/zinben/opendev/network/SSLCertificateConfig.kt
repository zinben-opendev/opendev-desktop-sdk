package com.zinben.opendev.network

/**
 * SSL 证书配置
 * 
 * 用于配置 HTTPS 请求的 SSL 证书验证行为
 */
data class SSLCertificateConfig(
    /**
     * 是否启用自定义 SSL 证书验证
     * 默认 false，使用系统默认的证书验证
     */
    val enableCustomCertificate: Boolean = false,
    
    /**
     * 是否允许自签名证书
     * 仅在 enableCustomCertificate = true 时生效
     * 警告：生产环境应设置为 false
     */
    val allowSelfSignedCertificates: Boolean = false,
    
    /**
     * 是否允许过期证书
     * 仅在 enableCustomCertificate = true 时生效
     * 警告：生产环境应设置为 false
     */
    val allowExpiredCertificates: Boolean = false,
    
    /**
     * 证书固定（Certificate Pinning）
     * 仅信任指定的证书或公钥哈希
     * 格式：["sha256/证书指纹1", "sha256/证书指纹2"]
     * 示例：["sha256/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="]
     */
    val pinnedCertificates: List<String> = emptyList(),
    
    /**
     * 信任的主机列表
     * 如果启用自定义证书验证，仅对这些主机进行自定义验证
     * 其他主机使用系统默认验证
     * 空列表表示对所有主机生效
     */
    val trustedHosts: List<String> = emptyList()
) {
    companion object {
        /**
         * 默认配置：使用系统默认证书验证
         */
        val DEFAULT = SSLCertificateConfig(
            enableCustomCertificate = false
        )
        
        /**
         * 开发环境配置：允许自签名证书（仅用于开发测试）
         */
        val DEVELOPMENT = SSLCertificateConfig(
            enableCustomCertificate = true,
            allowSelfSignedCertificates = true,
            allowExpiredCertificates = true
        )
        
        /**
         * 生产环境配置：严格证书验证
         */
        val PRODUCTION = SSLCertificateConfig(
            enableCustomCertificate = false
        )
    }
}

/**
 * SSL 证书验证结果
 */
sealed class SSLCertificateValidationResult {
    /**
     * 验证通过
     */
    object Success : SSLCertificateValidationResult()
    
    /**
     * 验证失败
     */
    data class Failure(
        val reason: String,
        val exception: Throwable? = null
    ) : SSLCertificateValidationResult()
}

/**
 * SSL 证书验证器接口
 * 使用 expect/actual 机制实现跨平台支持
 */
expect class SSLCertificateValidator {
    /**
     * 验证 SSL 证书
     * 
     * @param host 主机名
     * @param port 端口号
     * @param config SSL 证书配置
     * @return 验证结果
     */
    suspend fun validateCertificate(
        host: String,
        port: Int,
        config: SSLCertificateConfig
    ): SSLCertificateValidationResult
    
    /**
     * 创建平台特定的 HttpClient 引擎配置
     * 用于配置 Ktor HttpClient 的 SSL 证书验证
     */
    fun configureHttpClientEngine(
        config: SSLCertificateConfig
    ): Any? // 返回平台特定的引擎配置对象
}

