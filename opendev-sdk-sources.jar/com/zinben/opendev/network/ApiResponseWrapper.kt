package com.zinben.opendev.network

import kotlinx.serialization.Serializable

/**
 * Unified API response envelope matching the backend contract: { "code": 0, "msg": "", "data": {} }
 */
@Serializable
data class ApiResponseWrapper<T>(
    val code: Int,
    val msg: String = "",
    val data: T? = null
)
