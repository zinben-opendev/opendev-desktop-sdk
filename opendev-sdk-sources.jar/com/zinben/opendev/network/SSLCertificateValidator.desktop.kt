package com.zinben.opendev.network

import io.ktor.client.engine.cio.CIO
import io.ktor.client.engine.cio.CIOEngineConfig

/**
 * Desktop (JVM) 平台 SSL 证书验证器实现
 * 
 * Desktop 平台使用 CIO 引擎
 */
actual class SSLCertificateValidator {
    
    actual suspend fun validateCertificate(
        host: String,
        port: Int,
        config: SSLCertificateConfig
    ): SSLCertificateValidationResult {
        // Desktop 平台的证书验证由 CIO 引擎处理
        // 这里返回成功，实际验证在 configureHttpClientEngine 中配置
        return SSLCertificateValidationResult.Success
    }
    
    actual fun configureHttpClientEngine(
        config: SSLCertificateConfig
    ): Any? {
        if (!config.enableCustomCertificate) {
            // 使用默认配置
            return null
        }
        
        // 返回 CIO 引擎配置
        return CIOEngineConfig().apply {
            // 注意：Ktor CIO 引擎的 SSL 配置需要通过 SSLContext 来实现
            // 这里返回配置对象，实际应用需要在 URLSession 中处理
        }
    }
}

