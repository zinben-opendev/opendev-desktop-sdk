package com.zinben.opendev

/**
 * 平台信息接口
 * 用于获取当前运行平台的基本信息
 * 
 * 注意：此接口命名为 PlatformInfo 以避免与 models.Platform 枚举冲突
 */
interface PlatformInfo {
    val name: String
}

expect fun getPlatform(): PlatformInfo