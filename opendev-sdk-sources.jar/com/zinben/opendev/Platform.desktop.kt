package com.zinben.opendev

class JVMPlatform : PlatformInfo {
    override val name: String = "Java ${System.getProperty("java.version")}"
}

actual fun getPlatform(): PlatformInfo = JVMPlatform()