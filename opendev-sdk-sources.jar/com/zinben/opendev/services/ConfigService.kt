package com.zinben.opendev.services

import com.zinben.opendev.logger.Logger
import com.zinben.opendev.models.ConfigDownloadRequest
import com.zinben.opendev.models.ConfigEnvironment
import com.zinben.opendev.models.ConfigPlatform
import com.zinben.opendev.models.SDKConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * 统一配置服务
 * 
 * 封装配置的加载、下载、更新逻辑，提供统一的配置管理接口。
 * 
 * 配置加载优先级：
 * 1. 优先从本地数据目录读取（已下载的更新配置）
 * 2. 如果本地不存在，从应用资源读取（预置配置）
 * 3. 如果都不存在，从 CDN 同步下载
 * 4. 异步检查并更新配置（不阻塞初始化）
 * 
 * @since 1.6.0
 */
class ConfigService(
    private val scope: CoroutineScope
) {
    
    private val downloadService = ConfigDownloadService(encryptionKey = null)
    
    /**
     * 加载配置
     * 
     * @param platform 平台标识
     * @param environment 环境
     * @param channelKey 渠道标识（可选）
     * @param cdnBaseUrl CDN 基础 URL（可选，用于下载和更新）
     * @param cdnToken CDN 访问令牌（可选）
     * @return 配置数据，如果加载失败返回 null
     */
    suspend fun loadConfig(
        platform: ConfigPlatform,
        environment: ConfigEnvironment,
        channelKey: String? = null,
        cdnBaseUrl: String? = null,
        cdnToken: String? = null
    ): SDKConfig? {
        Logger.debug("[ConfigService] loadConfig: platform=${platform.value}, env=${environment.name}, channel=$channelKey")
        
        // 1. 尝试从本地读取配置
        val localConfig = tryLoadLocalConfig(platform, environment, channelKey)
        
        if (localConfig != null) {
            // 本地配置存在，异步检查更新
            if (cdnBaseUrl != null) {
                checkAndUpdateConfigAsync(
                    localConfig = localConfig,
                    cdnBaseUrl = cdnBaseUrl,
                    cdnToken = cdnToken,
                    platform = platform,
                    environment = environment,
                    channelKey = channelKey
                )
            }
            return localConfig
        }
        
        // 2. 本地配置不存在，尝试从 CDN 下载
        if (cdnBaseUrl != null) {
            return downloadConfigSync(
                cdnBaseUrl = cdnBaseUrl,
                cdnToken = cdnToken,
                platform = platform,
                environment = environment,
                channelKey = channelKey
            )
        }
        
        Logger.debug("[ConfigService] No config available (local not found, CDN not configured)")
        return null
    }
    
    /**
     * 从本地文件读取配置
     * 
     * @param platform 平台标识
     * @param environment 环境
     * @param channelKey 渠道标识（可选）
     * @param filePath 自定义文件路径（可选）
     * @param encryptionKey 加密密钥（可选，默认使用 SDK 内部密钥）
     * @return 配置数据
     */
    suspend fun readLocalConfig(
        platform: ConfigPlatform,
        environment: ConfigEnvironment,
        channelKey: String? = null,
        filePath: String? = null,
        encryptionKey: String? = null
    ): SDKConfig {
        return LocalConfigReadService.readConfigFromFile(
            platform = platform,
            environment = environment,
            channelKey = channelKey,
            filePath = filePath,
            encryptionKey = encryptionKey
        )
    }
    
    /**
     * 从 CDN 下载配置
     * 
     * @param baseUrl CDN 基础 URL
     * @param token 访问令牌
     * @param environment 环境
     * @param platform 平台标识
     * @param channelKey 渠道标识（可选）
     * @param onSuccess 成功回调
     * @param onError 错误回调
     */
    suspend fun downloadConfig(
        baseUrl: String,
        token: String,
        environment: ConfigEnvironment,
        platform: ConfigPlatform,
        channelKey: String? = null,
        onSuccess: (SDKConfig) -> Unit,
        onError: (Throwable) -> Unit
    ) {
        val request = ConfigDownloadRequest(
            baseUrl = baseUrl,
            token = token,
            environment = environment,
            platform = platform,
            channelKey = channelKey,
            onSuccess = { config, _ -> onSuccess(config) },
            onError = onError
        )
        downloadService.downloadConfig(request)
    }
    
    /**
     * 尝试从本地读取配置（不抛异常）
     */
    private suspend fun tryLoadLocalConfig(
        platform: ConfigPlatform,
        environment: ConfigEnvironment,
        channelKey: String?
    ): SDKConfig? {
        return try {
            Logger.debug("[ConfigService] Attempting to read config from local file...")
            LocalConfigReadService.readConfigFromFile(
                platform = platform,
                environment = environment,
                channelKey = channelKey,
                filePath = null,
                encryptionKey = null
            ).also {
                Logger.debug("[ConfigService] Successfully read local config: appId=${it.appId}, generatedAt=${it.generatedAt}")
            }
        } catch (e: Exception) {
            Logger.debug("[ConfigService] Failed to read local config: ${e.message}")
            null
        }
    }
    
    /**
     * 异步检查并更新配置文件
     */
    private fun checkAndUpdateConfigAsync(
        localConfig: SDKConfig,
        cdnBaseUrl: String,
        cdnToken: String?,
        platform: ConfigPlatform,
        environment: ConfigEnvironment,
        channelKey: String?
    ) {
        scope.launch(Dispatchers.Default) {
            try {
                Logger.debug("[ConfigService] Checking config update asynchronously (local generatedAt=${localConfig.generatedAt})...")
                
                var downloadedConfig: SDKConfig? = null
                var encryptedHexData: String? = null
                var downloadError: Throwable? = null
                
                val downloadRequest = ConfigDownloadRequest(
                    baseUrl = cdnBaseUrl,
                    token = cdnToken ?: "",
                    environment = environment,
                    platform = platform,
                    channelKey = channelKey,
                    onSuccess = { config, encryptedHex ->
                        downloadedConfig = config
                        encryptedHexData = encryptedHex
                    },
                    onError = { error -> downloadError = error }
                )
                
                downloadService.downloadConfig(downloadRequest)
                
                if (downloadedConfig != null && encryptedHexData != null) {
                    val localGeneratedAt = localConfig.generatedAt
                    val remoteGeneratedAt = downloadedConfig!!.generatedAt
                    
                    if (isConfigNewer(remoteGeneratedAt, localGeneratedAt)) {
                        Logger.debug("[ConfigService] Remote config is newer (local=$localGeneratedAt, remote=$remoteGeneratedAt), saving...")
                        try {
                            LocalConfigReadService.saveConfigToDataDirectory(
                                platform = platform,
                                environment = environment,
                                channelKey = channelKey,
                                encryptedHexString = encryptedHexData!!
                            )
                            Logger.debug("[ConfigService] Config updated successfully, will take effect on next app launch")
                        } catch (e: Exception) {
                            Logger.error("[ConfigService] Failed to save updated config: ${e.message}")
                        }
                    } else {
                        Logger.debug("[ConfigService] Local config is up to date")
                    }
                } else {
                    Logger.debug("[ConfigService] Config update check failed: ${downloadError?.message}")
                }
            } catch (e: Exception) {
                Logger.error("[ConfigService] Config update check error: ${e.message}")
            }
        }
    }
    
    /**
     * 同步从 CDN 下载配置并保存
     */
    private suspend fun downloadConfigSync(
        cdnBaseUrl: String,
        cdnToken: String?,
        platform: ConfigPlatform,
        environment: ConfigEnvironment,
        channelKey: String?
    ): SDKConfig? {
        return try {
            Logger.debug("[ConfigService] Downloading config from CDN synchronously...")
            
            var downloadedConfig: SDKConfig? = null
            var encryptedHexData: String? = null
            var downloadError: Throwable? = null
            
            val downloadRequest = ConfigDownloadRequest(
                baseUrl = cdnBaseUrl,
                token = cdnToken ?: "",
                environment = environment,
                platform = platform,
                channelKey = channelKey,
                onSuccess = { config, encryptedHex ->
                    downloadedConfig = config
                    encryptedHexData = encryptedHex
                },
                onError = { error -> downloadError = error }
            )
            
            downloadService.downloadConfig(downloadRequest)
            
            if (downloadedConfig != null && encryptedHexData != null) {
                Logger.debug("[ConfigService] Successfully downloaded config: appId=${downloadedConfig!!.appId}")
                
                // 保存到数据目录
                try {
                    LocalConfigReadService.saveConfigToDataDirectory(
                        platform = platform,
                        environment = environment,
                        channelKey = channelKey,
                        encryptedHexString = encryptedHexData!!
                    )
                    Logger.debug("[ConfigService] Config saved to data directory")
                } catch (e: Exception) {
                    Logger.error("[ConfigService] Failed to save config: ${e.message}")
                }
                
                downloadedConfig
            } else {
                throw downloadError ?: Exception("Download failed with unknown error")
            }
        } catch (e: Exception) {
            Logger.error("[ConfigService] Failed to download config from CDN: ${e.message}")
            null
        }
    }
    
    /**
     * 比较两个配置的 generatedAt 时间戳
     * ISO 8601 格式的字符串可以直接进行字符串比较
     */
    private fun isConfigNewer(remoteGeneratedAt: String?, localGeneratedAt: String?): Boolean {
        if (remoteGeneratedAt.isNullOrBlank()) return false
        if (localGeneratedAt.isNullOrBlank()) return true
        return remoteGeneratedAt > localGeneratedAt
    }
}

