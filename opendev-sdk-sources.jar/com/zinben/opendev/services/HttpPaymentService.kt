package com.zinben.opendev.services

import io.ktor.client.call.body
import io.ktor.client.request.get
import io.ktor.client.request.headers
import io.ktor.client.request.parameter
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.contentType
import kotlinx.serialization.Serializable
import com.zinben.opendev.logger.Logger
import com.zinben.opendev.models.SDKError
import com.zinben.opendev.network.URLSession
import com.zinben.opendev.security.PaymentSecurityManagerImpl
import com.zinben.opendev.security.PaymentSignature

@Serializable
data class PaymentApiResponse<T>(
    val code: Int = -1,
    val msg: String? = null,
    val data: T? = null
)

@Serializable
data class PaymentProductsWrapper(
    val products: List<PaymentProductDTO>
)

@Serializable
data class PaymentProductDTO(
    val productId: String,
    val name: String,
    val description: String? = null,
    val type: String,
    val source: String? = null,
    val price: PaymentPriceDTO,
    val subscriptionPeriod: String? = null,
    val subscriptionTrialDays: Int = 0,
    val platformProductIds: Map<String, String>? = null
)

@Serializable
data class PaymentPriceDTO(
    val amount: Double,
    val currency: String
)

@Serializable
data class CreateOrderResponse(
    val orderId: String,
    val amount: Double,
    val currency: String,
    val platform: String,
    val expiresAt: Long? = null,
    val status: String,
    val paymentData: Map<String, String>? = null
)

@Serializable
data class VerifyPaymentResponse(
    val orderId: String,
    val status: String,
    val transactionId: String? = null,
    val verifiedAt: Long? = null
)

@Serializable
data class FinishOrderResponse(
    val orderId: String,
    val acknowledged: Boolean,
    val acknowledgedAt: Long? = null
)

@Serializable
data class OrderStatusResponse(
    val orderId: String,
    val status: String,
    val amount: Double? = null,
    val currency: String? = null,
    val platform: String? = null,
    val productId: String? = null,
    val createdAt: Long? = null,
    val expiresAt: Long? = null,
    val completedAt: Long? = null,
    val transaction: OrderTransactionInfo? = null
)

/**
 * `GET /v1/payment/order/status/:orderId` — **无需登录**，与收银台网页轮询一致（FastSpring 等）。
 * 用于 Desktop/Web 浏览器支付后的轮询；避免已登录用户与 checkout 订单 userId 不一致时
 * `GET /v1/payment/status/:orderId` 返回 403「Order does not belong to this user」。
 */
@Serializable
data class PublicOrderStatusResponse(
    val orderId: String,
    val status: String,
    val platform: String? = null,
    val completed: Boolean = false,
)

@Serializable
data class OrderTransactionInfo(
    val transactionId: String? = null,
    val verificationStatus: String? = null,
    val verifiedAt: Long? = null,
    val isAcknowledged: Boolean = false
)

@Serializable
data class PaymentHistoryWrapper(
    val orders: List<PaymentOrderDTO>,
    val total: Int = 0
)

@Serializable
data class PaymentOrderDTO(
    val orderId: String,
    val appId: String? = null,
    val productId: String,
    val amount: Double,
    val currency: String,
    val platform: String,
    val status: String,
    val createdAt: Long,
    val completedAt: Long? = null,
    val refund: PaymentRefundInfo? = null
)

@Serializable
data class PaymentRefundInfo(
    val refundId: String? = null,
    val amount: Double? = null,
    val status: String? = null
)

@Serializable
data class PaymentConfigResponse(
    val stripePublishableKey: String? = null,
    val fastspringStorefront: String? = null,
    val fastspringStorefrontPath: String? = null,
    val supportedMethods: List<String>? = null
)

@Serializable
data class CheckoutInitResponse(
    val orderId: String,
    val checkoutUrl: String,
    val order: CheckoutOrderInfo? = null
)

@Serializable
data class CheckoutOrderInfo(
    val orderId: String? = null,
    val productName: String? = null,
    val amount: Double? = null,
    val currency: String? = null,
    val expiresAt: Long? = null
)

class HttpPaymentService(
    private val baseUrl: String,
    private val apiVersion: String = "v1",
    private val appId: String,
    private val tokenProvider: suspend () -> String?,
    private val securityManager: PaymentSecurityManagerImpl? = null,
    private val userIdProvider: suspend () -> String? = { null }
) {

    companion object {
        private const val DEFAULT_BASE_URL = "http://localhost:3000"
    }

    private val resolvedBaseUrl = baseUrl.takeIf { it.isNotBlank() }?.trimEnd('/') ?: DEFAULT_BASE_URL
    private val resolvedApiVersion = apiVersion.trim().trimStart('/').ifBlank { "v1" }

    private fun endpoint(path: String): String {
        return "$resolvedBaseUrl/$resolvedApiVersion/payment/${path.trimStart('/')}"
    }

    suspend fun fetchProducts(): List<PaymentProductDTO> {
        val wrapper: PaymentProductsWrapper = getRequest("products", mapOf("appId" to appId))
        return wrapper.products
    }

    suspend fun createOrder(productId: String, platform: String): CreateOrderResponse =
        postRequestSigned(
            "orders",
            CreateOrderRequestBody(
                appId = appId,
                productId = productId,
                platform = platform
            ),
            orderId = "",
            productId = productId
        )

    suspend fun verifyPayment(
        orderId: String,
        platform: String,
        receiptData: Map<String, String>
    ): VerifyPaymentResponse =
        postRequestSigned(
            "verify",
            VerifyPaymentRequestBody(
                orderId = orderId,
                platform = platform,
                receiptData = receiptData
            ),
            orderId = orderId,
            productId = receiptData["productId"] ?: ""
        )

    suspend fun finishOrder(orderId: String, transactionId: String?): FinishOrderResponse =
        postRequestSigned(
            "finish",
            FinishOrderRequestBody(
                orderId = orderId,
                transactionId = transactionId
            ),
            orderId = orderId,
            productId = ""
        )

    suspend fun queryOrderStatus(orderId: String): OrderStatusResponse =
        getRequestAuthorized("status/$orderId")

    suspend fun queryPublicOrderStatus(orderId: String): PublicOrderStatusResponse =
        getRequest("order/status/$orderId")

    suspend fun getPaymentHistory(limit: Int = 20): List<PaymentOrderDTO> {
        val wrapper: PaymentHistoryWrapper = getRequestAuthorized(
            "history",
            mapOf(
                "appId" to appId,
                "limit" to limit.toString()
            )
        )
        return wrapper.orders
    }

    suspend fun getPaymentConfig(): PaymentConfigResponse =
        getRequest("config", mapOf("appId" to appId))

    suspend fun initCheckout(
        productId: String,
        successUrl: String?,
        cancelUrl: String?
    ): CheckoutInitResponse =
        postRequestOptionalAuth(
            "checkout/init",
            CheckoutInitRequestBody(
                appId = appId,
                productId = productId,
                metadata = null,
                successUrl = successUrl,
                cancelUrl = cancelUrl
            )
        )

    private fun <T> unwrapPaymentResponse(wrapper: PaymentApiResponse<T>, op: String): T {
        if (wrapper.code != 0 || wrapper.data == null) {
            Logger.error("[HttpPaymentService] $op failed: code=${wrapper.code} msg=${wrapper.msg}")
            throw SDKError.Network.ServerError(wrapper.code, wrapper.msg ?: "Unknown error")
        }
        return wrapper.data
    }

    private suspend inline fun <reified T> getRequest(
        path: String,
        params: Map<String, String> = emptyMap()
    ): T {
        val response = URLSession.get(endpoint(path)) {
            params.forEach { (key, value) -> parameter(key, value) }
        }
        val wrapper = response.body<PaymentApiResponse<T>>()
        return unwrapPaymentResponse(wrapper, "GET $path")
    }

    private suspend inline fun <reified T> getRequestAuthorized(
        path: String,
        params: Map<String, String> = emptyMap()
    ): T {
        val token = tokenProvider() ?: throw SDKError.Auth.NotLoggedIn()
        val response = URLSession.get(endpoint(path)) {
            params.forEach { (key, value) -> parameter(key, value) }
            headers { append(HttpHeaders.Authorization, "Bearer $token") }
        }
        val wrapper = response.body<PaymentApiResponse<T>>()
        return unwrapPaymentResponse(wrapper, "GET $path (auth)")
    }

    private suspend inline fun <reified R, reified T> postRequest(path: String, body: R): T {
        val token = tokenProvider() ?: throw SDKError.Auth.NotLoggedIn()
        val response = URLSession.post(endpoint(path)) {
            contentType(ContentType.Application.Json)
            headers { append(HttpHeaders.Authorization, "Bearer $token") }
            setBody(body)
        }
        val wrapper = response.body<PaymentApiResponse<T>>()
        return unwrapPaymentResponse(wrapper, "POST $path")
    }

    private suspend inline fun <reified R, reified T> postRequestSigned(
        path: String,
        body: R,
        orderId: String,
        productId: String
    ): T {
        val token = tokenProvider() ?: throw SDKError.Auth.NotLoggedIn()
        val userId = userIdProvider() ?: ""
        val sig = securityManager?.signPaymentRequest(userId, orderId, productId)

        val response = URLSession.post(endpoint(path)) {
            contentType(ContentType.Application.Json)
            headers {
                append(HttpHeaders.Authorization, "Bearer $token")
                if (sig != null) {
                    append(PaymentSignature.HEADER_SIGNATURE, sig.signature)
                    append(PaymentSignature.HEADER_TIMESTAMP, sig.timestamp.toString())
                    append(PaymentSignature.HEADER_NONCE, sig.nonce)
                }
            }
            setBody(body)
        }
        val wrapper = response.body<PaymentApiResponse<T>>()
        return unwrapPaymentResponse(wrapper, "POST $path (signed)")
    }

    private suspend inline fun <reified R, reified T> postRequestOptionalAuth(path: String, body: R): T {
        val token = tokenProvider()
        val response = URLSession.post(endpoint(path)) {
            contentType(ContentType.Application.Json)
            if (token != null) {
                headers { append(HttpHeaders.Authorization, "Bearer $token") }
            }
            setBody(body)
        }
        val wrapper = response.body<PaymentApiResponse<T>>()
        return unwrapPaymentResponse(wrapper, "POST $path (optional auth)")
    }
}

@Serializable
private data class CreateOrderRequestBody(
    val appId: String,
    val productId: String,
    val platform: String
)

@Serializable
private data class VerifyPaymentRequestBody(
    val orderId: String,
    val platform: String,
    val receiptData: Map<String, String>
)

@Serializable
private data class FinishOrderRequestBody(
    val orderId: String,
    val transactionId: String? = null
)

@Serializable
private data class CheckoutInitRequestBody(
    val appId: String,
    val productId: String,
    val metadata: Map<String, String>? = null,
    val successUrl: String? = null,
    val cancelUrl: String? = null
)
