package com.zinben.opendev.services

import com.zinben.opendev.logger.Logger
import java.io.File
import java.io.InputStream

/**
 * Desktop平台本地配置文件读取实现
 * 
 * 优先级：
 * 1. 如果路径是绝对路径（以 / 开头或包含 :），从文件系统读取
 * 2. 否则从应用资源目录读取（应用安装后的资源路径）
 */
internal actual suspend fun readLocalConfigFile(filePath: String): ByteArray {
    return try {
        Logger.debug("[LocalConfigReadService.Desktop] Reading file/resource: $filePath")
        
        // 判断是文件系统路径还是资源路径
        val isAbsolutePath = filePath.startsWith("/") || filePath.contains(":")
        
        if (isAbsolutePath) {
            // 从文件系统读取（自定义路径）
            val file = File(filePath)
            if (!file.exists()) {
                throw java.io.FileNotFoundException("Config file not found: $filePath")
            }
            if (!file.canRead()) {
                throw SecurityException("Cannot read config file: $filePath")
            }
            file.readBytes()
        } else {
            // 从应用资源目录读取（应用安装后的资源路径）
            // 使用线程上下文类加载器从资源目录读取（资源文件在 composeApp 模块）
            val resourcePath = "/$filePath"
            
            // 优先使用线程上下文类加载器（通常是应用主类的类加载器）
            val classLoader = Thread.currentThread().contextClassLoader
                ?: LocalConfigReadService::class.java.classLoader
                ?: ClassLoader.getSystemClassLoader()
            
            val inputStream: InputStream? = classLoader.getResourceAsStream(resourcePath)
            
            if (inputStream == null) {
                // 如果找不到，尝试使用当前类的类加载器（fallback）
                val fallbackStream = LocalConfigReadService::class.java.getResourceAsStream(resourcePath)
                if (fallbackStream == null) {
                    Logger.error("[LocalConfigReadService.Desktop] Config resource not found: $filePath")
                    Logger.error("[LocalConfigReadService.Desktop] Searched path: $resourcePath")
                    Logger.error("[LocalConfigReadService.Desktop] Make sure the file is in composeApp/src/commonMain/resources/")
                    throw java.io.FileNotFoundException(
                        "Config resource not found: $filePath. " +
                        "Make sure the file is in composeApp/src/commonMain/resources/ and is included in the build."
                    )
                }
                fallbackStream.use { it.readBytes() }
            } else {
                inputStream.use { it.readBytes() }
            }
        }
    } catch (e: Exception) {
        Logger.error("[LocalConfigReadService.Desktop] Failed to read file/resource: ${e.message}")
        throw e
    }
}

/**
 * Desktop平台本地配置文件写入实现
 * 将配置文件写入到应用数据目录
 */
internal actual suspend fun writeLocalConfigFile(fileName: String, data: ByteArray) {
    try {
        Logger.debug("[LocalConfigReadService.Desktop] Writing config file: $fileName, size: ${data.size} bytes")
        
        val home = System.getProperty("user.home")
        val configDir = File(home, ".walknote/config")
        if (!configDir.exists()) {
            configDir.mkdirs()
        }
        
        val file = File(configDir, fileName)
        file.writeBytes(data)
        
        Logger.debug("[LocalConfigReadService.Desktop] Config file written successfully: ${file.absolutePath}")
    } catch (e: Exception) {
        Logger.error("[LocalConfigReadService.Desktop] Failed to write config file: ${e.message}")
        throw e
    }
}

/**
 * Desktop平台获取配置文件数据目录
 */
internal actual fun getConfigDataDirectory(): String {
    val home = System.getProperty("user.home")
    val configDir = File(home, ".walknote/config")
    if (!configDir.exists()) {
        configDir.mkdirs()
    }
    return configDir.absolutePath
}

