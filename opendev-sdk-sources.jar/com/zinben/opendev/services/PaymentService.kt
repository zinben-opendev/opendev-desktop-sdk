package com.zinben.opendev.services

import com.zinben.opendev.models.*

// 支付服务接口
interface PaymentService {
    // 创建支付订单
    suspend fun createPaymentOrder(request: CreatePaymentRequest): PaymentOrder
    
    // 执行支付
    suspend fun executePayment(paymentRequest: PaymentRequest): PaymentResult
    
    // 查询支付状态
    suspend fun queryPaymentStatus(orderId: String): PaymentStatus
    
    // 申请退款
    suspend fun requestRefund(refundRequest: RefundRequest): RefundResult
    
    // 查询退款状态
    suspend fun queryRefundStatus(refundId: String): PaymentStatus
    
    // 获取支付方式列表
    suspend fun getPaymentMethods(): List<PaymentMethod>
    
    // 验证支付回调
    suspend fun verifyPaymentCallback(callbackData: String): Boolean
    
    // 获取支付订单历史
    suspend fun getPaymentHistory(userId: String, limit: Int = 20): List<PaymentOrder>
    
    // 取消支付订单
    suspend fun cancelPaymentOrder(orderId: String): Boolean
}

