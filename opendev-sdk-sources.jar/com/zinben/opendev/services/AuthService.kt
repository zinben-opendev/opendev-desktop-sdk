package com.zinben.opendev.services

import com.zinben.opendev.auth.AuthCredential
import com.zinben.opendev.auth.ProviderId
import com.zinben.opendev.models.AuthResult
import com.zinben.opendev.models.BoundAccountInfo
import com.zinben.opendev.models.ChannelInfo
import com.zinben.opendev.models.OAuthConfigResponse
import com.zinben.opendev.models.AuthPayloadResponse
import com.zinben.opendev.models.OtpSendResult
import com.zinben.opendev.models.OtpTargetType
import com.zinben.opendev.models.OtpVerifyResult
import com.zinben.opendev.models.PlatformAuthResult
import com.zinben.opendev.models.PlatformUserInfo
import com.zinben.opendev.models.ThirdPartyProvider
import com.zinben.opendev.models.User

/**
 * HTTP-only authentication service interface.
 *
 * All methods are pure network calls — no local caching or state.
 * Caching and session management belong to [com.zinben.opendev.managers.AuthManager].
 */
interface AuthService {
    suspend fun guestLogin(): AuthResult

    suspend fun loginWithCredential(
        credential: AuthCredential,
        targetUserId: String? = null
    ): AuthResult = thirdPartyLogin(
        provider = ProviderId.toThirdPartyProvider(credential.providerId) ?: ThirdPartyProvider.GOOGLE,
        platformUserInfo = PlatformUserInfo(
            providerUserId = credential.providerUserId,
            username = credential.displayName,
            email = credential.email,
            avatar = credential.avatarUrl,
            provider = ProviderId.toThirdPartyProvider(credential.providerId) ?: ThirdPartyProvider.GOOGLE
        ),
        accessToken = credential.token,
        targetUserId = targetUserId
    )

    suspend fun thirdPartyLogin(
        provider: ThirdPartyProvider,
        platformUserInfo: PlatformUserInfo,
        accessToken: String? = null,
        targetUserId: String? = null
    ): AuthResult

    suspend fun bindAccount(
        provider: ThirdPartyProvider,
        authToken: String,
        authPayload: PlatformAuthResult.Success? = null
    ): AuthResult

    suspend fun unbindAccount(
        provider: ThirdPartyProvider,
        authToken: String,
        boundAccount: BoundAccountInfo? = null
    ): AuthResult

    suspend fun bindOtpAccount(
        targetType: OtpTargetType,
        target: String,
        authToken: String
    ): AuthResult

    suspend fun unbindOtpAccount(
        targetType: OtpTargetType,
        target: String,
        authToken: String
    ): AuthResult

    suspend fun logout(authToken: String?): AuthResult

    suspend fun refreshToken(authToken: String): AuthResult

    suspend fun updateUserInfo(user: User, authToken: String? = null): AuthResult

    suspend fun uploadAvatar(imageBytes: ByteArray, fileName: String, mimeType: String, authToken: String): kotlin.Result<String>

    suspend fun checkLoginStatus(token: String): Boolean

    suspend fun getOAuthConfig(appId: String, channelKey: String? = null): OAuthConfigResponse

    suspend fun getAvailableChannels(appId: String): List<ChannelInfo>

    suspend fun sendOtp(
        appId: String,
        targetType: OtpTargetType,
        target: String,
        channelKey: String? = null
    ): OtpSendResult

    suspend fun verifyOtp(
        appId: String,
        targetType: OtpTargetType,
        target: String,
        sessionId: String,
        code: String,
        channelKey: String? = null
    ): OtpVerifyResult

    suspend fun getAuthPayload(
        userId: String,
        provider: String? = null,
        appId: String? = null
    ): AuthPayloadResponse
}

