package com.zinben.opendev.services

/**
 * Desktop (JVM) 平台环境变量获取实现
 */
internal actual fun getEnvEncryptionKey(): String {
    return System.getenv("CDN_ENCRYPTION_KEY") ?: ""
}

