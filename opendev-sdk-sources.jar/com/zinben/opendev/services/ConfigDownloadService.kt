package com.zinben.opendev.services

import com.zinben.opendev.logger.Logger
import com.zinben.opendev.network.URLSession
import com.zinben.opendev.models.ConfigDownloadRequest
import com.zinben.opendev.models.ConfigEnvironment
import com.zinben.opendev.models.ConfigPlatform
import com.zinben.opendev.models.SDKConfig
import com.zinben.opendev.security.CdnKeyManager
import com.zinben.opendev.security.ConfigDecryption
import io.ktor.client.call.body
import io.ktor.client.request.get
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json

/**
 * 配置文件下载服务
 * 负责从CDN下载加密配置文件，解密并解析为配置数据模型
 */
class ConfigDownloadService(
    private val encryptionKey: String? = null
) {
    
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }
    
    private var _encryptionKey: String? = encryptionKey
    
    /**
     * 下载并解析配置文件
     * 
     * @param request 下载请求参数
     */
    suspend fun downloadConfig(request: ConfigDownloadRequest): SDKConfig {
        return withContext(Dispatchers.Default) {
            try {
                Logger.debug("[ConfigDownloadService] Starting config download: baseUrl=${request.baseUrl}, env=${request.environment}, platform=${request.platform.value}")
                
                // 1. 构建下载URL
                val downloadUrl = buildDownloadUrl(
                    baseUrl = request.baseUrl,
                    platform = request.platform,
                    environment = request.environment,
                    channelKey = request.channelKey,
                    token = request.token
                )
                
                Logger.debug("[ConfigDownloadService] Download URL: $downloadUrl")
                
                // 2. 下载加密文件
                val encryptedData = downloadEncryptedFile(downloadUrl)
                
                Logger.debug("[ConfigDownloadService] Downloaded encrypted file, size: ${encryptedData.length}")
                
                // 3. 解密文件
                val encryptionKey = getEncryptionKey()
                val decryptedJson = ConfigDecryption.decrypt(encryptedData, encryptionKey)
                
                Logger.debug("[ConfigDownloadService] Decrypted config, JSON length: ${decryptedJson.length}")
                
                // 记录解密后的JSON内容（前500个字符）用于调试
                val jsonPreview = decryptedJson.take(500)
                Logger.debug("[ConfigDownloadService] Decrypted JSON preview: $jsonPreview${if (decryptedJson.length > 500) "..." else ""}")
                
                // 验证JSON不为空
                if (decryptedJson.isBlank()) {
                    throw IllegalStateException("Decrypted JSON is empty")
                }
                
                // 4. 解析JSON为配置数据模型
                val config = try {
                    json.decodeFromString<SDKConfig>(decryptedJson)
                } catch (e: Exception) {
                    Logger.error("[ConfigDownloadService] JSON parsing failed: ${e.message}")
                    Logger.error("[ConfigDownloadService] Full decrypted JSON: $decryptedJson")
                    throw Exception("Failed to parse decrypted JSON: ${e.message}. JSON preview: $jsonPreview", e)
                }
                
                Logger.debug("[ConfigDownloadService] Config parsed successfully: appId=${config.appId}, appName=${config.app.name}")
                
                // 5. 调用成功回调（传递加密数据以便保存）
                request.onSuccess(config, encryptedData)
                
                config
            } catch (e: Exception) {
                Logger.error("[ConfigDownloadService] Config download failed: ${e.message}")
                request.onError(e)
                throw e
            }
        }
    }
    
    /**
     * 构建下载URL
     * 格式：[baseUrl]/manifest_平台_环境_渠道.enc?[token]
     */
    private fun buildDownloadUrl(
        baseUrl: String,
        platform: ConfigPlatform,
        environment: ConfigEnvironment,
        channelKey: String?,
        token: String
    ): String {
        val normalizedBaseUrl = baseUrl.trimEnd('/')
        val envValue = environment.name.lowercase()
        val platformValue = platform.value
        
        // 构建文件名
        val fileName = when {
            channelKey != null -> "manifest_${platformValue}_${envValue}_${channelKey}.enc"
            else -> "manifest_${platformValue}_${envValue}.enc"
        }
        
        // 构建完整URL
        val url = "$normalizedBaseUrl/$fileName"
        
        // 添加token参数
        return if (token.isNotBlank()) {
            "$url?$token"
        } else {
            url
        }
    }
    
    /**
     * 下载加密文件
     */
    private suspend fun downloadEncryptedFile(url: String): String {
        return try {
            val response: HttpResponse = URLSession.get(url)
            
            if (response.status.value !in 200..299) {
                val errorBody = try {
                    response.bodyAsText().take(200)
                } catch (_: Exception) {
                    "Unable to read error body"
                }
                throw Exception("Failed to download config file: HTTP ${response.status.value}. Error body: $errorBody")
            }
            
            // 读取响应体作为文本（加密数据是hex编码的字符串）
            val encryptedData = response.bodyAsText()
            
            // 验证下载的数据不为空
            if (encryptedData.isBlank()) {
                throw IllegalStateException("Downloaded encrypted file is empty")
            }
            
            // 记录下载的数据预览（前200个字符）用于调试
            val dataPreview = encryptedData.take(200)
            Logger.debug("[ConfigDownloadService] Downloaded data preview: $dataPreview${if (encryptedData.length > 200) "..." else ""}")
            
            encryptedData
        } catch (e: Exception) {
            Logger.error("[ConfigDownloadService] Download failed: ${e.message}")
            throw Exception("Failed to download config file from $url: ${e.message}", e)
        }
    }
    
    /**
     * 设置加密密钥
     */
    fun setEncryptionKey(key: String) {
        _encryptionKey = key
    }
    
    private fun getEncryptionKey(): String {
        // 优先使用设置的密钥（用于测试或特殊场景）
        if (!_encryptionKey.isNullOrBlank()) {
            return _encryptionKey!!
        }
        
        // 使用 SDK 内部密钥（通道层加密密钥）
        return CdnKeyManager.getCdnEncryptionKey()
    }
    
}

/**
 * 从环境变量获取加密密钥
 * 使用expect/actual机制实现跨平台支持
 */
internal expect fun getEnvEncryptionKey(): String

