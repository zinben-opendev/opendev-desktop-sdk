package com.zinben.opendev.services

import com.zinben.opendev.logger.Logger
import com.zinben.opendev.models.ClientChannelConfig

/**
 * Service for fetching channel configuration from the server.
 *
 * The default implementation ([LocalChannelConfigService]) returns null,
 * falling back to the local [ClientChannelConfig] provided at SDK init time.
 * [RemoteChannelConfigService] fetches from `GET /auth/oauth-config` and
 * converts the response into a [ClientChannelConfig].
 */
interface ChannelConfigService {
    suspend fun fetchChannelConfig(appId: String, channelId: String): ClientChannelConfig?
}

/**
 * Default no-op implementation — always returns null so the SDK uses
 * the locally-provided [ClientChannelConfig] from [PlatformConfig].
 */
class LocalChannelConfigService : ChannelConfigService {
    override suspend fun fetchChannelConfig(appId: String, channelId: String): ClientChannelConfig? {
        Logger.debug("[ChannelConfigService] Using local channel config (server fetch not enabled)")
        return null
    }
}

/**
 * Fetches channel configuration from `GET /auth/oauth-config` and converts
 * the OAuth provider configs into a [ClientChannelConfig].
 *
 * This replaces the previously stubbed `/auth/app-channels` approach.
 * The `/auth/oauth-config` endpoint accepts an optional `channelKey` parameter
 * and returns per-provider clientId/appId, which maps directly to
 * [ClientChannelConfig.enabledAuthProviders] and [ClientChannelConfig.oauthOverrides].
 */
class RemoteChannelConfigService(
    private val authService: AuthService
) : ChannelConfigService {
    override suspend fun fetchChannelConfig(appId: String, channelId: String): ClientChannelConfig? {
        return try {
            val response = authService.getOAuthConfig(appId, channelId.takeIf { it.isNotBlank() })
            val configs = response.configs
            if (configs.availableOAuthProviders().isEmpty()) {
                Logger.debug("[ChannelConfigService] No OAuth providers configured for appId=$appId, channelKey=$channelId")
                null
            } else {
                val channelConfig = configs.toClientChannelConfig(response.channelKey ?: channelId)
                Logger.debug("[ChannelConfigService] Remote config fetched: ${channelConfig.enabledAuthProviders.size} providers enabled")
                channelConfig
            }
        } catch (e: Exception) {
            Logger.error("[ChannelConfigService] Remote fetch failed: ${e.message}")
            null
        }
    }
}
