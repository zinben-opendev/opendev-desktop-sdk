package com.zinben.opendev.services

import com.zinben.opendev.logger.Logger
import com.zinben.opendev.models.OAuthConfigResponse
import com.zinben.opendev.storage.KVLocalDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.serialization.json.Json

/**
 * Stale-While-Revalidate cache for OAuth configuration.
 *
 * Lifecycle:
 * 1. Cold start (no local cache): synchronous fetch, persist, set in-memory.
 * 2. Warm start (local cache exists): load from KV store (~1ms), set in-memory,
 *    then async refresh in background — persisted for next launch.
 * 3. All subsequent reads (`current`) are pure in-memory, zero network cost.
 *
 * Aligned with Firebase Remote Config Strategy 3 and LaunchDarkly Warm Start.
 */
class OAuthConfigCache(
    private val kvStore: KVLocalDataStore,
    private val authService: AuthService,
    private val scope: CoroutineScope
) {
    private val _current = MutableStateFlow<OAuthConfigResponse?>(null)
    val current: OAuthConfigResponse? get() = _current.value

    private var onConfigUpdated: ((OAuthConfigResponse) -> Unit)? = null

    fun setOnConfigUpdated(listener: (OAuthConfigResponse) -> Unit) {
        onConfigUpdated = listener
    }

    suspend fun loadFromLocal(): OAuthConfigResponse? {
        return try {
            val raw: String? = kvStore.get(KEY, NAMESPACE)
            if (raw.isNullOrBlank()) return null
            val response = json.decodeFromString<OAuthConfigResponse>(raw)
            _current.value = response
            Logger.debug("[OAuthConfigCache] Loaded from local cache: appId=${response.appId}")
            response
        } catch (e: Exception) {
            Logger.debug("[OAuthConfigCache] Failed to load local cache: ${e.message}")
            null
        }
    }

    suspend fun fetchFromServer(appId: String, channelKey: String?): OAuthConfigResponse? {
        return try {
            val response = authService.getOAuthConfig(appId, channelKey)
            _current.value = response
            persist(response)
            Logger.debug("[OAuthConfigCache] Fetched from server and persisted: appId=${response.appId}")
            response
        } catch (e: Exception) {
            Logger.debug("[OAuthConfigCache] Server fetch failed: ${e.message}")
            null
        }
    }

    fun refreshAsync(appId: String, channelKey: String?) {
        scope.launch(Dispatchers.Default) {
            try {
                val response = authService.getOAuthConfig(appId, channelKey)
                _current.value = response
                persist(response)
                onConfigUpdated?.invoke(response)
                Logger.debug("[OAuthConfigCache] Async refresh completed, config updated in-memory + persisted")
            } catch (e: Exception) {
                Logger.debug("[OAuthConfigCache] Async refresh failed: ${e.message}")
            }
        }
    }

    private suspend fun persist(response: OAuthConfigResponse) {
        try {
            val raw = json.encodeToString(OAuthConfigResponse.serializer(), response)
            kvStore.set(KEY, raw, NAMESPACE)
        } catch (e: Exception) {
            Logger.debug("[OAuthConfigCache] Persist failed: ${e.message}")
        }
    }

    companion object {
        private const val KEY = "oauth_config"
        private const val NAMESPACE = "opendev_config"
        private val json = Json { ignoreUnknownKeys = true }
    }
}
