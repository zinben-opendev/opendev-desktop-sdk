package com.zinben.opendev.services

import com.zinben.opendev.network.ApiResponseWrapper
import com.zinben.opendev.network.URLSession
import com.zinben.opendev.logger.Logger
import com.zinben.opendev.models.PlatformAuthResult
import com.zinben.opendev.models.PlatformUserInfo
import com.zinben.opendev.models.LoginType
import com.zinben.opendev.models.ThirdPartyProvider
import com.zinben.opendev.models.User
import com.zinben.opendev.models.BoundAccountInfo
import com.zinben.opendev.models.AuthError
import com.zinben.opendev.models.AuthResult
import com.zinben.opendev.models.AppChannelsResponse
import com.zinben.opendev.models.ChannelInfo
import com.zinben.opendev.models.OAuthConfigResponse
import com.zinben.opendev.models.OAuthProviderConfigs
import com.zinben.opendev.models.AuthPayloadResponse
import com.zinben.opendev.models.OtpSendResult
import com.zinben.opendev.models.OtpTargetType
import com.zinben.opendev.models.OtpVerifyResult
import com.zinben.opendev.models.SendOtpRequest
import com.zinben.opendev.models.VerifyOtpRequest
import com.zinben.opendev.models.toApiType
import com.zinben.opendev.models.toThirdPartyProviderOrNull
import com.zinben.opendev.utils.TimeUtils
import io.ktor.client.call.body
import io.ktor.client.request.forms.formData
import io.ktor.client.request.forms.submitFormWithBinaryData
import io.ktor.client.request.get
import io.ktor.client.request.headers
import io.ktor.client.request.parameter
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.http.ContentType
import io.ktor.http.Headers
import io.ktor.http.HttpHeaders
import io.ktor.http.contentType
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * Pure HTTP authentication service — no local caching or state.
 *
 * All session/cache management is handled by AuthManager.
 */
class HttpAuthService(
    private val baseUrl: String = "",
    private val apiVersion: String = "v1",
    private val appId: String = "",
    private val deviceIdProvider: suspend () -> String = { "" }
) : AuthService {

    companion object {
        private const val DEFAULT_SESSION_DURATION = 30L * 24 * 60 * 60 * 1000
        private const val DEFAULT_BASE_URL = "http://localhost:3000"
        const val MAX_AVATAR_SIZE = 1 * 1024 * 1024 // 1MB, matches backend multer limit
    }

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val resolvedBaseUrl = baseUrl.takeIf { it.isNotBlank() }?.trimEnd('/') ?: DEFAULT_BASE_URL
    private val resolvedApiVersion = apiVersion.trim('/').ifBlank { null }
    
    override suspend fun guestLogin(): AuthResult {
        return try {
            val deviceId = deviceIdProvider()
            val request = AccountLoginRequest(
                appId = appId.takeIf { it.isNotBlank() },
                deviceId = deviceId,
                deviceUuid = deviceId,
                loginType = "guest"
            )
            val response = URLSession.post(endpoint("/account/login")) {
                contentType(ContentType.Application.Json)
                setBody(request)
            }.body<ApiResponseWrapper<AccountLoginResponseData>>()

            if (response.code != 0 || response.data == null) {
                Logger.error("[AuthService] guestLogin failed: code=${response.code}, msg=${response.msg}")
                return AuthResult.Failure(AuthError.NETWORK_ERROR)
            }

            val data = response.data
            val userDto = data.user ?: data.users?.firstOrNull()
            if (userDto == null) {
                Logger.error("[AuthService] guestLogin response missing user data")
                return AuthResult.Failure(AuthError.UNKNOWN_ERROR)
            }
            val userData = userDto.toUserData()

            val token = data.token ?: ""
            if (token.isBlank()) {
                Logger.error("[AuthService] guestLogin response missing token")
                return AuthResult.Failure(AuthError.UNKNOWN_ERROR)
            }

            AuthResult.Success(
                user = userData.toUser(),
                sessionToken = token,
                jwtToken = data.jwtToken,
                expiresAt = data.expiresAt ?: (TimeUtils.getCurrentTimeMillis() + DEFAULT_SESSION_DURATION)
            )
        } catch (e: Exception) {
            Logger.error("[AuthService] guestLogin exception: ${e.message}")
            AuthResult.Failure(AuthError.NETWORK_ERROR)
        }
    }

    private fun endpoint(path: String): String {
        val normalizedPath = path.trimStart('/')
        return buildString {
            append(resolvedBaseUrl)
            resolvedApiVersion?.let {
                append('/')
                append(it)
            }
            append('/')
            append(normalizedPath)
        }
    }
    
    override suspend fun thirdPartyLogin(
        provider: ThirdPartyProvider,
        platformUserInfo: PlatformUserInfo,
        accessToken: String?,
        targetUserId: String?
    ): AuthResult {
        return try {
            val deviceId = deviceIdProvider()
            val request = AccountLoginRequest(
                appId = appId.takeIf { it.isNotBlank() },
                deviceId = deviceId,
                deviceUuid = deviceId,
                loginType = "federated",
                targetUserId = targetUserId,
                provider = BindProviderPayload(
                    type = provider.toApiType(),
                    id = platformUserInfo.providerUserId,
                    name = platformUserInfo.nickname ?: platformUserInfo.username,
                    email = platformUserInfo.email,
                    accessToken = accessToken ?: ""
                )
            )

            val response = URLSession.post(endpoint("/account/login")) {
                contentType(ContentType.Application.Json)
                setBody(request)
            }.body<ApiResponseWrapper<AccountLoginResponseData>>()

            if (response.code != 0 || response.data == null) {
                Logger.error("[AuthService] thirdPartyLogin failed: code=${response.code}, msg=${response.msg}")
                return AuthResult.Failure(mapBusinessError(response.code, response.msg))
            }

            val responseData = response.data
            val usersList = responseData.users ?: listOfNotNull(responseData.user)

            if (usersList.size > 1 && responseData.token == null) {
                Logger.debug("[AuthService] Multiple accounts found: ${usersList.size}")
                return AuthResult.MultipleAccounts(usersList.map { it.toUserData().toUser() })
            }

            if (usersList.isNotEmpty() && !responseData.token.isNullOrBlank()) {
                val userData = usersList.first().toUserData()
                return AuthResult.Success(
                    user = userData.toUser(),
                    sessionToken = responseData.token,
                    jwtToken = responseData.jwtToken,
                    expiresAt = responseData.expiresAt ?: (TimeUtils.getCurrentTimeMillis() + DEFAULT_SESSION_DURATION)
                )
            }

            if (usersList.isEmpty() && responseData.token == null && responseData.unlinked == true) {
                Logger.debug("[AuthService] Provider unlinked, no account found for ${provider.name}")
                return AuthResult.Unlinked(
                    provider = provider,
                    platformUserInfo = platformUserInfo,
                    accessToken = accessToken
                )
            }

            Logger.error("[AuthService] Login response invalid: users=${usersList.size}, token=${responseData.token != null}")
            AuthResult.Failure(AuthError.UNKNOWN_ERROR)
        } catch (e: io.ktor.client.plugins.ClientRequestException) {
            val httpStatus = e.response.status.value
            val msg = runCatching { extractApiMessage(e) }.getOrElse { e.message }
            Logger.error("[AuthService] thirdPartyLogin HTTP $httpStatus: $msg")
            AuthResult.Failure(mapHttpStatusError(httpStatus, msg))
        } catch (e: Exception) {
            Logger.error("[AuthService] thirdPartyLogin exception: ${e.message}")
            AuthResult.Failure(AuthError.NETWORK_ERROR)
        }
    }
    
    override suspend fun bindAccount(
        provider: ThirdPartyProvider,
        authToken: String,
        authPayload: PlatformAuthResult.Success?
    ): AuthResult {
        return try {
            if (authToken.isBlank()) {
                return AuthResult.Failure(AuthError.INVALID_CREDENTIALS)
            }
            val payload = authPayload
                ?: return AuthResult.Failure(AuthError.INVALID_CREDENTIALS)

            Logger.debug("[AuthService] Starting bindAccount: provider=${provider.name}")

            val request = AccountBindRequest(
                appId = appId.takeIf { it.isNotBlank() },
                provider = BindProviderPayload(
                    type = provider.toApiType(),
                    id = payload.providerUserId,
                    name = payload.userInfo.nickname ?: payload.userInfo.username,
                    email = payload.userInfo.email,
                    accessToken = payload.accessToken,
                    refreshToken = null
                )
            )

            val response = URLSession.post(endpoint("/account/bind")) {
                contentType(ContentType.Application.Json)
                headers {
                    append(HttpHeaders.Authorization, "Bearer $authToken")
                }
                setBody(request)
            }.body<ApiResponseWrapper<AccountBindResponseData>>()

            if (response.code != 0 || response.data == null) {
                Logger.error("[AuthService] bindAccount failed: code=${response.code}, msg=${response.msg}")
                return AuthResult.Failure(mapBusinessError(response.code, response.msg))
            }

            val userData = response.data.user.toUserData()
            Logger.debug("[AuthService] bindAccount success for provider=${provider.name}, user=${userData.id}")

            AuthResult.Success(
                user = userData.toUser(),
                sessionToken = authToken,
                jwtToken = null,
                expiresAt = null
            )
        } catch (e: io.ktor.client.plugins.ClientRequestException) {
            val httpStatus = e.response.status.value
            val msg = runCatching { extractApiMessage(e) }.getOrElse { e.message }
            Logger.error("[AuthService] bindAccount HTTP $httpStatus: $msg")
            AuthResult.Failure(mapHttpStatusError(httpStatus, msg))
        } catch (e: Exception) {
            Logger.error("[AuthService] bindAccount failed: ${e.message}")
            AuthResult.Failure(AuthError.NETWORK_ERROR)
        }
    }
    
    override suspend fun unbindAccount(
        provider: ThirdPartyProvider,
        authToken: String,
        boundAccount: BoundAccountInfo?
    ): AuthResult {
        return try {
            if (authToken.isBlank()) {
                return AuthResult.Failure(AuthError.INVALID_CREDENTIALS)
            }

            if (boundAccount == null) {
                Logger.error("[AuthService] Bound account info required for unbind, provider=${provider.name}")
                return AuthResult.Failure(AuthError.USER_NOT_FOUND)
            }

            val request = AccountUnbindRequest(
                providerType = provider.toApiType(),
                providerId = boundAccount.providerUserId
            )

            val response = URLSession.post(endpoint("/account/unbind")) {
                contentType(ContentType.Application.Json)
                headers {
                    append(HttpHeaders.Authorization, "Bearer $authToken")
                }
                setBody(request)
            }.body<ApiResponseWrapper<AccountUnbindResponseData>>()

            if (response.code != 0 || response.data == null) {
                Logger.error("[AuthService] unbindAccount failed: code=${response.code}, msg=${response.msg}")
                return AuthResult.Failure(AuthError.NETWORK_ERROR)
            }

            val userData = response.data.user.toUserData()
            AuthResult.Success(
                user = userData.toUser(),
                sessionToken = authToken,
                jwtToken = null,
                expiresAt = null
            )
        } catch (e: Exception) {
            Logger.error("[AuthService] unbindAccount failed: ${e.message}")
            AuthResult.Failure(AuthError.NETWORK_ERROR)
        }
    }

    override suspend fun bindOtpAccount(
        targetType: OtpTargetType,
        target: String,
        authToken: String
    ): AuthResult {
        return try {
            if (authToken.isBlank()) return AuthResult.Failure(AuthError.INVALID_CREDENTIALS)

            val request = AccountBindRequest(
                appId = appId.takeIf { it.isNotBlank() },
                provider = BindProviderPayload(
                    type = targetType.toApiType(),
                    id = target
                )
            )

            val response = URLSession.post(endpoint("/account/bind")) {
                contentType(ContentType.Application.Json)
                headers { append(HttpHeaders.Authorization, "Bearer $authToken") }
                setBody(request)
            }.body<ApiResponseWrapper<AccountBindResponseData>>()

            if (response.code != 0 || response.data == null) {
                Logger.error("[AuthService] bindOtpAccount failed: code=${response.code}, msg=${response.msg}")
                return AuthResult.Failure(AuthError.NETWORK_ERROR)
            }

            val userData = response.data.user.toUserData()
            AuthResult.Success(
                user = userData.toUser(),
                sessionToken = authToken,
                jwtToken = null,
                expiresAt = null
            )
        } catch (e: Exception) {
            Logger.error("[AuthService] bindOtpAccount failed: ${e.message}")
            AuthResult.Failure(AuthError.NETWORK_ERROR)
        }
    }

    override suspend fun unbindOtpAccount(
        targetType: OtpTargetType,
        target: String,
        authToken: String
    ): AuthResult {
        return try {
            if (authToken.isBlank()) return AuthResult.Failure(AuthError.INVALID_CREDENTIALS)

            val request = AccountUnbindRequest(
                providerType = targetType.toApiType(),
                providerId = target
            )

            val response = URLSession.post(endpoint("/account/unbind")) {
                contentType(ContentType.Application.Json)
                headers { append(HttpHeaders.Authorization, "Bearer $authToken") }
                setBody(request)
            }.body<ApiResponseWrapper<AccountUnbindResponseData>>()

            if (response.code != 0 || response.data == null) {
                Logger.error("[AuthService] unbindOtpAccount failed: code=${response.code}, msg=${response.msg}")
                return AuthResult.Failure(AuthError.NETWORK_ERROR)
            }

            val userData = response.data.user.toUserData()
            AuthResult.Success(
                user = userData.toUser(),
                sessionToken = authToken,
                jwtToken = null,
                expiresAt = null
            )
        } catch (e: Exception) {
            Logger.error("[AuthService] unbindOtpAccount failed: ${e.message}")
            AuthResult.Failure(AuthError.NETWORK_ERROR)
        }
    }

    override suspend fun logout(authToken: String?): AuthResult {
        val emptyUser = User(id = "", username = "", loginType = LoginType.GUEST, createdAt = 0L, lastLoginAt = 0L)
        return try {
            if (authToken.isNullOrBlank()) {
                return AuthResult.Success(user = emptyUser, sessionToken = "", jwtToken = null, expiresAt = null)
            }

            val request = AccountLogoutRequest(token = authToken)
            URLSession.post(endpoint("/account/logout")) {
                contentType(ContentType.Application.Json)
                headers {
                    append(HttpHeaders.Authorization, "Bearer $authToken")
                }
                setBody(request)
            }.body<ApiResponseWrapper<Map<String, String>>>()

            AuthResult.Success(user = emptyUser, sessionToken = "", jwtToken = null, expiresAt = null)
        } catch (e: Exception) {
            Logger.error("[AuthService] logout failed: ${e.message}")
            AuthResult.Success(user = emptyUser, sessionToken = "", jwtToken = null, expiresAt = null)
        }
    }
    
    override suspend fun refreshToken(authToken: String): AuthResult {
        return try {
            if (authToken.isBlank()) {
                return AuthResult.Failure(AuthError.INVALID_CREDENTIALS)
            }

            val deviceId = deviceIdProvider()
            val request = AccountTokenLoginRequest(
                deviceId = deviceId,
                userId = null
            )

            val response = URLSession.post(endpoint("/account/token-login")) {
                contentType(ContentType.Application.Json)
                headers {
                    append(HttpHeaders.Authorization, "Bearer $authToken")
                }
                setBody(request)
            }.body<ApiResponseWrapper<AccountTokenLoginResponseData>>()

            if (response.code != 0 || response.data == null) {
                Logger.error("[AuthService] refreshToken failed: code=${response.code}, msg=${response.msg}")
                return AuthResult.Failure(AuthError.INVALID_CREDENTIALS)
            }

            val data = response.data
            val userData = data.user.toUserData()
            AuthResult.Success(
                user = userData.toUser(),
                sessionToken = data.token,
                jwtToken = data.jwtToken,
                expiresAt = data.expiresAt ?: (TimeUtils.getCurrentTimeMillis() + DEFAULT_SESSION_DURATION)
            )
        } catch (e: Exception) {
            Logger.error("[AuthService] refreshToken exception: ${e.message}")
            AuthResult.Failure(AuthError.NETWORK_ERROR)
        }
    }
    
    override suspend fun updateUserInfo(user: User, authToken: String?): AuthResult {
        return try {
            if (authToken.isNullOrBlank()) {
                return AuthResult.Failure(AuthError.INVALID_CREDENTIALS)
            }

            val request = UpdateProfileRequest(
                userId = user.id,
                username = user.username ?: "",
                nickname = user.nickname,
                avatar = user.avatar
            )

            val response = URLSession.post(endpoint("/account/profile")) {
                contentType(ContentType.Application.Json)
                headers {
                    append(HttpHeaders.Authorization, "Bearer $authToken")
                }
                setBody(request)
            }.body<ApiResponseWrapper<UpdateProfileResponseData>>()

            if (response.code != 0 || response.data == null) {
                Logger.error("[AuthService] updateUserInfo failed: code=${response.code}, msg=${response.msg}")
                return AuthResult.Failure(AuthError.NETWORK_ERROR)
            }

            val userData = response.data.user.toUserData()
            AuthResult.Success(
                user = userData.toUser(),
                sessionToken = authToken,
                jwtToken = null,
                expiresAt = null
            )
        } catch (e: Exception) {
            Logger.error("[AuthService] updateUserInfo failed: ${e.message}")
            AuthResult.Failure(AuthError.NETWORK_ERROR)
        }
    }

    override suspend fun uploadAvatar(
        imageBytes: ByteArray,
        fileName: String,
        mimeType: String,
        authToken: String
    ): kotlin.Result<String> {
        return try {
            if (imageBytes.size > MAX_AVATAR_SIZE) {
                return kotlin.Result.failure(RuntimeException("Image exceeds 1MB limit"))
            }
            val allowedMimes = setOf("image/png", "image/jpeg", "image/gif", "image/webp")
            if (mimeType !in allowedMimes) {
                return kotlin.Result.failure(RuntimeException("Only PNG, JPG, GIF, WebP images are allowed"))
            }

            val response = URLSession.submitFormWithBinaryData(
                url = endpoint("/account/avatar"),
                formData = formData {
                    append("avatar", imageBytes, Headers.build {
                        append(HttpHeaders.ContentType, mimeType)
                        append(HttpHeaders.ContentDisposition, "filename=\"$fileName\"")
                    })
                }
            ) {
                headers {
                    append(HttpHeaders.Authorization, "Bearer $authToken")
                }
            }.body<ApiResponseWrapper<AvatarUploadResponseData>>()

            if (response.code == 0 && response.data != null) {
                val userData = response.data.user
                val avatarUrl = userData?.avatar ?: ""
                Logger.debug("[AuthService] Avatar uploaded: $avatarUrl")
                kotlin.Result.success(avatarUrl)
            } else {
                Logger.error("[AuthService] Avatar upload failed: code=${response.code}, msg=${response.msg}")
                kotlin.Result.failure(RuntimeException(response.msg.ifBlank { "Upload failed" }))
            }
        } catch (e: io.ktor.client.plugins.ClientRequestException) {
            val msg = extractApiMessage(e)
            Logger.error("[AuthService] Avatar upload client error: $msg")
            kotlin.Result.failure(RuntimeException(msg))
        } catch (e: Exception) {
            Logger.error("[AuthService] Avatar upload failed: ${e.message}")
            kotlin.Result.failure(e)
        }
    }

    override suspend fun checkLoginStatus(token: String): Boolean {
        return try {
            if (token.isBlank()) return false

            val deviceId = deviceIdProvider()
            val request = AccountTokenLoginRequest(
                deviceId = deviceId,
                userId = null
            )

            val response = URLSession.post(endpoint("/account/token-login")) {
                contentType(ContentType.Application.Json)
                headers {
                    append(HttpHeaders.Authorization, "Bearer $token")
                }
                setBody(request)
            }.body<ApiResponseWrapper<AccountTokenLoginResponseData>>()

            val valid = response.code == 0 && response.data != null
            Logger.debug("[AuthService] Token validation result: $valid")
            valid
        } catch (e: Exception) {
            Logger.error("[AuthService] checkLoginStatus failed: ${e.message}")
            false
        }
    }

    override suspend fun getOAuthConfig(appId: String, channelKey: String?): OAuthConfigResponse {
        return try {
            val url = "${resolvedBaseUrl}/auth/oauth-config"
            val response = URLSession.get(url) {
                parameter("appId", appId)
                channelKey?.let { parameter("channelKey", it) }
            }.body<ApiResponseWrapper<OAuthConfigResponse>>()

            if (response.code != 0 || response.data == null) {
                Logger.error("[AuthService] getOAuthConfig failed: code=${response.code}, msg=${response.msg}")
                OAuthConfigResponse()
            } else {
                response.data
            }
        } catch (e: Exception) {
            Logger.error("[AuthService] getOAuthConfig exception: ${e.message}")
            OAuthConfigResponse()
        }
    }

    override suspend fun getAvailableChannels(appId: String): List<ChannelInfo> {
        return try {
            val url = "${resolvedBaseUrl}/auth/app-channels"
            val response = URLSession.get(url) {
                parameter("appId", appId)
            }.body<ApiResponseWrapper<AppChannelsResponse>>()

            if (response.code != 0 || response.data == null) {
                Logger.error("[AuthService] getAvailableChannels failed: code=${response.code}, msg=${response.msg}")
                emptyList()
            } else {
                response.data.channels
            }
        } catch (e: Exception) {
            Logger.error("[AuthService] getAvailableChannels exception: ${e.message}")
            emptyList()
        }
    }

    // ==================== OTP ====================

    override suspend fun sendOtp(
        appId: String,
        targetType: OtpTargetType,
        target: String,
        channelKey: String?
    ): OtpSendResult {
        val url = "${resolvedBaseUrl}/auth/send-otp"
        val request = SendOtpRequest(
            appId = appId,
            channelKey = channelKey,
            targetType = targetType.toApiType(),
            target = target
        )
        try {
            val response = URLSession.post(url) {
                contentType(ContentType.Application.Json)
                setBody(request)
            }.body<ApiResponseWrapper<OtpSendResult>>()

            if (response.code != 0 || response.data == null) {
                throw IllegalStateException(response.msg.ifBlank { "sendOtp failed (code=${response.code})" })
            }
            return response.data
        } catch (e: io.ktor.client.plugins.ClientRequestException) {
            throw IllegalStateException(extractApiMessage(e))
        }
    }

    override suspend fun verifyOtp(
        appId: String,
        targetType: OtpTargetType,
        target: String,
        sessionId: String,
        code: String,
        channelKey: String?
    ): OtpVerifyResult {
        val url = "${resolvedBaseUrl}/auth/verify-otp"
        val request = VerifyOtpRequest(
            appId = appId,
            channelKey = channelKey,
            targetType = targetType.toApiType(),
            target = target,
            sessionId = sessionId,
            code = code
        )
        try {
            val response = URLSession.post(url) {
                contentType(ContentType.Application.Json)
                setBody(request)
            }.body<ApiResponseWrapper<OtpVerifyResult>>()

            if (response.code != 0 || response.data == null) {
                throw IllegalStateException(response.msg.ifBlank { "verifyOtp failed (code=${response.code})" })
            }
            return response.data
        } catch (e: io.ktor.client.plugins.ClientRequestException) {
            throw IllegalStateException(extractApiMessage(e))
        }
    }

    override suspend fun getAuthPayload(
        userId: String,
        provider: String?,
        appId: String?
    ): AuthPayloadResponse {
        val url = "${resolvedBaseUrl}/auth/payload"
        val response = URLSession.get(url) {
            parameter("user_id", userId)
            provider?.let { parameter("provider", it) }
            appId?.let { parameter("appId", it) }
        }.body<ApiResponseWrapper<AuthPayloadResponse>>()

        if (response.code != 0 || response.data == null) {
            throw IllegalStateException("getAuthPayload failed: code=${response.code}, msg=${response.msg}")
        }
        return response.data
    }
}

// ==================== 数据模型 ====================

/**
 * 用户数据模型
 */
@Serializable
data class UserData(
    val id: String,
    val username: String?,
    val email: String?,
    val avatar: String?,
    val nickname: String?,
    val loginType: LoginType,
    val boundAccounts: List<BoundAccountInfo>,
    val createdAt: Long,
    val lastLoginAt: Long,
    val isSynced: Boolean
) {
    fun toUser(): User {
        return User(
            id = id,
            username = username,
            email = email,
            avatar = avatar,
            nickname = nickname,
            loginType = loginType,
            boundAccounts = boundAccounts,
            createdAt = createdAt,
            lastLoginAt = lastLoginAt,
            isSynced = isSynced
        )
    }
    
    companion object
}

// ==================== 远程账号服务数据模型 ====================

@Serializable
private data class AccountLoginRequest(
    val appId: String? = null, // 应用ID，用于账号服务按应用隔离
    val deviceId: String? = null,
    val deviceUuid: String? = null,
    val loginType: String? = null,
    val provider: BindProviderPayload? = null,
    val targetUserId: String? = null
)

@Serializable
private data class AccountLoginResponseData(
    val users: List<AccountUserDto>? = null,
    val user: AccountUserDto? = null,
    val token: String? = null,
    val jwtToken: String? = null,
    val expiresAt: Long? = null,
    val unlinked: Boolean? = null
)

@Serializable
private data class AccountBindRequest(
    val appId: String? = null, // 应用ID，用于账号服务按应用隔离
    val provider: BindProviderPayload
)

@Serializable
private data class BindProviderPayload(
    val type: String,
    val id: String? = null,
    val name: String? = null,
    val email: String? = null,
    val accessToken: String? = null,
    val refreshToken: String? = null
)

@Serializable
private data class AccountBindResponseData(
    val user: AccountUserDto
)

@Serializable
private data class AccountUnbindRequest(
    val providerType: String,
    val providerId: String? = null
)

@Serializable
private data class AccountUnbindResponseData(
    val user: AccountUserDto
)

@Serializable
private data class AccountTokenLoginRequest(
    val deviceId: String? = null,
    val userId: String? = null
)

@Serializable
private data class AccountTokenLoginResponseData(
    val user: AccountUserDto,
    val token: String,
    val jwtToken: String? = null,
    val expiresAt: Long? = null
)

@Serializable
private data class AccountLogoutRequest(
    val token: String? = null
)

@Serializable
private data class AccountLookupRequest(
    val appId: String? = null, // 应用ID，用于账号服务按应用隔离
    val deviceId: String? = null,
    val deviceUuid: String? = null,
    val provider: BindProviderPayload? = null
)

@Serializable
private data class AccountLookupResponseData(
    val user: AccountUserDto
)

@Serializable
private data class UpdateProfileRequest(
    val userId: String? = null,
    val username: String,
    val nickname: String? = null,
    val avatar: String? = null
)

@Serializable
private data class UpdateProfileResponseData(
    val user: AccountUserDto
)

@Serializable
private data class AvatarUploadResponseData(
    val user: AccountUserDto? = null
)

@Serializable
private data class AccountUserDto(
    val id: String,
    val username: String? = null,
    val email: String? = null,
    val avatar: String? = null,
    val nickname: String? = null,
    val loginType: String? = null,
    val boundAccounts: List<RemoteBoundAccountDto> = emptyList(),
    val createdAt: Long? = null,
    val lastLoginAt: Long? = null,
    val deviceId: String? = null,
    val deviceUuid: String? = null
)

/**
 * 绑定账号信息（符合接口文档规范）
 * 接口文档中 boundAccounts 包含：provider, id, name, email
 * 注意：不包含 accessToken 和 refreshToken（这些是加密存储的）
 */
@Serializable
private data class RemoteBoundAccountDto(
    val provider: String? = null,
    val id: String? = null,
    val name: String? = null,
    val email: String? = null
)

private fun AccountUserDto.toUserData(): UserData {
    val now = TimeUtils.getCurrentTimeMillis()
    // 保留完整的绑定账号信息，包括 provider、id、name 和 email（符合接口文档规范）
    val boundAccountInfos = boundAccounts.mapNotNull { dto ->
        val type = dto.provider ?: return@mapNotNull null
        BoundAccountInfo(
            providerType = type,
            providerUserId = dto.id,
            providerUserName = dto.name ?: dto.email
        )
    }
    return UserData(
        id = id,
        username = username,
        email = email,
        avatar = avatar,
        nickname = nickname,
        loginType = loginType.toLoginType(),
        boundAccounts = boundAccountInfos,
        createdAt = createdAt ?: now,
        lastLoginAt = lastLoginAt ?: now,
        isSynced = true
    )
}

private fun String?.toLoginType(): LoginType {
    return when (this?.lowercase()) {
        "federated", "third_party", "thirdparty" -> LoginType.THIRD_PARTY
        "bound" -> LoginType.BOUND
        "otp", "phone", "email" -> LoginType.OTP
        else -> LoginType.GUEST
    }
}

private suspend fun extractApiMessage(e: io.ktor.client.plugins.ClientRequestException): String {
    return try {
        val body = e.response.body<ApiResponseWrapper<Unit?>>()
        body.msg.ifBlank { e.message }
    } catch (_: Exception) {
        e.message
    }
}

private fun mapHttpStatusError(httpStatus: Int, msg: String): AuthError = when (httpStatus) {
    403 -> if (msg.contains("invalidTargetUser", ignoreCase = true)) {
        AuthError.INVALID_TARGET_USER
    } else {
        AuthError.INVALID_CREDENTIALS
    }
    409 -> AuthError.ACCOUNT_ALREADY_BOUND
    429 -> AuthError.TOO_MANY_ATTEMPTS
    401 -> AuthError.INVALID_CREDENTIALS
    else -> AuthError.NETWORK_ERROR
}

private fun mapBusinessError(code: Int, msg: String): AuthError = when {
    msg.contains("accountAlreadyBound", ignoreCase = true) -> AuthError.ACCOUNT_ALREADY_BOUND
    msg.contains("invalidTargetUser", ignoreCase = true) -> AuthError.INVALID_TARGET_USER
    msg.contains("tooMany", ignoreCase = true) || msg.contains("rate", ignoreCase = true) -> AuthError.TOO_MANY_ATTEMPTS
    msg.contains("disabled", ignoreCase = true) -> AuthError.ACCOUNT_DISABLED
    else -> AuthError.NETWORK_ERROR
}

