package com.zinben.opendev.services

import com.zinben.opendev.logger.Logger
import com.zinben.opendev.models.ConfigEnvironment
import com.zinben.opendev.models.ConfigPlatform
import com.zinben.opendev.models.SDKConfig
import com.zinben.opendev.security.CdnKeyManager
import com.zinben.opendev.security.ConfigDecryption
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json

/**
 * 本地配置文件读取服务
 * 负责从本地文件系统读取预置的加密配置文件，解密并解析为配置数据模型
 */
object LocalConfigReadService {
    
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }
    
    /**
     * 从本地文件读取配置
     * 
     * @param platform 平台标识（android/ios/desktop/web）
     * @param environment 环境（test/dev/prod）
     * @param channelKey 渠道标识（如 google_global，可选）
     * @param filePath 文件路径（可选，如果为空则使用默认路径）
     * @param encryptionKey 加密密钥（可选，如果为空则从环境变量获取）
     * @return 配置数据模型
     */
    suspend fun readConfigFromFile(
        platform: ConfigPlatform,
        environment: ConfigEnvironment,
        channelKey: String? = null,
        filePath: String? = null,
        encryptionKey: String? = null
    ): SDKConfig {
        return withContext(Dispatchers.Default) {
            try {
                Logger.debug("[LocalConfigReadService] Starting config read: platform=${platform.value}, env=${environment.name}, channel=$channelKey")
                
                // 1. 确定资源路径
                // 如果提供了自定义路径，使用自定义路径（可能是文件系统路径）
                // 否则优先从数据目录读取，如果不存在再从应用资源读取
                val encryptedData = if (filePath != null) {
                    // 使用自定义路径
                    Logger.debug("[LocalConfigReadService] Reading from custom path: $filePath")
                    readLocalConfigFile(filePath)
                } else {
                    // 优先从数据目录读取，如果不存在再从资源读取
                    val fileName = buildResourcePath(platform, environment, channelKey)
                    val dataDirPath = getConfigDataDirectory()
                    // WasmJS 平台使用特殊路径格式
                    val dataFilePath = if (dataDirPath == "localStorage") {
                        "$dataDirPath/$fileName"
                    } else {
                        "$dataDirPath/$fileName"
                    }
                    
                    try {
                        // 尝试从数据目录读取
                        Logger.debug("[LocalConfigReadService] Attempting to read from data directory: $dataFilePath")
                        readLocalConfigFile(dataFilePath)
                    } catch (e: Exception) {
                        // 如果数据目录不存在，从应用资源读取
                        Logger.debug("[LocalConfigReadService] Config not found in data directory, reading from resources: $fileName")
                        readLocalConfigFile(fileName)
                    }
                }
                Logger.debug("[LocalConfigReadService] Read encrypted file, size: ${encryptedData.size} bytes")
                
                // 3. 获取加密密钥（优先使用 SDK 内部密钥）
                val finalEncryptionKey = encryptionKey 
                    ?: CdnKeyManager.getCdnEncryptionKey()
                
                Logger.debug("[LocalConfigReadService] Using encryption key (length: ${finalEncryptionKey.length})")
                
                // 4. 解密文件（加密数据是hex编码的字符串）
                val encryptedHexString = encryptedData.decodeToString()
                val decryptedJson = ConfigDecryption.decrypt(encryptedHexString, finalEncryptionKey)
                
                Logger.debug("[LocalConfigReadService] Decrypted config, JSON length: ${decryptedJson.length}")
                
                // 验证JSON不为空
                if (decryptedJson.isBlank()) {
                    throw IllegalStateException("Decrypted JSON is empty")
                }
                
                // 记录解密后的JSON内容（前500个字符）用于调试
                val jsonPreview = decryptedJson.take(500)
                Logger.debug("[LocalConfigReadService] Decrypted JSON preview: $jsonPreview${if (decryptedJson.length > 500) "..." else ""}")
                
                // 5. 解析JSON为配置数据模型
                val config = try {
                    json.decodeFromString<SDKConfig>(decryptedJson)
                } catch (e: Exception) {
                    Logger.error("[LocalConfigReadService] JSON parsing failed: ${e.message}")
                    Logger.error("[LocalConfigReadService] Full decrypted JSON: $decryptedJson")
                    throw Exception("Failed to parse decrypted JSON: ${e.message}. JSON preview: $jsonPreview", e)
                }
                
                Logger.debug("[LocalConfigReadService] Config parsed successfully: appId=${config.appId}, appName=${config.app.name}")
                
                config
            } catch (e: Exception) {
                Logger.error("[LocalConfigReadService] Config read failed: ${e.message}")
                throw Exception("Failed to read config from file: ${e.message}", e)
            }
        }
    }
    
    /**
     * 保存配置文件到数据目录
     * 
     * @param platform 平台标识
     * @param environment 环境
     * @param channelKey 渠道标识
     * @param encryptedHexString 加密的hex字符串
     */
    suspend fun saveConfigToDataDirectory(
        platform: ConfigPlatform,
        environment: ConfigEnvironment,
        channelKey: String? = null,
        encryptedHexString: String
    ) {
        return withContext(Dispatchers.Default) {
            try {
                val fileName = buildResourcePath(platform, environment, channelKey)
                // 将hex字符串转换为字节数组
                val data = encryptedHexString.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
                
                Logger.debug("[LocalConfigReadService] Saving config to data directory: $fileName, size: ${data.size} bytes")
                writeLocalConfigFile(fileName, data)
                Logger.debug("[LocalConfigReadService] Config saved successfully to data directory")
            } catch (e: Exception) {
                Logger.error("[LocalConfigReadService] Failed to save config to data directory: ${e.message}")
                throw Exception("Failed to save config to data directory: ${e.message}", e)
            }
        }
    }
    
    /**
     * 构建资源文件路径
     * 格式：manifest_{platform}_{environment}_{channel}.enc
     * 注意：这是资源路径，不是文件系统路径
     */
    private fun buildResourcePath(
        platform: ConfigPlatform,
        environment: ConfigEnvironment,
        channelKey: String? = null
    ): String {
        val channel = channelKey ?: "default"
        return "manifest_${platform.value}_${environment.name.lowercase()}_${channel}.enc"
    }
}

/**
 * 跨平台文件读取接口
 * 从应用资源或文件系统读取加密配置文件
 * 
 * 优先级：
 * 1. 如果 filePath 是绝对路径（以 / 开头或包含 :），从文件系统读取
 * 2. 否则从应用资源中读取（assets/bundle/resources）
 * 
 * @param filePath 资源路径或文件系统路径
 * @return 文件内容的字节数组
 */
internal expect suspend fun readLocalConfigFile(filePath: String): ByteArray

/**
 * 跨平台文件写入接口
 * 将加密配置文件写入到应用数据目录
 * 
 * @param fileName 文件名（如 manifest_android_test_google_global.enc）
 * @param data 文件内容的字节数组
 */
internal expect suspend fun writeLocalConfigFile(fileName: String, data: ByteArray)

/**
 * 获取配置文件数据目录路径
 * 返回应用数据目录的绝对路径，用于存储下载的配置文件
 * 
 * @return 数据目录的绝对路径
 */
internal expect fun getConfigDataDirectory(): String

