package com.zinben.opendev.services

import com.zinben.opendev.logger.Logger
import com.zinben.opendev.models.CreatePaymentRequest
import com.zinben.opendev.models.Money
import com.zinben.opendev.models.formatPlain
import com.zinben.opendev.models.PaymentMethod
import com.zinben.opendev.models.PaymentMethodType
import com.zinben.opendev.models.PaymentOrder
import com.zinben.opendev.models.PaymentRequest
import com.zinben.opendev.models.PaymentResult
import com.zinben.opendev.models.PaymentStatus
import com.zinben.opendev.models.PaymentTransaction
import com.zinben.opendev.models.Platform
import com.zinben.opendev.models.RefundRecord
import com.zinben.opendev.models.RefundRequest
import com.zinben.opendev.models.RefundResult
import com.zinben.opendev.utils.TimeUtils

class PaymentServiceImpl(
    private val http: HttpPaymentService
) : PaymentService {

    private val transactions = mutableMapOf<String, PaymentTransaction>()
    private val refunds = mutableMapOf<String, RefundRecord>()

    override suspend fun createPaymentOrder(request: CreatePaymentRequest): PaymentOrder {
        Logger.debug("[PaymentService] Creating payment order (HTTP) user=${request.userId} product=${request.productId}")
        val platformStr = request.platform.name.lowercase()
        val res = http.createOrder(request.productId, platformStr)
        val now = TimeUtils.getCurrentTimeMillis()
        return PaymentOrder(
            id = res.orderId,
            userId = request.userId,
            productId = request.productId,
            productName = request.productName,
            productDescription = request.productDescription,
            amount = Money(res.amount.formatPlain()),
            currency = res.currency,
            paymentMethod = request.paymentMethods.first(),
            platform = request.platform,
            status = apiStatusToPaymentStatus(res.status),
            createdAt = now,
            updatedAt = now,
            expiresAt = res.expiresAt,
            metadata = res.paymentData ?: emptyMap()
        )
    }

    override suspend fun executePayment(paymentRequest: PaymentRequest): PaymentResult {
        Logger.debug("[PaymentService] Verifying payment (HTTP) order=${paymentRequest.orderId}")
        return try {
            val platformStr = paymentRequest.platform.name.lowercase()
            val verify = http.verifyPayment(
                paymentRequest.orderId,
                platformStr,
                paymentRequest.paymentData
            )
            val now = TimeUtils.getCurrentTimeMillis()
            val txId = verify.transactionId ?: "txn_${now}_${paymentRequest.orderId}"
            val transaction = PaymentTransaction(
                id = txId,
                orderId = paymentRequest.orderId,
                transactionId = txId,
                paymentMethod = paymentRequest.paymentMethod,
                amount = paymentRequest.amount,
                currency = paymentRequest.currency,
                status = apiStatusToPaymentStatus(verify.status),
                paymentTime = verify.verifiedAt ?: now,
                platformData = paymentRequest.paymentData,
                createdAt = now,
                updatedAt = now
            )
            transactions[txId] = transaction
            when (transaction.status) {
                PaymentStatus.SUCCESS ->
                    PaymentResult.Success(
                        orderId = paymentRequest.orderId,
                        transactionId = txId,
                        amount = paymentRequest.amount,
                        currency = paymentRequest.currency,
                        paymentTime = verify.verifiedAt ?: now
                    )
                PaymentStatus.PENDING, PaymentStatus.PROCESSING ->
                    PaymentResult.Pending(
                        orderId = paymentRequest.orderId,
                        status = verify.status,
                        message = verify.status
                    )
                else ->
                    PaymentResult.Failure(
                        orderId = paymentRequest.orderId,
                        errorCode = verify.status,
                        errorMessage = verify.status
                    )
            }
        } catch (e: Exception) {
            Logger.error("[PaymentService] executePayment failed: ${e.message}")
            PaymentResult.Failure(
                orderId = paymentRequest.orderId,
                errorCode = "VERIFY_FAILED",
                errorMessage = e.message ?: "Verification failed"
            )
        }
    }

    override suspend fun queryPaymentStatus(orderId: String): PaymentStatus {
        Logger.debug("[PaymentService] Querying payment status (HTTP) order=$orderId")
        return try {
            val res = http.queryOrderStatus(orderId)
            apiStatusToPaymentStatus(res.status)
        } catch (e: Exception) {
            Logger.error("[PaymentService] queryPaymentStatus failed: ${e.message}")
            PaymentStatus.FAILED
        }
    }

    override suspend fun requestRefund(refundRequest: RefundRequest): RefundResult {
        Logger.debug("[PaymentService] Requesting refund transaction=${refundRequest.transactionId}")
        val transaction = transactions[refundRequest.transactionId]
        if (transaction == null) {
            Logger.error("[PaymentService] Transaction not found: ${refundRequest.transactionId}")
            return RefundResult.Failure(
                errorCode = "TRANSACTION_NOT_FOUND",
                errorMessage = "Transaction not found"
            )
        }
        if (transaction.status != PaymentStatus.SUCCESS) {
            Logger.error("[PaymentService] Transaction not eligible for refund: ${transaction.status}")
            return RefundResult.Failure(
                errorCode = "INVALID_TRANSACTION_STATUS",
                errorMessage = "Transaction is not eligible for refund"
            )
        }
        val currentTime = TimeUtils.getCurrentTimeMillis()
        val refundId = "refund_${currentTime}_${refundRequest.transactionId}"
        val refund = RefundRecord(
            id = refundId,
            transactionId = refundRequest.transactionId,
            orderId = transaction.orderId,
            amount = refundRequest.amount,
            currency = refundRequest.currency,
            reason = refundRequest.reason,
            status = PaymentStatus.SUCCESS,
            refundTime = currentTime,
            createdAt = currentTime,
            updatedAt = currentTime
        )
        refunds[refundId] = refund
        transactions[refundRequest.transactionId] = transaction.copy(
            status = PaymentStatus.REFUNDED,
            updatedAt = currentTime
        )
        Logger.debug("[PaymentService] Refund processed locally: $refundId")
        return RefundResult.Success(
            refundId = refundId,
            amount = refundRequest.amount,
            currency = refundRequest.currency,
            refundTime = currentTime
        )
    }

    override suspend fun queryRefundStatus(refundId: String): PaymentStatus {
        Logger.debug("[PaymentService] Querying refund status: $refundId")
        val refund = refunds[refundId]
        return refund?.status ?: PaymentStatus.FAILED
    }

    override suspend fun getPaymentMethods(): List<PaymentMethod> {
        Logger.debug("[PaymentService] Getting payment methods (HTTP)")
        return try {
            val cfg = http.getPaymentConfig()
            val methods = cfg.supportedMethods
            if (methods.isNullOrEmpty()) {
                defaultPaymentMethods()
            } else {
                methods.map { name ->
                    val type = paymentMethodTypeFromApi(name)
                    PaymentMethod(
                        type = type,
                        name = name,
                        platformSupport = listOf(
                            Platform.ANDROID,
                            Platform.IOS,
                            Platform.DESKTOP,
                            Platform.WASMJS
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Logger.error("[PaymentService] getPaymentMethods failed: ${e.message}")
            defaultPaymentMethods()
        }
    }

    override suspend fun verifyPaymentCallback(callbackData: String): Boolean {
        Logger.debug("[PaymentService] Verifying payment callback")
        return try {
            callbackData.contains("transaction_id") && callbackData.contains("order_id")
        } catch (e: Exception) {
            Logger.error("[PaymentService] Payment callback verification failed: ${e.message}")
            false
        }
    }

    override suspend fun getPaymentHistory(userId: String, limit: Int): List<PaymentOrder> {
        Logger.debug("[PaymentService] Getting payment history (HTTP) user=$userId limit=$limit")
        // 不向调用方吞掉异常：成功时列表可为空（服务端无订单）；失败由 PaymentManager 回退本地缓存
        return http.getPaymentHistory(limit).map { dto ->
            PaymentOrder(
                id = dto.orderId,
                userId = userId,
                productId = dto.productId,
                productName = dto.productId,
                productDescription = null,
                amount = Money(dto.amount.formatPlain()),
                currency = dto.currency,
                paymentMethod = PaymentMethodType.STRIPE_CARD,
                platform = parsePlatform(dto.platform),
                status = apiStatusToPaymentStatus(dto.status),
                createdAt = dto.createdAt,
                updatedAt = dto.completedAt ?: dto.createdAt,
                expiresAt = null,
                metadata = emptyMap()
            )
        }
    }

    override suspend fun cancelPaymentOrder(orderId: String): Boolean {
        Logger.debug("[PaymentService] cancelPaymentOrder not supported over HTTP: $orderId")
        return false
    }

    private fun apiStatusToPaymentStatus(raw: String): PaymentStatus {
        return when (raw.lowercase()) {
            "pending", "created" -> PaymentStatus.PENDING
            "processing" -> PaymentStatus.PROCESSING
            "success", "completed", "paid", "verified" -> PaymentStatus.SUCCESS
            "failed", "expired" -> PaymentStatus.FAILED
            "cancelled", "canceled" -> PaymentStatus.CANCELLED
            "refunded" -> PaymentStatus.REFUNDED
            else -> PaymentStatus.PENDING
        }
    }

    private fun parsePlatform(raw: String): Platform =
        runCatching { Platform.valueOf(raw.uppercase()) }.getOrDefault(Platform.ANDROID)

    private fun paymentMethodTypeFromApi(name: String): PaymentMethodType =
        runCatching { PaymentMethodType.valueOf(name.uppercase()) }.getOrElse {
            when (name.lowercase()) {
                "wechat", "wechat_pay" -> PaymentMethodType.WECHAT_PAY
                "alipay" -> PaymentMethodType.ALIPAY
                "apple_pay" -> PaymentMethodType.APPLE_PAY
                "google_pay" -> PaymentMethodType.GOOGLE_PAY
                "stripe", "stripe_card" -> PaymentMethodType.STRIPE_CARD
                "paypal" -> PaymentMethodType.PAYPAL
                else -> PaymentMethodType.STRIPE_CARD
            }
        }

    private fun defaultPaymentMethods(): List<PaymentMethod> {
        return listOf(
            PaymentMethod(
                type = PaymentMethodType.WECHAT_PAY,
                name = "微信支付",
                platformSupport = listOf(Platform.ANDROID, Platform.IOS, Platform.DESKTOP, Platform.WASMJS)
            ),
            PaymentMethod(
                type = PaymentMethodType.ALIPAY,
                name = "支付宝",
                platformSupport = listOf(Platform.ANDROID, Platform.IOS, Platform.DESKTOP, Platform.WASMJS)
            ),
            PaymentMethod(
                type = PaymentMethodType.APPLE_PAY,
                name = "Apple Pay",
                platformSupport = listOf(Platform.IOS, Platform.DESKTOP, Platform.WASMJS)
            ),
            PaymentMethod(
                type = PaymentMethodType.GOOGLE_PAY,
                name = "Google Pay",
                platformSupport = listOf(Platform.ANDROID, Platform.DESKTOP, Platform.WASMJS)
            ),
            PaymentMethod(
                type = PaymentMethodType.STRIPE_CARD,
                name = "Stripe",
                platformSupport = listOf(Platform.ANDROID, Platform.IOS, Platform.DESKTOP, Platform.WASMJS)
            ),
            PaymentMethod(
                type = PaymentMethodType.PAYPAL,
                name = "PayPal",
                platformSupport = listOf(Platform.ANDROID, Platform.IOS, Platform.DESKTOP, Platform.WASMJS)
            )
        )
    }
}
